//
//  CustomDatePickerVC1.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import FSCalendar

class CustomDatePickerVC1: UIViewController {

    @IBOutlet weak var mainView: CardView!
    @IBOutlet weak var myDatePicker: UIDatePicker!
    
    @IBOutlet weak var calendar: FSCalendar!
    //MARK: - Variables
    var voidSelectedDate:((Date) -> Void)?
    var selectedDate:String = ""
    var selectedStartDate: Date?
        var selectedEndDate: Date?
    
    //MARK: - Custom Function's
    func showAnimation(isShow:Bool){
        UIView.animate(withDuration: isShow ? 0.40 : 0.40, delay: 0, options: .curveEaseOut) {
            self.mainView.transform = isShow ? .identity : CGAffineTransform(scaleX: 0.01, y: 0.01)
            self.view.alpha = isShow ? 1 : 0
        } completion: { isCompleted in
            if !isShow{
                self.dismiss(animated: false, completion: nil)
            }
        }
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
            if selectedStartDate == nil {
                selectedStartDate = date
                selectedEndDate = nil
            } else if selectedEndDate == nil {
                selectedEndDate = date
            } else {
                selectedStartDate = date
                selectedEndDate = nil
            }

            // Perform any additional logic or update UI based on the selected dates
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        calendar.delegate = self
//        calendar.dataSource = self
        
        view.alpha = 0
        mainView.transform = CGAffineTransform(scaleX: 0, y: 0)
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showAnimation(isShow: true)
    }
    
    @IBAction func btnActionDismissScreen(_ sender: UIButton) {
        self.showAnimation(isShow: false)
    }
    
    @IBAction func datePickerActionSelectDate(_ sender: UIButton) {
        voidSelectedDate?(myDatePicker.date)
        self.showAnimation(isShow: true)
        self.showAnimation(isShow: false)
    }
}


