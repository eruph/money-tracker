//
//  ChatMessageVC2.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import CoreData
import OneSignalFramework
import CoreLocation

protocol Open2VCDelegate: AnyObject {
    func open2VCDidSave()
}

class ChatMessageVC2: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var txtcategory: UITextField!
    @IBOutlet weak var txtused: UITextField!
    @IBOutlet weak var txtamount: UITextField!
    @IBOutlet weak var customview: UIView!
    @IBOutlet weak var topview: UIView!
    @IBOutlet weak var mainview: MainGradientView!
    @IBOutlet weak var lblchat: UILabel!
    @IBOutlet weak var lbltype: UILabel!
    
    var bottomSheetVC: AnalysisViewController?
    var mainVC: MainViewController?
    weak var delegate: Open2VCDelegate?
    var isConditionMet = false
    var originalFrame: CGRect!
    var messageValue: String = ""
    var type: String = ""
    var note: String  = ""
    var amount: Int = 0
    var category: String = ""
    var prompt: String = ""
    var message = ChatMessageVC()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lbltype.isHidden = true
        lblchat.text = messageValue
        lbltype.text = type
        txtamount.text = String(amount)
        txtused.text = note
        txtcategory.text = category
        txtamount.delegate = self
        registerForKeyboardNotifications()
        view.alpha = 0
        customview.transform = CGAffineTransform(scaleX: 0, y: 0)
        topview.roundTopCorners(cornerRadius: 30)
        customview.layer.cornerRadius = 30.0
        mainview.layer.cornerRadius = 30.0
        topview.addBottomBorder(color: UIColor(hex: "AEB5C0"), borderWidth: 1)
        
        // Add a tap gesture recognizer to dismiss the keyboard
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tapGestureRecognizer)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showAnimation(isShow: true)
    }
    
    func showAnimation(isShow: Bool, completion: (() -> Void)? = nil) {
        UIView.animate(withDuration: 0.40, delay: 0, options: .curveEaseOut, animations: {
            self.customview.transform = isShow ? .identity : CGAffineTransform(scaleX: 0.01, y: 0.01)
            self.view.alpha = isShow ? 1 : 0
        }, completion: { _ in
            if !isShow {
                self.dismiss(animated: false, completion: completion)
            }
        })
    }
    
    func saveTransaction(type: String, category: String, note: String, amount: Int, date: Date, time: String, notificatin_id: Int) {
        DispatchQueue.main.async {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let managedContext = appDelegate.persistentContainer.viewContext
            
            guard let mainEntity = NSEntityDescription.entity(forEntityName: "Main", in: managedContext) else { return }
            let newMain = NSManagedObject(entity: mainEntity, insertInto: managedContext)
            
            // Set a unique identifier as an integer (assuming "primarykey" is an Integer 32 attribute)
            let uniqueIdentifier = Int.random(in: 1...Int.max) // Generate a unique integer
            newMain.setValue(uniqueIdentifier, forKey: "primarykey")
            
            newMain.setValue(type, forKey: "type") // Use the correctedType here
            
            // Capitalize the first letter and convert the rest to lowercase
            let formattedCategory = category.prefix(1).capitalized + category.dropFirst().lowercased()
            newMain.setValue(formattedCategory, forKey: "category")
            
            newMain.setValue(note, forKey: "note")
            newMain.setValue(Date(), forKey: "date")
            newMain.setValue(amount, forKey: "amount")
            newMain.setValue(time, forKey: "time")
            
            print("Primary:--- \(uniqueIdentifier)")
            
            // Saving the context
            do {
                try managedContext.save()
                CustomToast.toastMessage(message: "Transaction Saved Successfully", type: .SUCCESS)
            } catch {
                print("Error saving context: \(error)")
            }
        }
    }
    
    @objc func handleTap() {
        // Dismiss the keyboard
        view.endEditing(true)
    }

    @IBAction func click_btncheck_policy(_ sender: UIButton) {
        sender.isSelected.toggle() // Toggle the isSelected state
        
        if sender.isSelected {
            UserDefaults.standard.set(true, forKey: "isButtonChecked")
        } else {
            UserDefaults.standard.set(false, forKey: "isButtonChecked")
        }
    }
    
    func getDeviceID() -> String? {
        let device = UIDevice.current
        return device.identifierForVendor?.uuidString
    }
    
    func getOneSignalPlayerID(completion: @escaping (String?) -> Void) {
        // Prompt the user for push notification permission
        //OneSignal.promptForPushNotifications(userResponse: { accepted in
           // if accepted {
                // If the user accepts, retrieve the OneSignal player ID
                guard let oneSignal = OneSignal.User.pushSubscription.id else {
                    print("Failed to retrieve OneSignal player ID")
                    completion(nil)
                    return
                }
                
                // Use the playerID as needed
                print("OneSignal player ID: \(oneSignal)")
                completion(oneSignal)
//            } else {
//                // If the user rejects push notification permission
//                print("User rejected push notification permission")
//                completion(nil)
           // }
        //})
    }
    
    func registerForKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        UIView.animate(withDuration: 0.3) {
            self.customview.transform = .identity
        }
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardFrame: NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardHeight = keyboardFrame.cgRectValue.height
            let bottomSpace = self.view.frame.height - (customview.frame.origin.y + customview.frame.height)
            if bottomSpace < keyboardHeight {
                UIView.animate(withDuration: 0.3) {
                    self.customview.transform = CGAffineTransform(translationX: 0, y: -(keyboardHeight - bottomSpace + 15)) // Additional 20px space
                }
            }
        }
    }
    
    @IBAction func click_saved(_ sender: Any) {
        self.bottomSheetVC?.loadTransactions()
        //self.bottomSheetVC?.loadTransactions()
        self.mainVC?.retrieveData()
        let currentDate = Date()
        delegate?.open2VCDidSave()
        // Attempt to convert the text from txtamount to an Int
        if let amountValue = Int(txtamount.text ?? "") {
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "HH:mm"
            let currentTime = Date()
            let formattedTime = dateFormatter.string(from: currentTime)
            
            // Successfully converted to Int, now you can pass it to saveTransaction
            self.saveTransaction(type: lbltype.text ?? "", category: txtcategory.text ?? "", note: txtused.text ?? "", amount: amountValue, date: currentDate, time: formattedTime, notificatin_id: 0)
            if let switchState = UserDefaults.standard.object(forKey: "SwitchStateAllEntry") as? Bool {
                if switchState {
                    self.getOneSignalPlayerID { playerID in
                        guard let playerID = playerID else {
                            print("Failed to obtain OneSignal player ID")
                            return
                        }
                        
                        if let deviceID = self.getDeviceID() {
                            print("OneSignal player ID: \(playerID)")
                            print("Device ID: \(deviceID)")
                            
                            if let playerID = self.getDeviceID() {
                                print("OneSignal player ID: \(playerID)")
                                
                                if let deviceState = OneSignal.User.pushSubscription.id {
                                    print("OneSignal Device ID: \(deviceState)")
                                    
                                    let dateFormatter = DateFormatter()
                                    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                                    let currentTime = dateFormatter.string(from: Date())
                                    
                                    APIManagers.shared.AllTime_callNotificationAPI(playerid: playerID, prompt: self.txtused.text!)
                                } else {
                                    print("Failed to obtain OneSignal Device ID")
                                }
                            } else {
                                print("Failed to obtain player ID")
                            }
                        }
                    }
                }
            }
            
            showAnimation(isShow: false) {}
            //message.messageview.isHidden = false
        } else {
            // Handle the case where txtamount.text is not a valid integer
            // You might want to show an error message or take appropriate action
            print("Invalid amount entered")
        }
        
        let userInfo: [String: Any] = [
            "type": type,
            "amount": amount,
            "category": category,
            "note": note,
            //"date": formattedDate
        ]
        
        NotificationCenter.default.post(name: Notification.Name("DataUpdateNotification"), object: nil, userInfo: userInfo)
        self.dismiss(animated: true, completion: nil)
        self.bottomSheetVC?.loadTransactions()
        self.mainVC?.retrieveData()
        self.mainVC?.retrieveDataTotal()
        
    }
}

