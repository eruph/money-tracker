//
//  FilterAlertsVC.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//
import UIKit

protocol FilterVCDelegate: AnyObject {
    func didSelectIncome()
    //func didSelectFilterOption(_ filterOption: FilterOption)
}

class FilterAlertsVC: UIViewController {

    var saveButtonHandler: (([String]) -> Void)?
    weak var delegate: FilterVCDelegate?
    @IBOutlet weak var btnuncheck_expense: UIButton!
    @IBOutlet weak var btnuncheck_income: UIButton!
    @IBOutlet weak var choice_view: UIView!
    @IBOutlet weak var lblexpense: UILabel!
    @IBOutlet weak var lblincome: UILabel!
    
    var selectedValues: [String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.alpha = 0
        choice_view.transform = CGAffineTransform(scaleX: 0, y: 0)
    }
    
    func showAnimation(isShow: Bool) {
        UIView.animate(withDuration: isShow ? 0.20 : 0.40, delay: 0, options: .curveEaseOut) {
            self.choice_view.transform = isShow ? .identity : CGAffineTransform(scaleX: 0.01, y: 0.01)
            self.view.alpha = isShow ? 1 : 0
        } completion: { isCompleted in
            if !isShow {
                self.dismiss(animated: false, completion: nil)
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        showAnimation(isShow: true)
    }

    @IBAction func click_check_income(_ sender: UIButton) {
        toggleSelection(for: "Income", button: sender)
    }

    @IBAction func click_check_expense(_ sender: UIButton) {
        toggleSelection(for: "Expense", button: sender)
    }

    @IBAction func click_check_borrowing(_ sender: UIButton) {
        toggleSelection(for: "Borrowing", button: sender)
    }

    @IBAction func click_check_lending(_ sender: UIButton) {
        toggleSelection(for: "Lending", button: sender)
    }

    private func toggleSelection(for type: String, button: UIButton) {
        if button.isSelected {
            if let index = selectedValues.firstIndex(of: type) {
                selectedValues.remove(at: index)
            }
        } else {
            selectedValues.append(type)
        }
        button.isSelected = !button.isSelected
    }

    @IBAction func btn_clickhide(_ sender: Any) {
        showAnimation(isShow: false)
    }

    func showToast(message: String, duration: TimeInterval = 2.0) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.view.alpha = 0.7
        alert.view.layer.cornerRadius = 15
        
        if let presenter = self.presentedViewController {
            presenter.dismiss(animated: false) {
                presenter.present(alert, animated: true)
            }
        } else {
            present(alert, animated: true)
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
            alert.dismiss(animated: true)
        }
    }

    @IBAction func click_btnapply(_ sender: Any) {
        if selectedValues.isEmpty {
            CustomToast.toastMessage(message: "Please Select the Type", type: .NONE)
            //showToast(message: "Please Select the Type")
        } else {
            saveButtonHandler?(selectedValues)
            dismiss(animated: true, completion: nil)
            showAnimation(isShow: false)
        }
    }
}




