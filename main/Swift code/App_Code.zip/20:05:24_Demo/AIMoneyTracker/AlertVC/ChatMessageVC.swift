//
//  ChatMessageVC.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import CoreData
import Alamofire
import OneSignalFramework
//import OneSignal
import CoreLocation

struct GetCategory : Decodable {
    let id: Int
    let name: String
    //let amount: Int
    
    init(fromDic:[String:Any]){
        id = fromDic["id"] as? Int ?? 0
        name = fromDic["name"] as? String ?? ""
        // amount = fromDic["amount"] as? Int ?? 0
    }
}

class ChatMessageVC: UIViewController, UITextFieldDelegate, Open2VCDelegate, UIGestureRecognizerDelegate, NotificationVCDelegate {
    
    @IBOutlet weak var messageview: UIView!
    @IBOutlet weak var tblmessage: UITableView!
    @IBOutlet weak var txtchat: UITextField!
    
    @IBOutlet weak var uiview3: UIView!
    @IBOutlet weak var uiview2: UIView!
    @IBOutlet weak var uiview1: UIView!
    @IBOutlet weak var lbltype: UILabel!
    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var txt_note: UITextField!
    @IBOutlet weak var txt_amount: UITextField!
    @IBOutlet weak var txtcategory: UITextField!
    
    @IBOutlet weak var SCROLLVIEW: UIScrollView!
    
    var mainSheetVC: MainViewController?
    
    private var isInternetConnected:Bool
    {
        return NetworkReachabilityManager()?.isReachable ?? false
    }
    
    var isFirstSave = true
    var messageValue: String = ""
    var apiResponse: String = ""
    var promptText: String?
    let transparentView = UIView()
    var voidIsGrpAdded:(() -> Void)?
    
    let options = ["Option 1", "Option 2", "Option 3"]
    var bottomSheetVC: AnalysisViewController?
    var mainview: MainViewController?
    var dataSource = [String]()
    var selectedButton = UIButton()
    var arrCategory = [GetCategory]()
    let tableview = UITableView()
    
    var notificationVC: NotificationViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardAppear), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardDisappear), name: UIResponder.keyboardWillHideNotification,object: nil)
        
//        uiview1.addBottomBorder(color: .black, thickness: 0.7)
//        uiview2.addBottomBorder(color: .black, thickness: 0.7)
//        uiview3.addBottomBorder(color: .black, thickness: 0.7)
        
       // notificationVC!.delegate = self
        
        txtchat.borderStyle = .roundedRect
        
        // Adjust the vertical position of the tab bar item titles
        if let tabBarController = self.tabBarController {
                if let items = tabBarController.tabBar.items {
                    // Calculate the width for each tab bar item
                    let itemWidth = tabBarController.tabBar.frame.width / CGFloat(items.count)

                    for item in items {
                        // Set the item's width to the calculated width
                        item.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -12)
                    }
                }
            }
        
        // Make it round
        txtchat.layer.cornerRadius = txtchat.frame.height / 2
        txtchat.clipsToBounds = true
        txtchat.layer.borderWidth = 1.0
        txtchat.layer.borderColor = UIColor(hex: "DBDBDB").cgColor
        
        //self.title = "Personal Expense"
        lbltype.isHidden = true
        updateSegmentAppearance()
        lbltype.text = "Income"
        
        // Add a tap gesture recognizer to the view
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tapGestureRecognizer)
        
        tblmessage.isScrollEnabled = false
        tblmessage.separatorStyle  = .none
        
        txtchat.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        // Assuming you have a UIView instance called myView
        uiview1.addBottomBorders(color: .gray, thickness: 1.0)
        uiview2.addBottomBorders(color: .gray, thickness: 1.0)
        uiview3.addBottomBorders(color: .gray, thickness: 1.0)
    }
    
    @objc func keyboardAppear(notification: Notification) {
            if let userInfo = notification.userInfo,
               let keyboardSize = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
                let contentInsets = UIEdgeInsets(top: 0, left: 0, bottom: keyboardSize.height, right: 0)
                SCROLLVIEW.contentInset = contentInsets
                SCROLLVIEW.scrollIndicatorInsets = contentInsets
            }
        }
        
        @objc func keyboardDisappear(notification: Notification) {
            let contentInsets = UIEdgeInsets.zero
            SCROLLVIEW.contentInset = contentInsets
            SCROLLVIEW.scrollIndicatorInsets = contentInsets
        }
    
    @objc func handleTap() {
        // Check if the user has already received the reward
        let hasReceivedReward = UserDefaults.standard.bool(forKey: "HasReceivedReward")
        
        if !hasReceivedReward {
            // Increment the click count when the user taps anywhere on the screen
            Click_CountClass.shared.incrementClickCount()
            Click_CountClass.shared.checkClickCount(presentingViewController: self)
        }
        view.endEditing(true)
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        // Don't dismiss the keyboard if the touch is inside certain views
        // For example, you might want to allow interaction with buttons or other controls
        return !(touch.view is UIControl)
    }
    
    func setupUI() {
        // Set up the table view
        tblmessage.delegate = self
        tblmessage.dataSource = self
        tblmessage.estimatedRowHeight = 100.0
        tblmessage.rowHeight = UITableView.automaticDimension
    }
    
    // Implement the UITextFieldDelegate method to dismiss the keyboard when the Return key is pressed
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtchat.resignFirstResponder()
        return true
    }
    
    func open2VCDidSave() {
        messageview.isHidden = false
        //showAnimation(isShow: false)
        self.mainSheetVC?.retrieveData()
    }
    
    @IBAction func btn_save(_ sender: Any) {
        self.bottomSheetVC?.loadTransactions()
        
        let type = lbltype.text!
        let category = txtcategory.text!
        let note = txt_note.text!
        let date = Date()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"

        let currentTime = Date()
        let formattedTime = dateFormatter.string(from: currentTime)
        
        guard let amount = Int(txt_amount.text ?? "") else {
            CustomToast.toastMessage(message: "Please Enter Amount", type: .NONE)
           // view.makeToast("Please Enter Amount", position: .top)
            print("Invalid amount value.")
            return
        }
        
        if note.isEmpty {
            CustomToast.toastMessage(message: "Please Enter Note", type: .NONE)
           // view.makeToast("Please Enter Note", position: .top)
        } else if type.isEmpty {
            CustomToast.toastMessage(message: "Please Select Transaction Type", type: .NONE)
           // view.makeToast("Please Select Transaction Type", position: .top)
        } else if category.isEmpty {
            CustomToast.toastMessage(message: "Please Select Category", type: .NONE)
            //view.makeToast("Please Select Category", position: .top)
        } else if amount == 0 {
            CustomToast.toastMessage(message: "Please Enter Amount", type: .NONE)
            //view.makeToast("Please Enter Amount", position: .top)
        } else {
            saveTransaction(type: type, category: category, note: note, amount: amount, date: date, time: formattedTime, notification_id: 0)
            CustomToast.toastMessage(message: "Saved Successfully", type: .SUCCESS)
            //view.makeToast("Saved Successfully", position: .top)
            
            // Clear text fields
            txtcategory.text = ""
            txt_note.text = ""
            txt_amount.text = ""
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy"
            // let formattedDate = dateFormatter.string(from: date)
            
            let userInfo: [String: Any] = [
                "type": type,
                "amount": amount,
                "category": category,
                "note": note,
                //"date": formattedDate
            ]
            if let switchState = UserDefaults.standard.object(forKey: "SwitchStateAllEntry") as? Bool {
                if switchState {
                    self.getOneSignalPlayerID { playerID in
                        guard let playerID = playerID else {
                            print("Failed to obtain OneSignal player ID")
                            return
                        }
                        
                        if let deviceID = self.getDeviceID() {
                            print("OneSignal player ID: \(playerID)")
                            print("Device ID: \(deviceID)")
                            
                            if let playerID = self.getDeviceID() {
                                print("OneSignal player ID: \(playerID)")
                                
                                if let deviceState = OneSignal.User.pushSubscription.id {
                                    print("OneSignal Device ID: \(deviceState)")
                                    
                                    let dateFormatter = DateFormatter()
                                    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                                    let currentTime = dateFormatter.string(from: Date())
                                    
                                    APIManagers.shared.AllTime_callNotificationAPI(playerid: playerID, prompt: note)
                                } else {
                                    print("Failed to obtain OneSignal Device ID")
                                }
                            } else {
                                print("Failed to obtain player ID")
                            }
                        }
                    }
                }
            }
            
            NotificationCenter.default.post(name: Notification.Name("DataUpdateNotification"), object: nil, userInfo: userInfo)
            self.dismiss(animated: true, completion: nil)
            self.bottomSheetVC?.loadTransactions()
            self.mainview?.retrieveDataTotal()
            self.mainview?.retrieveData()
            view.endEditing(true)
        }
    }
    
    @IBAction func click_segment(_ sender: Any) {
        updateSegmentAppearance()
    }
    
    func updateSegmentAppearance() {
        if segment.selectedSegmentIndex == 0 {
            lbltype.text = "Income"
            segment.backgroundColor = UIColor(red: 255.0/255.0, green: 200.0/255.0, blue: 60.0/255.0, alpha: 1.0)
            segment.tintColor = .white
        } else if segment.selectedSegmentIndex == 1 {
            lbltype.text = "Expense"
            segment.backgroundColor = UIColor(red: 255.0/255.0, green: 200.0/255.0, blue: 60.0/255.0, alpha: 1.0)
            segment.tintColor = .white
        }else if segment.selectedSegmentIndex == 2 {
            lbltype.text = "Lending"
            segment.backgroundColor = UIColor(red: 255.0/255.0, green: 200.0/255.0, blue: 60.0/255.0, alpha: 1.0)
            segment.tintColor = .white
        }
        else if segment.selectedSegmentIndex == 3 {
            lbltype.text = "Borrowing"
            segment.backgroundColor = UIColor(red: 255.0/255.0, green: 200.0/255.0, blue: 60.0/255.0, alpha: 1.0)
            segment.tintColor = .white
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {
            return
        }
        
        let latitude = location.coordinate.latitude
        let longitude = location.coordinate.longitude
        
        // Use the latitude and longitude values as needed
        print("Latitude: \(latitude)")
        print("Longitude: \(longitude)")
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location manager failed with error: \(error.localizedDescription)")
    }
    
    func saveTransaction(type: String, category: String, note: String, amount: Int, date: Date, time: String, notification_id: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        guard let mainEntity = NSEntityDescription.entity(forEntityName: "Main", in: managedContext) else { return }
        let newMain = NSManagedObject(entity: mainEntity, insertInto: managedContext)
        
        let uniqueIdentifier = Int.random(in: 1...Int.max) // Generate a unique integer
        newMain.setValue(uniqueIdentifier, forKey: "primarykey")
        
        // Determine the type based on lblType
        if lbltype.text == "Expense" {
            newMain.setValue("Expense", forKey: "type")
        } else if lbltype.text == "Income" {
            newMain.setValue("Income", forKey: "type")
        } else if lbltype.text == "Lending" {
            newMain.setValue("Lending", forKey: "type")
        } else if lbltype.text == "Borrowing" {
            newMain.setValue("Borrowing", forKey: "type")
        }
        
        // Capitalize the first letter and convert the rest to lowercase
        let formattedCategory = category.prefix(1).capitalized + category.dropFirst().lowercased()
        newMain.setValue(formattedCategory, forKey: "category")
        
        newMain.setValue(note, forKey: "note")
        newMain.setValue(Date(), forKey: "date")
        newMain.setValue(amount, forKey: "amount")
        newMain.setValue(time, forKey: "time")
        
        print("Primary:--- \(uniqueIdentifier)")
        // Saving the context
        do {
            try managedContext.save()
            print("Transaction saved successfully.")
        } catch {
            print("Error saving context: \(error)")
        }
    }
    
    @IBAction func click_msg_done(_ sender: Any) {
        
        guard let text = txtchat.text?.trimmingCharacters(in: .whitespacesAndNewlines), !text.isEmpty else {
            // Display an error message or handle the case when the prompt text is nil or empty
            return
        }
        
        promptText = text
        //bottomSheetVC?.view.isHidden = false
        messageValue = txtchat.text ?? ""
        tblmessage.reloadRows(at: [IndexPath(row: 0, section: 0)], with: .none)
        txtchat.text = ""
        //bottomSheetVC?.reloadData()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.apiResponse = "Loading..."
            self.tblmessage.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .none)
        }
        
        func countWordsAndSpacesInString(_ inputString: String) -> (wordCount: Int, spaceCount: Int, totalCount: Int) {
            let words = inputString.components(separatedBy: .whitespacesAndNewlines)
            let filteredWords = words.filter { !$0.isEmpty }
            
            let spaceCount = inputString.count - inputString.replacingOccurrences(of: " ", with: "").count
            
            let wordCount = filteredWords.count
            let totalCount = wordCount + spaceCount
            
            return (wordCount: wordCount, spaceCount: spaceCount, totalCount: totalCount)
        }
        
        
        // Example usage:
        let inputString = promptText
        let counts = countWordsAndSpacesInString(inputString!)
        print("Word count: \(counts.wordCount)")
        print("Space count: \(counts.spaceCount)")
        print("Total count: \(counts.totalCount)")
        
        if counts.totalCount <= 15 {
            if isInternetConnected {
                APIManagers.shared.callAPI(with: promptText!) { [weak self] (type, amount, category, note)  in
                    guard let self = self else { return }
                    
                    print(type)
                    print(amount)
                    print(category)
                    print(note)
                    
                    let correctedType = type.capitalized // Capitalize the type
                    
                    if correctedType == "Income" || correctedType == "Expense" || correctedType == "Lending" || correctedType == "Borrowing" || correctedType == "NA" {
                        if amount == 0 || category == "NA" || note == "NA" {
                            self.apiResponse = "Hey dear, I think some details are missing.\nPlease check the Suspense table."
                            // Check if the button in Open2VC is checked
                            let isButtonChecked = UserDefaults.standard.bool(forKey: "isButtonChecked")
                            
                            if !isButtonChecked {
                                // The button in Open2VC is not checked, so present Open2VC
                                DispatchQueue.main.async {
                                    self.messageview.isHidden = true
                                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                    if let open2VC = storyboard.instantiateViewController(withIdentifier: "ChatMessageVC2") as? ChatMessageVC2 {
                                        // Save data in UserDefaults
                                        UserDefaults.standard.set(true, forKey: "isSavedInUserDefaults")
                                        open2VC.modalPresentationStyle = .overCurrentContext
                                        open2VC.delegate = self
                                        open2VC.messageValue = self.messageValue
                                        open2VC.type = "Suspense"
                                        open2VC.amount = amount
                                        open2VC.note = note
                                        open2VC.category = category
                                        // Present the Open2VC
                                        self.present(open2VC, animated: true, completion: nil)
                                    }
                                }
                            }
                            
                            if isButtonChecked {
                                // Call saveTransaction only if it's a success message
                                let currentDate = Date()
                                
                                let dateFormatter = DateFormatter()
                                dateFormatter.dateFormat = "HH:mm"

                                let currentTime = Date()
                                let formattedTime = dateFormatter.string(from: currentTime)
                                
                                // Check the switch state
                                if let switchState = UserDefaults.standard.object(forKey: "SwitchState") as? Bool {
                                    if switchState {
                                        // Switch is ON, make the API call
                                        self.getOneSignalPlayerID { playerID in
                                            guard let playerID = playerID else {
                                                print("Failed to obtain OneSignal player ID")
                                                return
                                            }
                                            
                                            if let deviceID = self.getDeviceID() {
                                                print("OneSignal player ID: \(playerID)")
                                                print("Device ID: \(deviceID)")
                                                
                                                if let playerID = self.getDeviceID() {
                                                    print("OneSignal player ID: \(playerID)")
                                                    
                                                    if let deviceState = OneSignal.User.pushSubscription.id {
                                                        print("OneSignal Device ID: \(deviceState)")
                                                        
                                                        let dateFormatter = DateFormatter()
                                                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                                                        let currentTime = Date()

                                                        // Add one hour to the current time
                                                        let calendar = Calendar.current
                                                        let modifiedTime = calendar.date(byAdding: .hour, value: 1, to: currentTime)
                                                        
                                                        // Convert modifiedTime back to string using dateFormatter
                                                        let modifiedTimeString = dateFormatter.string(from: modifiedTime!)
                                                        
                                                        //let currentTime = dateFormatter.string(from: Date())
                                                        
//                                                        APIManagers.shared.callNotificationAPI(playerid: playerID, notificationtime: modifiedTimeString, description: note) { notificationId in
//                                                            guard let notificationId = notificationId, let notificationIdInt = Int(notificationId) else {
//                                                                print("Error: Failed to get notification ID from API response")
//                                                                return
//                                                            }
//                                                            
//                                                        }
                                                        APIManagers.shared.callNotificationAPI(playerid: playerID, notificationtime: modifiedTimeString, description: note) { notificationId in
                                                            if let notificationId = notificationId {
                                                                    print("Notification ID: \(notificationId)")
                                                                // Use the obtained notification ID to saveTransaction
                                                                self.saveTransaction(type: "Suspense", category: category, note: note, amount: amount, date: currentDate, prompt: text, time: formattedTime, notification_id: Int(notificationId)!)
                                                                    // Perform further actions with the notificationId if needed
                                                                } else {
                                                                    print("Failed to obtain notification ID")
                                                                }
                                                        }
                                                    } else {
                                                        print("Failed to obtain OneSignal Device ID")
                                                    }
                                                } else {
                                                    print("Failed to obtain player ID")
                                                }
                                            }
                                        }
                                    }
                                }
                                    // Use the obtained notification ID to saveTransaction
                                    self.saveTransaction(type: "Suspense", category: category, note: note, amount: amount, date: currentDate, prompt: text, time: formattedTime, notification_id: 0)
                            }
                        } else {
                            self.apiResponse = "Your \(type) Saved Successfully.\n\(type): \(amount).\nNote: \(note)."
                            // Check if the button in Open2VC is checked
                            let isButtonChecked = UserDefaults.standard.bool(forKey: "isButtonChecked")
                            
                            if !isButtonChecked {
                                // The button in Open2VC is not checked, so present Open2VC
                                DispatchQueue.main.async {
                                    self.messageview.isHidden = true
                                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                                    if let open2VC = storyboard.instantiateViewController(withIdentifier: "ChatMessageVC2") as? ChatMessageVC2 {
                                        // Save data in UserDefaults
                                        UserDefaults.standard.set(true, forKey: "isSavedInUserDefaults")
                                        open2VC.modalPresentationStyle = .overCurrentContext
                                        open2VC.delegate = self
                                        open2VC.messageValue = self.messageValue
                                        open2VC.type = correctedType
                                        open2VC.amount = amount
                                        open2VC.note = note
                                        open2VC.category = category
                                        // Present the Open2VC
                                        self.present(open2VC, animated: true, completion: nil)
                                    }
                                }
                            }
                            
                            if isButtonChecked {
                                // Call saveTransaction only if it's a success message
                                let currentDate = Date()
                                
                                let dateFormatter = DateFormatter()
                                dateFormatter.dateFormat = "HH:mm"

                                let currentTime = Date()
                                let formattedTime = dateFormatter.string(from: currentTime)
                                
                                self.saveTransaction(type: correctedType, category: category, note: note, amount: amount, date: currentDate, prompt: text, time: formattedTime, notification_id: 0)
                                if let switchState = UserDefaults.standard.object(forKey: "SwitchStateAllEntry") as? Bool {
                                    if switchState {
                                        self.getOneSignalPlayerID { playerID in
                                            guard let playerID = playerID else {
                                                print("Failed to obtain OneSignal player ID")
                                                return
                                            }
                                            
                                            if let deviceID = self.getDeviceID() {
                                                print("OneSignal player ID: \(playerID)")
                                                print("Device ID: \(deviceID)")
                                                
                                                if let playerID = self.getDeviceID() {
                                                    print("OneSignal player ID: \(playerID)")
                                                    
                                                    if let deviceState = OneSignal.User.pushSubscription.id {
                                                        print("OneSignal Device ID: \(deviceState)")
                                                        
                                                        let dateFormatter = DateFormatter()
                                                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                                                        let currentTime = dateFormatter.string(from: Date())
                                                        
                                                        APIManagers.shared.AllTime_callNotificationAPI(playerid: playerID, prompt: self.promptText!)
                                                    } else {
                                                        print("Failed to obtain OneSignal Device ID")
                                                    }
                                                } else {
                                                    print("Failed to obtain player ID")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        self.apiResponse = "I am sorry, This is out of topic.\nPlease enter income-expense related notes only."
                    }
                    
                    DispatchQueue.main.async {
                        self.tblmessage.reloadRows(at: [IndexPath(row: 1, section: 0)], with: .none)
                        
                        if type.lowercased() == "income" || type.lowercased() == "expense" || type.lowercased() == "lending" || type.lowercased() == "borrowing" || !category.isEmpty || amount != 0 || !note.isEmpty {
                            // Post a notification with the updated data
                            let userInfo: [String: Any] = [
                                "type": type,
                                "amount": amount,
                                "category": category,
                                "note": note,
                                //"date": formattedDate
                            ]
                            
                            NotificationCenter.default.post(name: Notification.Name("DataUpdateNotification"), object: nil, userInfo: userInfo)
                            self.mainSheetVC?.retrieveData()
                        }
                    }
                }
            } else {
                CustomToast.toastMessage(message: "Please Connect Your Internet", type: .ERROR)
            }
        } else {
            CustomToast.toastMessage(message: "TRY AGAIN", type: .ERROR)
        }
        view.endEditing(true)
    }
    
    func getDeviceID() -> String? {
        let device = UIDevice.current
        return device.identifierForVendor?.uuidString
    }
    
    func getOneSignalPlayerID(completion: @escaping (String?) -> Void) {
        // Prompt the user for push notification permission
        //OneSignal.promptForPushNotifications(userResponse: { accepted in
           // if accepted {
                // If the user accepts, retrieve the OneSignal player ID
                guard let oneSignal = OneSignal.User.pushSubscription.id else {
                    print("Failed to retrieve OneSignal player ID")
                    completion(nil)
                    return
                }
                
                // Use the playerID as needed
                print("OneSignal player ID: \(oneSignal)")
                completion(oneSignal)
//            } else {
//                // If the user rejects push notification permission
//                print("User rejected push notification permission")
//                completion(nil)
           // }
        //})
    }
    
    func notificationSwitchDidChange(isOn: Bool) {
        // Handle the switch state change
        if isOn {
            // Switch is ON
            // Perform actions when the switch is ON
            // Call API, etc.
        } else {
            // Switch is OFF
        }
    }
    
    func saveTransaction(type: String, category: String, note: String, amount: Int, date: Date, prompt: String, time: String, notification_id: Int) {
        DispatchQueue.main.async {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
            let managedContext = appDelegate.persistentContainer.viewContext
            
            guard let mainEntity = NSEntityDescription.entity(forEntityName: "Main", in: managedContext) else { return }
            let newMain = NSManagedObject(entity: mainEntity, insertInto: managedContext)
            
            // Set a unique identifier as an integer (assuming "primarykey" is an Integer 32 attribute)
            let uniqueIdentifier = Int.random(in: 1...Int.max) // Generate a unique integer
            newMain.setValue(uniqueIdentifier, forKey: "primarykey")
            
            newMain.setValue(type, forKey: "type")
            
            // Capitalize the first letter and convert the rest to lowercase
            let formattedCategory = category.prefix(1).capitalized + category.dropFirst().lowercased()
            newMain.setValue(formattedCategory, forKey: "category")
            
            newMain.setValue(note, forKey: "note")
            newMain.setValue(Date(), forKey: "date")
            newMain.setValue(amount, forKey: "amount")
            newMain.setValue(prompt, forKey: "prompt")
            newMain.setValue(time, forKey: "time")
            newMain.setValue(notification_id, forKey: "notification_id") // Assign the notification ID
            
            print("Note:--- \(note)")
            print("Date:--- \(date)")
            print("Amount:--- \(amount)")
            print("Prompt:--- \(prompt)")
            print("Primary:--- \(uniqueIdentifier)")
            
            // Saving the context
            do {
                try managedContext.save()
                CustomToast.toastMessage(message: "Transaction Saved Successfully", type: .SUCCESS)
            } catch {
                print("Error saving context: \(error)")
            }
        }
    }
}

extension UIColor {
    convenience init(hex: Int, alpha: CGFloat = 1.0) {
        self.init(
            red: CGFloat((hex >> 16) & 0xFF) / 255.0,
            green: CGFloat((hex >> 8) & 0xFF) / 255.0,
            blue: CGFloat(hex & 0xFF) / 255.0,
            alpha: alpha
        )
    }
}

extension ChatMessageVC:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblmessage.dequeueReusableCell(withIdentifier: "MsgTableViewCell", for: indexPath) as! MsgTableViewCell
        cell.backgroundColor = .clear
        
        if indexPath.row == 0 {
            cell.configureCell(message: messageValue, alignment: .right)
            //cell.configureImage(imageName: "Ellipse 139")
            cell.lblchat.text = messageValue
        } else if indexPath.row == 1 {
            cell.lblchat.text = apiResponse
            //cell.configureCell(message: apiResponse, alignment: .left)
            cell.lblchat.numberOfLines = 0
            //cell.configureImage(imageName: "Ellipse 19")
            cell.lblchat.lineBreakMode = .byWordWrapping
        } else {
            cell.lblchat.text = "Row \(indexPath.row + 1)"
        }
        
        if indexPath.row % 2 == 0 {
            // Display message on the right side
            cell.lblchat.textAlignment = .left
        } else {
            // Display message on the left side
            cell.lblchat.textAlignment = .left
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 50.0
        }else {
            return 120.0
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200.0 // Adjust the estimated height based on your cell content
    }
}

