//
//  TermsConditionAlertVC.swift
//  AIMoneyTracker
//
//  Created by Apple on 16/05/24.
//

import UIKit

class TermsConditionAlertVC: UIViewController {

    @IBOutlet weak var customview: UIView!
    @IBOutlet weak var topview: UIView!
    @IBOutlet weak var mainview: MainGradientView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.alpha = 0
        customview.transform = CGAffineTransform(scaleX: 0, y: 0)
        topview.roundTopCorners(cornerRadius: 30)
        customview.layer.cornerRadius = 30.0
        mainview.layer.cornerRadius = 30.0
        topview.addBottomBorder(color: UIColor(hex: "AEB5C0"), borderWidth: 1)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showAnimation(isShow: true)
    }
    
    func showAnimation(isShow: Bool, completion: (() -> Void)? = nil) {
        UIView.animate(withDuration: 0.40, delay: 0, options: .curveEaseOut, animations: {
            self.customview.transform = isShow ? .identity : CGAffineTransform(scaleX: 0.01, y: 0.01)
            self.view.alpha = isShow ? 1 : 0
        }, completion: { _ in
            if !isShow {
                self.dismiss(animated: false, completion: completion)
            }
        })
    }
    
    @IBAction func click_btnhidescreen(_ sender: Any) {
        showAnimation(isShow: false) {

        }
    }
    
    @IBAction func click_ok(_ sender: Any) {
        showAnimation(isShow: false) {

        }
    }
}
