//
//  AddSuspenseVC.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import DropDown
import CoreData

protocol AddSuspenseVCDelegate: AnyObject {
    // func didFinishAddingSuspense(incomeSaved: Bool)
    func didAddDataToHistory()
}

protocol SwitchDelegate: AnyObject {
    func switchStatusChanged(isOn: Bool)
}

class AddSuspenseVC: UIViewController, UITextFieldDelegate {
    
    var history: [NSManagedObject] = []
    weak var delegateSwitch: SwitchDelegate?
    //var bottomSheetVC: BottomSheetVC?
    let transparentView = UIView()
    let tableview = UITableView()
    //var main = PersonalExpVC()
    //weak var bottom: BottomSheetVC?
    weak var historyViewController: HistoryViewController?
    weak var delegate: AddSuspenseVCDelegate?
    
    var his = HistoryViewController()
    
    @IBOutlet weak var txtcategory: UITextField!
    @IBOutlet weak var txtamount: UITextField!
    @IBOutlet weak var lblselect: UILabel!
    @IBOutlet weak var vwdropdown: UIView!
    @IBOutlet weak var txtnote: UITextField!
    @IBOutlet weak var lblnotereal: UILabel!
    @IBOutlet weak var btn_red_edit_history: MyButton!
    @IBOutlet weak var btn_blue_edit_suspense: MyButton!
    @IBOutlet weak var lblprimary: UILabel!
    @IBOutlet weak var customview: UIView!
    @IBOutlet weak var topview: UIView!
    @IBOutlet weak var mainview: MainGradientView!
    
    var isBlueButtonHidden = false
    var passedValue: String?
    var passedamount: Int?
    var passedcategory: String?
    var passednote: String?
    var passedrealnote: String?
    var passedtype: String?
    var passedprompt: String?
    var passedprimary: Int?
    var notification_id: Int?
    
    @IBOutlet weak var lblprompt: UILabel!
    var cellID: Int?
    //weak var delegate: AddSuspenseVCDelegate?
    
    let dropDown = DropDown()
    let dropdownValue = ["Income", "Expense", "Lending", "Borrowing"]
    
    private var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MoneyManagerBudgetCopilot")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // lblprimary.isHidden = true
        NotificationCenter.default.addObserver(self, selector: #selector(handleDataUpdatedNotification), name: NSNotification.Name("DataUpdatedNotification"), object: nil)
        btn_blue_edit_suspense.isHidden = isBlueButtonHidden
        btn_red_edit_history.isHidden = !isBlueButtonHidden
        
        txtnote.delegate = self
        txtamount.delegate = self
        txtcategory.delegate = self
        
        //scroll.isScrollEnabled = true
        //tblsuspense.backgroundColor = .clear
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tapGesture)
        registerForKeyboardNotifications()
        view.alpha = 0
        customview.transform = CGAffineTransform(scaleX: 0, y: 0)
        topview.roundTopCorners(cornerRadius: 30)
        customview.layer.cornerRadius = 30.0
        mainview.layer.cornerRadius = 30.0
        topview.addBottomBorder(color: UIColor(hex: "AEB5C0"), borderWidth: 1)
        
        dropDown.anchorView = vwdropdown
        dropDown.dataSource = dropdownValue
        dropDown.bottomOffset = CGPoint(x: 0, y: (dropDown.anchorView?.plainView.bounds.height)!)
        dropDown.topOffset = CGPoint(x: 0, y: -(dropDown.anchorView?.plainView.bounds.height)!)
        dropDown.direction = .bottom
        dropDown.selectionAction = { [unowned self]
            (index: Int, item: String) in
            self.lblselect.text = dropdownValue[index]
        }
        if let lblname = passedValue {
            print(lblname,"....name")
            lblprompt.text = lblname
            // Use the lblname value as needed
            // ...
        } else {
            // Handle the case when lblnote.text is nil
        }
        
        if let lblprimary1 = passedprimary {
            print(lblprimary1, "....name")
            lblprimary.text = String(lblprimary1) // Convert Int to String before setting as text
            // Use the lblprimary1 value as needed
            // ...
        } else {
           
        }
        
        if let lblnotes = passednote {
            print(lblnotes)
            txtnote.text = lblnotes
            // Use the lblname value as needed
            // ...
        } else {
            // Handle the case when lblnote.text is nil
        }
        if let lblcategory = passedcategory {
            print(lblcategory)
            txtcategory.text = lblcategory
            // Use the lblname value as needed
            // ...
        } else {
            // Handle the case when lblnote.text is nil
        }
        
        if let lblpro = passedprompt {
            print(lblpro)
            lblprompt.text = lblpro
            // Use the lblname value as needed
            // ...
        } else {
            // Handle the case when lblnote.text is nil
        }
        
        if let lblamount = passedamount {
            print(lblamount)
            txtamount.text = String(lblamount)
            // Use the lblname value as needed
            // ...
        } else {
            // Handle the case when lblnote.text is nil
        }
        if let lblrealnote1 = passedrealnote {
            print(lblrealnote1)
            lblnotereal.text = lblrealnote1
            // Use the lblname value as needed
            // ...
        } else {
            // Handle the case when lblnote.text is nil
        }
        if let lbltype = passedtype {
            print(lbltype)
            lblselect.text = lbltype
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showAnimation(isShow: true)
    }
    
    func showAnimation(isShow: Bool, completion: (() -> Void)? = nil) {
        UIView.animate(withDuration: 0.40, delay: 0, options: .curveEaseOut, animations: {
            self.customview.transform = isShow ? .identity : CGAffineTransform(scaleX: 0.01, y: 0.01)
            self.view.alpha = isShow ? 1 : 0
        }, completion: { _ in
            if !isShow {
                self.dismiss(animated: false, completion: completion)
            }
        })
    }
    
    func registerForKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        UIView.animate(withDuration: 0.3) {
            self.customview.transform = .identity
        }
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardFrame: NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardHeight = keyboardFrame.cgRectValue.height
            let bottomSpace = self.view.frame.height - (customview.frame.origin.y + customview.frame.height)
            if bottomSpace < keyboardHeight {
                UIView.animate(withDuration: 0.3) {
                    self.customview.transform = CGAffineTransform(translationX: 0, y: -(keyboardHeight - bottomSpace + 15)) // Additional 20px space
                }
            }
        }
    }
    
    @objc func handleDataUpdatedNotification() {
        //tblsuspense.reloadData()
        // Reload your page or perform any other action needed
        // For reloading the page, you can dismiss and present the AddSuspenseVC again
        showAnimation(isShow: true) {
            let addSuspenseVC = self.storyboard?.instantiateViewController(withIdentifier: "AddSuspenseVC") as! AddSuspenseVC
            addSuspenseVC.modalPresentationStyle = .fullScreen
            // Configure any values you need to pass
            // ...
            self.present(addSuspenseVC, animated: true, completion: nil)
        }
//        dismiss(animated: true) {
//            let addSuspenseVC = self.storyboard?.instantiateViewController(withIdentifier: "AddSuspenseVC") as! AddSuspenseVC
//            addSuspenseVC.modalPresentationStyle = .fullScreen
//            // Configure any values you need to pass
//            // ...
//            self.present(addSuspenseVC, animated: true, completion: nil)
//        }
    }
    
    func showToast(message: String) {
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
        toastLabel.backgroundColor = UIColor.red.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.black
        toastLabel.font = UIFont.systemFont(ofSize: 12)
        toastLabel.textAlignment = .center
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true
        self.view.addSubview(toastLabel)
        
        UIView.animate(withDuration: 3.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
    

    @objc func handleTap() {
        // Resign the first responder status of the active text field (dismiss the keyboard)
        view.endEditing(true)
    }
    
    // Implement the UITextFieldDelegate method to dismiss the keyboard when the Return key is pressed
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtnote.resignFirstResponder()
        txtamount.resignFirstResponder()
        txtcategory.resignFirstResponder()
        return true
    }
    
    @IBAction func clcikdropdown(_ sender: Any) {
        dropDown.show()
    }
    
    @IBAction func btnhidescreen(_ sender: Any) {
        self.showAnimation(isShow: false)
    }
    
    @IBAction func click_cancel(_ sender: Any) {
        self.showAnimation(isShow: false)
    }
    
    func updateTransactionWithNewValues(primarykey: Int, newCategory: String, newNote: String, newDate: Date, newAmount: Int, newType: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext

        let fetchRequest: NSFetchRequest<Main> = Main.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "primarykey == %d", primarykey)

        do {
            let transactions = try managedContext.fetch(fetchRequest)
            if let existingTransaction = transactions.first {
                existingTransaction.setValue(newCategory, forKey: "category")
                existingTransaction.setValue(newNote, forKey: "note")
                existingTransaction.setValue(newDate, forKey: "date")
                existingTransaction.setValue(newAmount, forKey: "amount")
                existingTransaction.setValue(newType, forKey: "type")

                // Save the context to persist the changes
                try managedContext.save()
                print("Transaction updated successfully.")
                NotificationCenter.default.post(name: NSNotification.Name("DataUpdatedNotification"), object: nil)
            } else {
                print("Transaction not found.")
                // Show an alert or handle the error gracefully here
            }
        } catch {
            print("Error updating transaction: \(error)")
            // Show an alert or handle the error gracefully here
        }
    }

    @IBAction func btnsave(_ sender: Any) {
        if let primarykeyText = lblprimary.text, let primarykey = Int(primarykeyText) {
            let type = lblselect.text!
            let category = txtcategory.text!
            let note = txtnote.text!
            let date = Date()
            
            if let amountText = txtamount.text, let amounts = Int(amountText) {
                updateTransactionWithNewValues(
                    primarykey: primarykey,
                    newCategory: category,
                    newNote: note,
                    newDate: date,
                    newAmount: amounts,
                    newType: type
                )
                
                let userInfo: [String: Any] = [
                    "type": lblselect.text ?? "",
                    "amount": amounts,
                    "category": category,
                    "note": note
                ]
                //delegate?.didAddDataToHistory(updatedData: userInfo)
             NotificationCenter.default.post(name: Notification.Name("DataUpdateHistory"), object: nil, userInfo: userInfo)
             
            APIManagers.shared.Delete_callNotificationAPI(id: notification_id!)
               // tblsuspense.reloadData()
                
                // Notify the delegate that new data has been added to history
                delegate?.didAddDataToHistory()
                self.showAnimation(isShow: false)
                CustomToast.toastMessage(message: "Data Updated Successfully", type: .SUCCESS)
               // navigationController?.popViewController(animated: true)
            } else {
                print("Invalid amount format")
                // Handle the case where the amount is not a valid integer
            }
        } else {
            print("Invalid primary key format")
            // Handle the case where lblprimary.text is not a valid integer
        }
    }
}


