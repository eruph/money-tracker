//
//  SuggestionTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class SuggestionTableViewCell: UITableViewCell {

    @IBOutlet weak var lblsuggestionnumber: UILabel!
    @IBOutlet weak var lbltime: UILabel!
    @IBOutlet weak var lblsuggestion: UILabel!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var btndelete: UIButton!
    
    var onDeleteTapped: (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func click_delete(_ sender: Any) {
        onDeleteTapped?()
    }

}
