//
//  IncExpTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class IncExpTableViewCell: UITableViewCell {

    @IBOutlet weak var lbltype: UILabel!
    @IBOutlet weak var lblamount: UILabel!
    @IBOutlet weak var lblnote: UILabel!
    @IBOutlet weak var lbldate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
