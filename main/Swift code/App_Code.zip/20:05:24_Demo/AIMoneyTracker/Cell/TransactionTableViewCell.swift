//
//  TransactionTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 13/10/23.
//

import UIKit

class TransactionTableViewCell: UITableViewCell {

    @IBOutlet weak var lblamount: UILabel!
    @IBOutlet weak var lblnote: UILabel!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var uiview: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected st ate
    }

}
