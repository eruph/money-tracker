//
//  HistoryTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class HistoryTableViewCell: UITableViewCell {
    
    var addButtonAction: ((_ index: Int) -> Void)?
    var deleteButtonAction: ((_ index:Int) -> Void)?
    
    @IBOutlet weak var btndelete: UIButton!
    @IBOutlet weak var btnedit: UIButton!
    @IBOutlet weak var lblamount: UILabel!
    @IBOutlet weak var lbltype: UILabel!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var lblcategory: UILabel!
    @IBOutlet weak var lblprompt: UILabel!
    @IBOutlet weak var lblnote: UILabel!
    
    @IBOutlet weak var lblprimary: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        lblprimary.isHidden = true
        lblnote.isHidden = true
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    @IBAction func click_edit(_ sender: UIButton) {
        addButtonAction?(sender.tag)
    }
    
    @IBAction func click_delete(_ sender: UIButton) {
        deleteButtonAction?(sender.tag)
        //            let noteToDelete = lblnote.text!
        //
        //            deleteTransactionWithNote(noteToDelete: noteToDelete)
        //
    }
}
