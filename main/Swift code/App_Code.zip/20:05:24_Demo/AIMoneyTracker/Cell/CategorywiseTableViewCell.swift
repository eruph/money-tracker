//
//  CategorywiseTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class CategorywiseTableViewCell: UITableViewCell {

    @IBOutlet weak var lblamount: UILabel!
    @IBOutlet weak var lblcategoryname: UILabel!
    @IBOutlet weak var imgcategory: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
