//
//  MonthlyBudgetTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class MonthlyBudgetTableViewCell: UITableViewCell {

    @IBOutlet weak var btnedit: UIButton!
    @IBOutlet weak var lbl_left_amount: UILabel!
    @IBOutlet weak var lbl_total_amount: UILabel!
    @IBOutlet weak var monthname: UILabel!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var lblremaning: UILabel!
    @IBOutlet weak var btn_delete: UIButton!
    
    var editButtonAction: (() -> Void)?
    var deleteButtonAction: (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        lbl_total_amount.sizeToFit()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func editButtonTapped(_ sender: Any) {
            editButtonAction?()
        }
    
    @IBAction func deleteButtonTapped(_ sender: Any) {
            deleteButtonAction?()
        }
    
   
}
