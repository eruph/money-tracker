//
//  MainTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//
import UIKit

class MainTableViewCell: UITableViewCell {

    var addButtonAction: ((_ index: Int) -> Void)?
    var deleteButtonAction: ((_ index:Int) -> Void)?
    
    @IBOutlet weak var lblnote: UILabel!
    @IBOutlet weak var lblcategory: UILabel!
    @IBOutlet weak var lbltype: UILabel!
    @IBOutlet weak var lblamount: UILabel!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var btndelete: UIButton!
    @IBOutlet weak var btnedit: UIButton!
    @IBOutlet weak var lblprompt: UILabel!
    @IBOutlet weak var lblprimarykey: UILabel!
    @IBOutlet weak var lbltime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        lblprompt.isHidden = true
        lblprimarykey.isHidden = true
        lbltype.isHidden = true
        lblcategory.isHidden = true
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func editButtonTapped(_ sender: UIButton) {
        //editButtonAction?()
        //delegate?.didTapEditButton(cellID: cellID!)
        addButtonAction?(sender.tag)
    }
    
    @IBAction func deleteButtonTapped(_ sender: UIButton) {
        deleteButtonAction?(sender.tag)
    }

}

