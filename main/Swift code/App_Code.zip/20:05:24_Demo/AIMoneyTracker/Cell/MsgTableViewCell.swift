//
//  MsgTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class MsgTableViewCell: UITableViewCell {
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var msg_view: UIView!
    @IBOutlet weak var lblchat: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //msg_view.backgroundColor  = .blue
        lblchat.numberOfLines = 0
        lblchat.translatesAutoresizingMaskIntoConstraints = false
        lblchat.sizeToFit()
        
        let constraints = [lblchat.topAnchor.constraint(equalTo: topAnchor, constant: 16),
                           lblchat.leadingAnchor.constraint(equalTo: leadingAnchor,constant: 16),
                           lblchat.bottomAnchor.constraint(equalTo: bottomAnchor,constant: -16),
                           lblchat.widthAnchor.constraint(equalToConstant: 250)]
        
        NSLayoutConstraint.activate(constraints)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func configureCell(message: String, alignment: NSTextAlignment) {
        lblchat.text = message
        lblchat.textAlignment = alignment
        lblchat.sizeToFit()
        
        // Set initial properties for animation
        lblchat.alpha = 0.0
        lblchat.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        
        // Animate label appearance
        UIView.animate(withDuration: 0.5, delay: 0.0, options: [.curveEaseInOut], animations: {
            // Set final properties for animation
            self.lblchat.alpha = 1.0
            self.lblchat.transform = .identity
        }, completion: nil)
    }
    
    func configureImage(imageName: String) {
            if let image = UIImage(named: imageName) {
                img.image = image
            } else {
                // Handle the case when the image is not found
                print("Image not found")
            }
        }
}
