//
//  ExpenseTableViewCell.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class ExpenseTableViewCell: UITableViewCell {

    var addButtonAction: ((_ index: Int) -> Void)?
    var deleteButtonAction: ((_ index:Int) -> Void)?
    
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var lbl_type: UILabel!
    @IBOutlet weak var lbl_cateogry: UILabel!
    @IBOutlet weak var btn_edit: UIButton!
    @IBOutlet weak var btn_close: UIButton!
    @IBOutlet weak var lbl_amount: UILabel!
    @IBOutlet weak var lblnote: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func editButtonTapped(_ sender: UIButton) {
        //editButtonAction?()
        //delegate?.didTapEditButton(cellID: cellID!)
        addButtonAction?(sender.tag)
    }
    
    @IBAction func deleteButtonTapped(_ sender: UIButton) {
        deleteButtonAction?(sender.tag)
    }

}

