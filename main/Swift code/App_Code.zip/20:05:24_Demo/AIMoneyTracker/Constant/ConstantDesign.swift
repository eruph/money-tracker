//
//  ConstantDesign.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import Foundation
import UIKit

@IBDesignable class CardView : UIView {
    var cornerRadius: CGFloat = 10
    var ofsetWidth: CGFloat = 7
    var ofsetHeight: CGFloat = 7
    
    //var ofsetShadowOpacity: Float = 5
    var color = UIColor.white
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        layer.cornerRadius = cornerRadius
        layer.shadowColor = color.cgColor
        layer.shadowOffset = CGSize(width: ofsetWidth, height: ofsetHeight)
        layer.shadowOpacity = 0.5 // Adjust the shadow opacity if needed
        layer.shadowRadius = 5 // Adjust the shadow radius if needed
        layer.shadowPath = UIBezierPath(roundedRect: bounds.insetBy(dx: ofsetWidth, dy: ofsetHeight), cornerRadius: cornerRadius).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        layer.borderWidth = 0.5
        layer.borderColor = UIColor.black.cgColor
    }
}

@IBDesignable class CardViewSuggestion : UIView {
    var cornerRadius: CGFloat = 10
    var ofsetWidth: CGFloat = 10
    var ofsetHeight: CGFloat = 7
    
    //var ofsetShadowOpacity: Float = 5
    var color = UIColor.white
    
    
    override func layoutSubviews() {
        layer.cornerRadius = self.cornerRadius
        layer.shadowColor = self.color.cgColor
        layer.shadowOffset = CGSize(width: self.ofsetWidth, height: self.ofsetHeight)
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: self.cornerRadius).cgPath
        layer.borderColor = UIColor.black.cgColor
        layer.borderWidth = 1.0
        //layer.shadowOpacity = self.ofsetShadowOpacity
    }
}

@IBDesignable class CardViewStraight: UIView {
    var cornerRadius: CGFloat = 10
    var offsetWidth: CGFloat = 10
    var offsetHeight: CGFloat = 7
    
    var color: UIColor = .white  // You can set a default color

    override func layoutSubviews() {
        //layer.cornerRadius = cornerRadius
        layer.shadowColor = color.cgColor // Convert UIColor to CGColor
        layer.shadowOffset = CGSize(width: offsetWidth, height: offsetHeight)
        //layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius).cgPath
        layer.borderColor = UIColor(hex: "dedede").cgColor // Convert UIColor to CGColor
        layer.borderWidth = 2.0
    }
}

class CurvedCornerView1: UIView {
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // Define the curve radius
        let curveRadius: CGFloat = 10.0
        
        // Create a path for the curved corners
        let path = UIBezierPath(
            roundedRect: bounds,
            byRoundingCorners: [.topRight, .topLeft],
            cornerRadii: CGSize(width: curveRadius, height: curveRadius)
        )
        
        // Create a shape layer
        let maskLayer = CAShapeLayer()
        maskLayer.path = path.cgPath
        
        // Apply the mask to the view's layer
        layer.mask = maskLayer
        
        // Add a black border to the view
        layer.borderColor = UIColor.black.cgColor
        layer.borderWidth = 1.0 // Adjust the border width as needed
    }
}


@IBDesignable class CardViewNoBorder: UIView {
    @IBInspectable var cornerRadius: CGFloat = 20
    @IBInspectable var shadowOffsetWidth: CGFloat = 7
    @IBInspectable var shadowOffsetHeight: CGFloat = 7
    //@IBInspectable var shadowOpacity: Float = 5
    @IBInspectable var shadowColor: UIColor = UIColor.white
    @IBInspectable var cornerCurveColor: UIColor = UIColor.gray // New property for corner curve color
    
    override func layoutSubviews() {
        layer.cornerRadius = cornerRadius
        layer.shadowColor = shadowColor.cgColor
        layer.shadowOffset = CGSize(width: shadowOffsetWidth, height: shadowOffsetHeight)
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius).cgPath
        
        // Set the color of the corner curve
        layer.borderColor = cornerCurveColor.cgColor
        
        // Remove the border width to have no border
        layer.borderWidth = 0.0
        //layer.shadowOpacity = shadowOpacity
    }
}

@IBDesignable class CardViewBottomBorder: UIView {
    var ofsetHeight: CGFloat = 1
    var color = UIColor.black

    override func layoutSubviews() {
        layer.shadowColor = self.color.cgColor
        layer.shadowOffset = CGSize(width: 0, height: self.ofsetHeight)
        layer.shadowRadius = 3
        layer.shadowOpacity = 0.5
        layer.masksToBounds = false
        clipsToBounds = false
    }
}

@IBDesignable class CardViewNoBorderAnalysis : UIView {
    var ofsetWidth: CGFloat = 7
    var ofsetHeight: CGFloat = 7
    
    //var ofsetShadowOpacity: Float = 5
    var color = UIColor.white
    
    
    override func layoutSubviews() {
        layer.shadowColor = color.cgColor
        layer.shadowOffset = CGSize(width: ofsetWidth, height: ofsetHeight)
        layer.borderWidth = 0.5
        layer.borderColor = UIColor.black.cgColor
        layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner] // Rounded top corners

        // If you want to add a shadow, uncomment the following lines
        // layer.shadowOpacity = 0.5
        // layer.shadowRadius = 2.0
        // layer.shadowOffset = CGSize(width: 0, height: 2)
        // layer.masksToBounds = false
    }
}

@IBDesignable class CardView1 : UIView {
    var cornerRadius: CGFloat = 18
    var ofsetWidth: CGFloat = 7
    var ofsetHeight: CGFloat = 7
    
    //var ofsetShadowOpacity: Float = 5
    var color = UIColor.white
    
    
    override func layoutSubviews() {
        layer.cornerRadius = self.cornerRadius
        layer.shadowColor = self.color.cgColor
        layer.shadowOffset = CGSize(width: self.ofsetWidth, height: self.ofsetHeight)
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: self.cornerRadius).cgPath
        layer.borderColor = UIColor.black.cgColor // Convert UIColor to CGColor
        layer.borderWidth = 0.4
        //layer.shadowOpacity = self.ofsetShadowOpacity
    }
}

@IBDesignable class CardViewRound : UIView {
    var cornerRadius: CGFloat = 20
    var ofsetWidth: CGFloat = 7
    var ofsetHeight: CGFloat = 7
    
    //var ofsetShadowOpacity: Float = 5
    var color = UIColor.white
    
    
    override func layoutSubviews() {
        layer.cornerRadius = self.cornerRadius
        layer.shadowColor = self.color.cgColor
        layer.shadowOffset = CGSize(width: self.ofsetWidth, height: self.ofsetHeight)
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: self.cornerRadius).cgPath
        layer.borderColor = UIColor.black.cgColor
        layer.borderWidth = 0.5
        //layer.shadowOpacity = self.ofsetShadowOpacity
    }
}

@IBDesignable class MyButton: UIButton
{
    override func layoutSubviews() {
        super.layoutSubviews()
        
        updateCornerRadius()
    }
    
    @IBInspectable var rounded: Bool = false {
        didSet {
            updateCornerRadius()
        }
    }
    
    func updateCornerRadius() {
        layer.cornerRadius = rounded ? frame.size.height / 4 : 0
    }
}

