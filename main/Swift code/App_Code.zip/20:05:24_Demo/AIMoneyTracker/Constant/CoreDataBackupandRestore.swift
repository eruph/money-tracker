//
//  CoreDataBackupandRestore.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 14/10/23.
//

import Foundation
import UIKit
import CoreData
import SQLite3

struct BackupData: Codable {
    let amount: Int
    let category: String
    let type: String
    let date: Date
    let note: String
}

class CoreDataBackupManager {
    // Backup CoreData data to a file
    static func backupDataToFile() -> URL? {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return nil }
        let persistentContainer = appDelegate.persistentContainer
        
        let boldTextAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 14)
        ]
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        do {
            var backupData: [String] = []
            
            // Fetch data from the Main table
            let mainFetchRequest: NSFetchRequest<Main> = Main.fetchRequest()
            let mainData = try persistentContainer.viewContext.fetch(mainFetchRequest)
            
            // Add a title row for Main data
            let mainTitle = NSAttributedString(string: "BackUp Of AIMoneyTracker", attributes: boldTextAttributes)
            backupData.append(mainTitle.string)
            
            // Add the main data rows
            backupData.append(contentsOf: mainData.map { data in
                let formattedDate = dateFormatter.string(from: data.date ?? Date())
                return "\(data.amount),\(data.category ?? ""),\(formattedDate),\(data.note ?? ""),\(data.type ?? ""),\(data.primarykey),\(data.prompt ?? ""),\(data.time ?? "")"
            })
            
            // Join the backup data rows with line breaks
            let dataString = backupData.joined(separator: "\n")
            
            // Convert the dataString to Data
            guard let data = dataString.data(using: .utf8) else {
                print("Failed to convert dataString to Data.")
                return nil
            }
            
            // Save data to a .txt file
            let fileManager = FileManager.default
            let documentsDirectory = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let fileURL = documentsDirectory.appendingPathComponent("backupData.txt")
            try data.write(to: fileURL)
            
            print("Data backup completed. File saved at: \(fileURL)")
            return fileURL
        } catch {
            print("Failed to backup data: \(error.localizedDescription)")
            return nil
        }
    }
    
    // Restore CoreData data from a file
    
    static func restoreDataFromBackup(fileURL: URL) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            print("Failed to get the AppDelegate.")
            return
        }
        
        let persistentContainer = appDelegate.persistentContainer
        
        do {
            let fileData = try Data(contentsOf: fileURL)
            guard let fileString = String(data: fileData, encoding: .utf8) else {
                print("Failed to convert file data to string.")
                return
            }
            
            let rows = fileString.components(separatedBy: "\n")
            var currentEntityName: String?
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            
            for row in rows {
                if row.isEmpty {
                    continue
                }
                
                if row.hasSuffix(":") {
                    currentEntityName = String(row.dropLast())
                } else {
                    if let entityName = currentEntityName, entityName == "Main" {
                        let dataComponents = row.components(separatedBy: ",")
                        
                        if dataComponents.count == 8 {
                            let newMain = Main(context: persistentContainer.viewContext)
                            newMain.amount = Int32(dataComponents[0]) ?? 0
                            newMain.category = dataComponents[1]
                            newMain.date = dateFormatter.date(from: dataComponents[2])
                            newMain.note = dataComponents[3]
                            newMain.type = dataComponents[4]
                            newMain.primarykey = Int16(dataComponents[5]) ?? 0
                            newMain.prompt = dataComponents[6]
                            newMain.time = dataComponents[7]
                        }
                    }
                }
            }
            
            try persistentContainer.viewContext.save()
            print("Data restore completed.")
        } catch {
            print("Failed to restore data: \(error.localizedDescription)")
        }
    }
}
