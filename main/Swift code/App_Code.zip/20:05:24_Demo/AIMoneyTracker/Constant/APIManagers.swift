//
//  APIManagers.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 12/10/23.
//

import Foundation
import UIKit
import Foundation
import Alamofire
import Firebase
import FirebaseRemoteConfig

enum APIErrors: Error {
    case custom(message: String)
}

//typealias Handler = (Swift.Result<Any?, APIErrors>) -> Void
typealias Handler = (String, Int, String, String) -> Void
typealias ErrorHandler = (Error) -> Void

typealias Handler1 = (String, Int, String, String, String) -> Void


class APIManagers {
    
    static let shared = APIManagers()
    
    //    func fetchApiKeyFromRemoteConfig(completion: @escaping (String?) -> Void) {
    //        let remoteConfig = RemoteConfig.remoteConfig()
    //
    //        // Define default values for your keys
    //        let remoteConfigDefaults: [String: NSObject] = [
    //            "api_key": "default_api_key" as NSObject
    //        ]
    //        remoteConfig.setDefaults(remoteConfigDefaults)
    //
    //        remoteConfig.fetch { (status, error) in
    //            if status == .success {
    //                remoteConfig.activate { (_, _) in
    //                    let apiKey = remoteConfig["api_key"].stringValue
    //                    completion(apiKey)
    //                }
    //            } else {
    //                print("Error fetching remote config: \(error?.localizedDescription ?? "Unknown error")")
    //                completion(nil)
    //            }
    //        }
    //    }
    //
    //    func callAPI(with prompt: String, completion: @escaping Handler) {
    //        let url = URL(string: "https://api.openai.com/v1/chat/completions")!
    //
    //        let accessToken = "Bearer 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"
    //
    //        var request = URLRequest(url: url)
    //        request.httpMethod = "POST"
    //        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    //        request.setValue(accessToken, forHTTPHeaderField: "Authorization")
    //
    //        let requestBody: [String: Any] = [
    //            "model": "gpt-3.5-turbo",
    //            "messages": [
    //                [
    //                    "role": "user",
    //                    "content": "\(prompt). User's transaction note is \(prompt) Response format: type:income or expense or NA, amount: amount of transaction or 0, category: subcategory of transaction or NA, note: Transaction short note or NA (do not write a full line in note), give only json"
    //
    //                    //                                        "content": "User's transaction note is \(prompt), Response format: type:income or expense, amount: amount of transaction or NA, category: subcategory of transaction or NA, note: Transaction short note or NA (do not write a full line in note), give only json"
    //
    //                    //                    "content": "summarizing the income and expanse from user's note:user's note for income or expanse or Na , note is \(prompt),Response format: type:income or expense or Na , amount: amount of transaction or  0 , category: subcategory of transaction or Na or If you can't extract it, you output NA, note: Transaction Description or Na or If you can't extract it, you output NA, give only json"
    //                ]
    //            ]
    //        ]
    //
    //        do {
    //            let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
    //            request.httpBody = jsonData
    //
    //            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
    //                if let error = error {
    //                    print("Error: \(error)")
    //                    return
    //                }
    //
    //                if let httpResponse = response as? HTTPURLResponse {
    //                    if httpResponse.statusCode == 200 {
    //                        if let data = data {
    //                            do {
    //                                if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
    //                                   let choices = jsonResponse["choices"] as? [[String: Any]],
    //                                   let content = choices.first?["message"] as? [String: Any],
    //                                   let contentValue = content["content"] as? String {
    //                                    print(contentValue)
    //
    //                                    // Handle the API response content here
    //                                    if let jsonData = contentValue.data(using: .utf8) {
    //                                        do {
    //                                            if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
    //                                                // Process the JSON response
    //                                                let type = json["type"] as? String ?? ""
    //                                                let amount = json["amount"] as? Int ?? 0
    //                                                let category = json["category"] as? String ?? ""
    //                                                let note = json["note"] as? String ?? ""
    //
    //                                                // Use the extracted values as needed
    //                                                print("Type: \(type)")
    //                                                print("Amount: \(amount)")
    //                                                print("Category: \(category)")
    //                                                print("Note: \(note)")
    //
    //                                                // Call the completion handler with the extracted values
    //                                                completion(type, amount, category, note)
    //                                            }
    //                                        } catch {
    //                                            print("Error parsing JSON: \(error)")
    //                                        }
    //                                    }
    //                                }
    //                            } catch {
    //                                print("Error parsing JSON response: \(error)")
    //                            }
    //                        }
    //                    } else {
    //                        print("API request failed with status code: \(httpResponse.statusCode)")
    //                    }
    //                }
    //            }
    //
    //            task.resume()
    //
    //        } catch {
    //            print("Error serializing request body: \(error)")
    //        }
    //    }
    
    func fetchApiKeyFromRemoteConfig(completion: @escaping (String?) -> Void) {
        let remoteConfig = RemoteConfig.remoteConfig()
        
        // Define default values for your keys
        let remoteConfigDefaults: [String: NSObject] = [
            "api_key": "default_api_key" as NSObject
        ]
        remoteConfig.setDefaults(remoteConfigDefaults)
        
        remoteConfig.fetch { (status, error) in
            if status == .success {
                remoteConfig.activate { (_, _) in
                    let apiKey = remoteConfig["api_key"].stringValue
                    print("Fetched API Key: \(String(describing: apiKey))")
                    completion(apiKey)
                }
            } else {
                print("Error fetching remote config: \(error?.localizedDescription ?? "Unknown error")")
                completion(nil)
            }
        }
    }
    
    func callAPI(with prompt: String, completion: @escaping Handler) {
        // Fetch the API key from Remote Config
        fetchApiKeyFromRemoteConfig { apiKey in
            if let apiKey = apiKey {
                let url = URL(string: "https://api.openai.com/v1/chat/completions")!
                
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
                
                let requestBody: [String: Any] = [
                    "model": "gpt-3.5-turbo",
                    "messages": [
                        [
                            "role": "user",
                            "content": "summarizing the income, expense, lending, borrowing from transaction notes.\n(Example 1 \nTransaction note: I eat 100 rs burger.\nType : Expense\nAmount : 100\nCategory : Food\nShort Note : Eat Burger\nExample 2 \nTransaction note: I borrow 1000$ from Hiren\nType : Borrowing \nAmount : 1000\nCategory : Borrow \nShort Note : From Hiren \nExample 3\nTransaction note: get 5000 salary from company\nType : income\nAmount : 5000\nCategory : salary\nShort Note : earning from company)\n\nNow give me answer for Type , Amount ,Category , Short note.\nGive me answer in json format.\n\nTransaction Note is \(prompt)"
                        ],
                    ]
                ]
                
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
                    request.httpBody = jsonData
                    
                    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                        if let error = error {
                            print("Error: \(error)")
                            //completion(nil, 0, "", "")
                            return
                        }
                        
                        if let httpResponse = response as? HTTPURLResponse {
                            if httpResponse.statusCode == 200 {
                                if let data = data {
                                    do {
                                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                                        if let choices = jsonResponse?["choices"] as? [[String: Any]],
                                           let content = choices.first?["message"] as? [String: Any],
                                           let contentValue = content["content"] as? String {
                                            // Handle the API response content here
                                            if let jsonData = contentValue.data(using: .utf8) {
                                                do {
                                                    if let json = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                                        // Process the JSON response
                                                        let type = json["Type"] as? String ?? ""
                                                        let amount = json["Amount"] as? Int ?? 0
                                                        let category = json["Category"] as? String ?? ""
                                                        let note = json["Short Note"] as? String ?? ""
                                                        
                                                        
                                                        // Use the extracted values as needed
                                                        print("Type: \(type)")
                                                        print("Amount: \(amount)")
                                                        print("Category: \(category)")
                                                        print("Note: \(note)")
                                                        
                                                        // Call the completion handler with the extracted values
                                                        completion(type, amount, category, note)
                                                    }
                                                } catch {
                                                    print("Error parsing JSON: \(error)")
                                                    //completion(nil, 0, "", "")
                                                }
                                            }
                                        }
                                    } catch {
                                        print("Error parsing JSON response: \(error)")
                                        //completion(nil, 0, "", "")
                                    }
                                }
                            } else {
                                print("API request failed with status code: \(httpResponse.statusCode)")
                                //completion(nil, 0, "", "")
                            }
                        }
                    }
                    
                    task.resume()
                    
                } catch {
                    print("Error serializing request body: \(error)")
                    //completion(nil, 0, "", "")
                }
            } else {
                print("Failed to fetch API key from Remote Config.")
                //completion(nil, 0, "", "")
            }
        }
    }
    
    func callAPISuggestion(with prompt: String, completion: @escaping Handler1) {
        // Fetch the API key from Remote Config
        fetchApiKeyFromRemoteConfig { apiKey in
            if let apiKey = apiKey {
                let url = URL(string: "https://api.openai.com/v1/chat/completions")!
                
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
                
                let requestBody: [String: Any] = [
                    "model": "gpt-3.5-turbo",
                    "messages": [
                        [
                            "role": "user",
                            "content": "you are my expense and savings Advisor.\nI give my day-to-day expense notes.\nstudy it and give me one short suggestion or idea for increasing savings.\nday-to-day expense notes is \n demo : date,user's transaction note,amount,category, type, short note \(prompt)"
                        ]
                    ]
                ]
                
                do {
                    let jsonData = try JSONSerialization.data(withJSONObject: requestBody, options: [])
                    request.httpBody = jsonData
                    
                    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                        if let error = error {
                            print("Error: \(error)")
                            completion("error", 0, "", "", "")
                            return
                        }
                        
                        if let httpResponse = response as? HTTPURLResponse {
                            if httpResponse.statusCode == 200 {
                                if let data = data {
                                    do {
                                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
                                        if let choices = jsonResponse?["choices"] as? [[String: Any]],
                                           let content = choices.first?["message"] as? [String: Any],
                                           let contentValue = content["content"] as? String {
                                            // Handle the API response content here
                                            // Print the content for debugging
                                            print("Content: \(contentValue)")
                                            
                                            // Call the completion handler with the extracted values
                                            completion("success", 0, "", contentValue, "")
                                        }
                                    } catch {
                                        print("Error parsing JSON: \(error)")
                                        completion("error", 0, "", "", "")
                                    }
                                }
                            } else {
                                print("API request failed with status code: \(httpResponse.statusCode)")
                                completion("error", 0, "", "", "")
                            }
                        }
                    }
                    
                    task.resume()
                    
                } catch {
                    print("Error serializing request body: \(error)")
                    //completion(nil, 0, "", "")
                }
            } else {
                print("Failed to fetch API key from Remote Config.")
                //completion(nil, 0, "", "")
            }
        }
    }
    
//    func callNotificationAPI(playerid: String, notificationtime: String, description: String) {
//        // Create the URL string for the API
//        let urlString = "https://money-manager-copilot-budget.aibible.in/api/suspense-notification"
//        print("Player ID: \(playerid)")
//        
//        // Create the request body parameters
//        let params = [
//            "playerid": playerid,
//            "notificationtime": notificationtime,
//            "description": description,
//            //"location": location
//        ]
//        
//        AF.request(urlString, method: .post, parameters: params, encoding: JSONEncoding.default).responseJSON { response in
//            switch response.result {
//            case .success(let value):
//                if let responseString = String(data: response.data ?? Data(), encoding: .utf8) {
//                    print("API response: \(responseString)")
//                    
//                    // Handle the response data as needed
//                }
//            case .failure(let error):
//                print("API request error: \(error)")
//            }
//        }
//    }
    
    func callNotificationAPI(playerid: String, notificationtime: String, description: String, completion: @escaping (String?) -> Void) {
        // Create the URL string for the API
        let urlString = "https://money-manager-copilot-budget.aibible.in/api/suspense-notification"
        print("Player ID: \(playerid)")
        
        // Create the multipartFormData object
        AF.upload(multipartFormData: { multipartFormData in
            // Add parameters to the request body
            multipartFormData.append(playerid.data(using: .utf8) ?? Data(), withName: "player_id")
            multipartFormData.append(notificationtime.data(using: .utf8) ?? Data(), withName: "notificationtime")
            multipartFormData.append(description.data(using: .utf8) ?? Data(), withName: "description")
        }, to: urlString).responseJSON { response in
            switch response.result {
            case .success(let value):
                // Print the entire API response
                print("API Response: \(value)")
                
                if let responseData = response.data {
                    do {
                        let jsonResponse = try JSONSerialization.jsonObject(with: responseData, options: [])
                        if let jsonDict = jsonResponse as? [String: Any],
                           let details = jsonDict["details"] as? [String: Any],
                           let notificationId = details["notificationid"] as? String {
                            completion(notificationId)
                            return
                        }
                    } catch {
                        print("Error parsing JSON: \(error)")
                    }
                }
                completion(nil)
            case .failure(let error):
                print("API request error: \(error)")
                completion(nil)
            }
        }
    }
    
    func AllTime_callNotificationAPI(playerid: String, prompt: String) {
        // Create the URL string for the API
        let urlString = "https://money-manager-copilot-budget.aibible.in/api/insert"
        print("Player ID: \(playerid)")
        
        // Create the multipartFormData object
        AF.upload(multipartFormData: { multipartFormData in
            // Add parameters to the request body
            multipartFormData.append(playerid.data(using: .utf8) ?? Data(), withName: "player_id")
            multipartFormData.append(prompt.data(using: .utf8) ?? Data(), withName: "prompt")
        }, to: urlString).responseJSON { response in
            switch response.result {
            case .success(let value):
                if let responseString = String(data: response.data ?? Data(), encoding: .utf8) {
                    print("API response: \(responseString)")
                    // Handle the response data as needed
                }
            case .failure(let error):
                print("API request error: \(error)")
            }
        }
    }
    
    func Delete_callNotificationAPI(id: Int) {
        // Create the URL string for the API
        let urlString = "https://money-manager-copilot-budget.aibible.in/api/delete-suspense/\(id)"
        
        // Create the multipartFormData object
        AF.upload(multipartFormData: { multipartFormData in

        }, to: urlString).responseJSON { response in
            switch response.result {
            case .success(let value):
                if let responseString = String(data: response.data ?? Data(), encoding: .utf8) {
                    print("API response: \(responseString)")
                    // Handle the response data as needed
                }
            case .failure(let error):
                print("API request error: \(error)")
            }
        }
    }
    
    func makeAPIRequest(text: String, modelName: String, images: [UIImage]) {
        // API endpoint URL
        guard let apiUrl = URL(string: "https://aiexpensemanager.latestgovtjobs.co.in/api/suggestion") else {
            print("Invalid API URL")
            return
        }
        
        // Create the request
        var request = URLRequest(url: apiUrl)
        request.httpMethod = "POST"
        
        // Set the request body
        let boundary = UUID().uuidString
        let lineBreak = "\r\n"
        let contentType = "multipart/form-data; boundary=\(boundary)"
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        
        var requestBody = Data()
        
        // Add text parameter
        let textParameter = "--\(boundary + lineBreak)" +
        "Content-Disposition: form-data; name=\"text\"\(lineBreak + lineBreak)" +
        "\(text + lineBreak)"
        requestBody.append(Data(textParameter.utf8))
        
        // Add modelname parameter
        let modelNameParameter = "--\(boundary + lineBreak)" +
        "Content-Disposition: form-data; name=\"modelname\"\(lineBreak + lineBreak)" +
        "\(modelName + lineBreak)"
        requestBody.append(Data(modelNameParameter.utf8))
        
        // Add images
        for (index, image) in images.enumerated() {
            guard let imageData = image.pngData() else {
                print("Failed to convert image to data")
                return
            }
            
            let imageParameter = "--\(boundary + lineBreak)" +
            "Content-Disposition: form-data; name=\"images[]\"; filename=\"image\(index).png\"\(lineBreak)" +
            "Content-Type: image/png\(lineBreak + lineBreak)"
            requestBody.append(Data(imageParameter.utf8))
            requestBody.append(imageData)
            requestBody.append(Data(lineBreak.utf8))
        }
        
        let endBoundary = "--\(boundary)--\(lineBreak)"
        requestBody.append(Data(endBoundary.utf8))
        
        request.httpBody = requestBody
        
        // Send the request
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            // Handle the response and error
            if let error = error {
                DispatchQueue.main.async {
                    // Display alert controller with error message
                    let alertController = UIAlertController(title: "API Error", message: error.localizedDescription, preferredStyle: .alert)
                    let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
                    alertController.addAction(okAction)
                    //present(alertController, animated: true, completion: nil)
                }
                return
            }
            
            if let data = data {
                let responseString = String(data: data, encoding: .utf8)
                print("Response: \(responseString ?? "")")
            }
        }
        
        task.resume()
    }
}


