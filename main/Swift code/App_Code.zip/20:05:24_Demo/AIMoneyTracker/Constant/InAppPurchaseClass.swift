//
//  InAppPurchaseClass.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import Foundation
import SwiftyStoreKit

class InAppPurchaseClass{
    
    static let shared:InAppPurchaseClass = InAppPurchaseClass()
    
    // get removeall ad's updated price from app store.
    func getPrice(success:(@escaping (Bool) -> Void))
    {
        if CommonConst.priceOfRemoveAd.isEmpty{
            CustomLoader.show()
            SwiftyStoreKit.retrieveProductsInfo([AppInformation.removeAdID]) { result in
                CustomLoader.hide()
                if let product = result.retrievedProducts.first
                {
                    CommonConst.priceOfRemoveAd = product.localizedPrice!
                    success(true)
                }
                else
                {
                    CommonConst.priceOfRemoveAd = "9 $"
                    success(true)
                    print("Error: \(String(describing: result.error))")
                }
            }
        }else{
            success(true)
        }
    }
    
    func purchaseRestoreSuccess(){
        CommonConst.isPurchasedRemoveAds = true
        UserDefaults.standard.setValue(CommonConst.isPurchasedRemoveAds, forKey: "isPurchasedRemoveAds")
    }
    
    // purchase removeall ad's
    func purchase(purchaseResponse:(@escaping (Bool,String) -> Void))
    {
        CustomLoader.show()
        SwiftyStoreKit.purchaseProduct(AppInformation.removeAdID, atomically: true)
        {
            [self] result in
            CustomLoader.hide()
            switch result
            {
            case .success(let _):
                //sendEventToFirebase(event: "User In-App Purchase Success")
                purchaseRestoreSuccess()
                purchaseResponse(true,"Purchase Successfully")
            case .error(let error):
                let errMsg = error._nsError.code == 2 ? "Purchase Fail" : (error._nsError.code == 110 ? "No internet connection" : error.localizedDescription)
                purchaseResponse(false,errMsg)
            }
        }
    }
    
    // Restore removeall ad's
    func restore(restoreResponse:(@escaping (Bool,String) -> Void))
    {
        CustomLoader.show()
        SwiftyStoreKit.restorePurchases(atomically: true) { [self] results in
            CustomLoader.hide()
            if results.restoreFailedPurchases.count > 0
            {
                print("Restore Failed: \(results.restoreFailedPurchases)")
                restoreResponse(false,"Restore Failed")
            }
            else if results.restoredPurchases.count > 0
            {
                //sendEventToFirebase(event: "User In-App Purchase //Restore Success")
                purchaseRestoreSuccess()
                restoreResponse(true,"Your restore was successful")
            }
            else
            {
                restoreResponse(CommonConst.isPurchasedRemoveAds,"Nothing to Restore First Purchase")
            }
        }
    }
}



