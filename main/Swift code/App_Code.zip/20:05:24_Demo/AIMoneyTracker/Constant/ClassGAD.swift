//
//  ClassGAD.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import GoogleMobileAds
import Alamofire
import Firebase
import FirebaseRemoteConfig

protocol Class_GADDelegate: AnyObject {
    func didSelectAccount()
    func didSelectCategorywise()
}

class ClassGAD_New: NSObject, GADFullScreenContentDelegate {
    
    //MARK: - PUBLIC VARIABLE'S
    static let shared:ClassGAD_New = ClassGAD_New()
    weak var delegate: Class_GADDelegate?
    weak var appdelegate: AppDelegate?
    
    private var AppOpenAD = GAD_AD_Info()
    
    private var isInternetConnected:Bool
    {
        return NetworkReachabilityManager()?.isReachable ?? false
    }
    
    private var remoteConfig = RemoteConfig.remoteConfig()
    let adsRunValue = FirebaseRemoteConfigManager.shared.remoteConfig["iOS_ads_run"].stringValue ?? "default_model_value"
    let adsRunValueappopen = FirebaseRemoteConfigManager.shared.remoteConfig["app_open_controller"].stringValue ?? "default_model_value"
    
    private var gadAppOpenAd: GADAppOpenAd?
    private var gadAppOpenAdRequested = false
    
    static var clickedX: Int = 0
    static var RemoveAdsClickCount: Int = 0
    
    func fetchRemoteConfig_RemoveAds() {
        let remoteConfig = RemoteConfig.remoteConfig()
        
        // Set default values in case fetching from Firebase fails
        let defaultValues: [String: NSObject] = [
            "openInAppValue": 5 as NSObject // Replace with your desired default value
        ]
        remoteConfig.setDefaults(defaultValues)
        
        // Fetch the values from Firebase Remote Config with an expiration duration of 0 to bypass throttling
        remoteConfig.fetch(withExpirationDuration: 0) { [weak self] status, error in
            if status == .success {
                remoteConfig.activate { _, _ in
                    // Retrieve the 'click_count_rewarded' value from Firebase Remote Config
                    let clickCountValue = remoteConfig.configValue(forKey: "openInAppValue").numberValue
                    print(clickCountValue,"****RemoveAds")
                    
                    // Check if the retrieved value is a valid number
                    if let clickCount = clickCountValue as? Int {
                        ClassGAD_New.RemoveAdsClickCount = clickCount
                        print("clickCountValue:", clickCountValue)
                    } else {
                        print("Error retrieving 'click_count_rewarded' from Remote Config.")
                        // Handle error if needed
                    }
                }
            } else {
                print("Error fetching Remote Config: \(error?.localizedDescription ?? "Unknown error")")
                // Handle error if needed
            }
        }
    }
}


extension ClassGAD_New {
    func adDidDismissFullScreenContent(_ ad: GADFullScreenPresentingAd) {
        // Call the delegate method to handle ad dismissal
        gadFullScreenPresentingAdDismiss(ad)
    }
}

struct GAD_AD_Info{
    
    var adID:String = ""
    var adRequested:Bool = false
    
    // GADRewardedInterstitialAd
    var rewardedAD:GADRewardedInterstitialAd? = nil
    var rewardedADDismissed:((Bool) -> Void)? = nil
    
    // GADInterstitialAd
    var interstitialAD:GADInterstitialAd? = nil
    var interstitialADDismissed:(() -> Void)? = nil
    
    // GADNativeAd
    var nativeAD:GADNativeAd? = nil
    var nativeADLoader:GADAdLoader? = nil
    var nativeADLoadSuccess:((GADNativeAd?) -> Void)? = nil
    
    // Banner Ad
    var bannerAD: GADBannerView? = nil
    var bannerADLoadSuccess:((GADBannerView?) -> Void)? = nil
    
}

var RewardedInterstitialAD = GAD_AD_Info()
var RewardedInterstitialADGuestUser = GAD_AD_Info()

var InterstitialADSetMonthBudget = GAD_AD_Info()
var InterstitialADTransactionReport = GAD_AD_Info()
var InterstitialADCategoryReport = GAD_AD_Info()
var InterstitialADSeeAll = GAD_AD_Info()

var NativADHistory = GAD_AD_Info()
var NativADAccountReport = GAD_AD_Info()
var NativADNotification = GAD_AD_Info()

var BannerADHome = GAD_AD_Info()

class FirebaseRemoteConfigManager {
    static let shared = FirebaseRemoteConfigManager()
    
    var remoteConfig: RemoteConfig
    
    private init() {
        remoteConfig = RemoteConfig.remoteConfig()
        
        // Set default values in case remote config values are not available
        let defaultValue: [String: NSObject] = [
            "iOS_ads_run": "1" as NSObject,
            // Add more keys and default values as needed
        ]
        
        remoteConfig.setDefaults(defaultValue)
    }
    
    func fetchRemoteConfigValuesAppRun(completion: @escaping () -> Void) {
        remoteConfig.fetch(withExpirationDuration: 3600) { (status, error) in
            if status == .success {
                self.remoteConfig.activate()
                completion()
            } else {
                // Handle fetch error
                print("Error fetching remote config: \(error?.localizedDescription ?? "")")
            }
        }
    }
}


//MARK: ad init function for appdelegate

// MARK: - All Public Func
extension ClassGAD_New{
    func initGAD(){
        GADMobileAds.sharedInstance().start(completionHandler: nil)
        addTestDevice()
        startMonitoring()
    }
}

// MARK: - All Private Func
extension ClassGAD_New{
    // Print all error in
    private func printLog(_ data:Any){
#if DEBUG
        print("ClassGAD_New :- ",data)
#else
#endif
    }
    
    // Monitoring internet connectivity
    private func startMonitoring() {
        self.getAdIdsFromRemoteConfig()
    }
    
    // Add test device
    private func addTestDevice(){
        var arrTestDevice:[String] = ["00008110-000154313CC0401E","4f4fb53be6522e5b8933194c8e62ab7c","1680d6f580145c615f1432ab285aa51a"]
        if !GADSimulatorID.isEmpty{arrTestDevice.append(GADSimulatorID)}
        GADMobileAds.sharedInstance().requestConfiguration.testDeviceIdentifiers = arrTestDevice
    }
    
    // Get All Ad id From Remote Config
    private func getAdIdsFromRemoteConfig(){
        remoteConfig.fetch(withExpirationDuration: 0) {[self] (status, error) in
            guard error == nil else { return }
            self.remoteConfig.activate()
            
            // Rewarded Interstitial AD
            RewardedInterstitialAD.adID = remoteConfig["rewarded_4"].stringValue ?? ""
            
            // Interstitial AD
            InterstitialADSetMonthBudget.adID = remoteConfig["Set_Month_Budget_Intrestrial_3"].stringValue ?? ""
            InterstitialADTransactionReport.adID = remoteConfig["Transaction_Report_Intrestrial_5"].stringValue ?? ""
            InterstitialADCategoryReport.adID = remoteConfig["Category_Report_Intrestrial_6"].stringValue ?? ""
            InterstitialADSeeAll.adID = remoteConfig["See_all_Intrestrial_10"].stringValue ?? ""
            
            // Native Ad
            NativADHistory.adID = remoteConfig["History_native_7"].stringValue ?? ""
            NativADAccountReport.adID = remoteConfig["AI_Account_Report_Native_8"].stringValue ?? ""
            NativADNotification.adID = remoteConfig["notification_native_9"].stringValue ?? ""
            
            // Banner Ad
            BannerADHome.adID = remoteConfig["main_adaptive_2"].stringValue ?? ""
            
            NotificationCenter.default.post(name: .GADAdIDGet, object: nil)
            //            NotificationCenter.default.post(name: .googleAdIdGet, object: nil)
        }
    }
    
    // GADInterstitialAd dismiss or not present
    private func gadFullScreenPresentingAdDismiss(_ ad: GADFullScreenPresentingAd){
        if ad.isKind(of: GADInterstitialAd.self){
            
            var tmpAdInfo = getSetAdInfoFromID(adID: (ad as! GADInterstitialAd).adUnitID)
            tmpAdInfo.interstitialAD = nil
            tmpAdInfo.interstitialADDismissed?()
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            
        }else if ad.isKind(of: GADRewardedInterstitialAd.self){
            
            var tmpAdInfo = getSetAdInfoFromID(adID: (ad as! GADRewardedInterstitialAd).adUnitID)
            tmpAdInfo.rewardedAD = nil
            tmpAdInfo.rewardedADDismissed?(true)
            tmpAdInfo.rewardedADDismissed = nil
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        }
    }
    
    private func getSetAdInfoFromID(adID:String = "",
                                    adInfo:GAD_AD_Info? = nil) -> GAD_AD_Info{
        
        let isSet = adInfo != nil
        let tmpAdID = isSet ? adInfo!.adID : adID
        
        switch tmpAdID{
            
        case AppOpenAD.adID:
            if isSet{AppOpenAD = adInfo!}
            return AppOpenAD
            
        case RewardedInterstitialAD.adID:
            if isSet{RewardedInterstitialAD = adInfo!}
            return RewardedInterstitialAD
            
        case RewardedInterstitialADGuestUser.adID:
            if isSet{RewardedInterstitialADGuestUser = adInfo!}
            return RewardedInterstitialADGuestUser
            
        case InterstitialADSetMonthBudget.adID:
            if isSet{InterstitialADSetMonthBudget = adInfo!}
            return InterstitialADSetMonthBudget
            
        case InterstitialADTransactionReport.adID:
            if isSet{InterstitialADTransactionReport = adInfo!}
            return InterstitialADTransactionReport
            
        case InterstitialADCategoryReport.adID:
            if isSet{InterstitialADCategoryReport = adInfo!}
            return InterstitialADCategoryReport
            
        case InterstitialADSeeAll.adID:
            if isSet{InterstitialADSeeAll = adInfo!}
            return InterstitialADSeeAll
            
        case NativADHistory.adID:
            if isSet{NativADHistory = adInfo!}
            return NativADHistory
            
        case NativADAccountReport.adID:
            if isSet{NativADAccountReport = adInfo!}
            return NativADAccountReport
            
        case NativADNotification.adID:
            if isSet{NativADNotification = adInfo!}
            return NativADNotification
            
        case BannerADHome.adID:
            if isSet{BannerADHome = adInfo!}
            return BannerADHome
            
        default:
            return GAD_AD_Info()
        }
    }
}

//MARK: - GADInterstitialAD's METHOD
extension ClassGAD_New{
    
    // load GADInterstitialAd
    private func loadGADInterstitialAD(adInfo:GAD_AD_Info,adisLoad:((Bool) -> Void)? = nil){
        
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        
        if CommonConst.isPurchasedRemoveAds{
            tmpAdInfo.interstitialAD = nil
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            adisLoad?(false)
            return
        }
        
        if tmpAdInfo.interstitialAD == nil &&
            isInternetConnected &&
            !tmpAdInfo.adID.isEmpty &&
            !tmpAdInfo.adRequested && adsRunValue == "1" {
            
            tmpAdInfo.adRequested = true
            
            GADInterstitialAd.load(withAdUnitID:tmpAdInfo.adID,request: GADRequest(),completionHandler: { [self] ad, error in
                
                tmpAdInfo.adRequested = false
                
                if let error = error {
                    tmpAdInfo.interstitialAD = nil
                    printLog("ERROR :- GADInterstitialAd load error: \(error.localizedDescription)")
                    let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
                    adisLoad?(false)
                    return
                }
                
                printLog("SUCCESS :- GADInterstitialAd load ")
                tmpAdInfo.interstitialAD = ad
                tmpAdInfo.interstitialAD?.fullScreenContentDelegate = self
                let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
                adisLoad?(true)
            })
        }
    }
   
    // Present GADInterstitialAd
    private func presentGADInterstitialAD(adInfo: GAD_AD_Info,
                                          isNeedToPresent:Bool = true,
                                          adisDismissed:@escaping (() -> Void)){
        
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        tmpAdInfo.interstitialADDismissed = adisDismissed
        
        if let topVC = UIApplication.getTopViewController(),
           tmpAdInfo.interstitialAD != nil,
           !CommonConst.isPurchasedRemoveAds{
            DispatchQueueMain {
                tmpAdInfo.interstitialAD!.present(fromRootViewController: topVC)
            }
        }else{
            tmpAdInfo.interstitialADDismissed?()
        }
        let _ = self.getSetAdInfoFromID(adInfo: tmpAdInfo)
    }
    
    func checkGADInterstitialAd(adInfo: GAD_AD_Info,
                                isNeedToPresent:Bool = true,
                                adisDismissed:(() -> Void)? = nil){
        
        if adInfo.adID.isEmpty{
            adisDismissed?()
            return
        }
        
        if adsRunValue == "0" {
            adisDismissed?()
            return
        }
        
        if adInfo.interstitialAD != nil{
            if isNeedToPresent{
                self.presentGADInterstitialAD(adInfo: adInfo) {
                    adisDismissed?()
                }
            }
        }else{
            if isNeedToPresent{
                CustomLoader.show()
            }
            self.loadGADInterstitialAD(adInfo: adInfo) { isAsLoad in
                DispatchQueueMain {CustomLoader.hide()}
                
                if isAsLoad{
                    if isNeedToPresent{
                        self.presentGADInterstitialAD(adInfo: adInfo) {
                            adisDismissed?()
                        }
                    }
                }else{
                    adisDismissed?()
                }
            }
        }
    }
}

//MARK: - GADRewardedInterstitialAd's METHOD
extension ClassGAD_New{
    
    
    // load GADRewardedAd
    private func loadGADRewardedInterstitialAd(adInfo:GAD_AD_Info,adisLoad:@escaping ((Bool) -> Void)){
        
        if CommonConst.isPurchasedRemoveAds{
            adisLoad(false)
            return
        }
        
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        
        if tmpAdInfo.rewardedAD == nil &&
            isInternetConnected &&
            !tmpAdInfo.adID.isEmpty &&
            !tmpAdInfo.adRequested && adsRunValue == "1" {
            
            tmpAdInfo.adRequested = true
            
            GADRewardedInterstitialAd.load(withAdUnitID:adInfo.adID,request: GADRequest(),completionHandler: { [self] ad, error in
                tmpAdInfo.adRequested = false
                
                if let error = error {
                    tmpAdInfo.rewardedAD = nil
                    printLog("ERROR :- GADRewardedInterstitialAd load error: \(error.localizedDescription)")
                    adisLoad(false)
                    let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
                    return
                }
                
                printLog("SUCCESS :- GADRewardedInterstitialAd load ")
                tmpAdInfo.rewardedAD = ad
                tmpAdInfo.rewardedAD?.fullScreenContentDelegate = self
                let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
                adisLoad(true)
            })
        }else{
            adisLoad(false)
        }
    }
    
    // Present GADInterstitialAd
    private func presentGADRewardedInterstitialAd(adInfo: GAD_AD_Info,userReward:@escaping(() -> Void),adisDismissed:@escaping ((Bool) -> Void)) {
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        tmpAdInfo.rewardedADDismissed = adisDismissed
        
        //        if let topVC = UIApplication.shared.getTopViewController(),gadRewardedAd != nil,!CommonConst.isPurchasedRemoveAds{
        if let topVC = UIApplication.getTopViewController(),
           tmpAdInfo.rewardedAD != nil,
           !CommonConst.isPurchasedRemoveAds{
            
            tmpAdInfo.rewardedAD!.present(fromRootViewController: topVC) {
                // user reward success
                self.printLog("SUCCESS :- GADRewardedInterstitialAd reward success")
                userReward()
            }
        }else{
            tmpAdInfo.rewardedADDismissed?(true)
        }
        let _ = self.getSetAdInfoFromID(adInfo: tmpAdInfo)
    }
    
    // check ad is ready or not
    func checkGADRewardedInterstitialAd(adInfo: GAD_AD_Info,
                                        isNeedToPresent:Bool = true,
                                        userReward:(() -> Void)? = nil,
                                        adisDismissed:((Bool) -> Void)? = nil){
        if adInfo.rewardedAD != nil{
            if isNeedToPresent{
                self.presentGADRewardedInterstitialAd(adInfo: adInfo) {
                    userReward?()
                } adisDismissed: { isAdDismiss in
                    adisDismissed?(isAdDismiss)
                }
            }
        }else{
            if isNeedToPresent{
                CustomLoader.show()
            }
            
            self.loadGADRewardedInterstitialAd(adInfo: adInfo) { isAsLoad in
                DispatchQueueMain {CustomLoader.hide()}
                
                if isAsLoad{
                    if isNeedToPresent{
                        self.presentGADRewardedInterstitialAd(adInfo: adInfo) {
                            userReward?()
                        } adisDismissed: { isAdDismiss in
                            adisDismissed?(isAdDismiss)
                        }
                    }
                }else{
                    adisDismissed?(true)
                }
            }
        }
    }
}

//MARK: - GADNAtive's METHOD
extension ClassGAD_New:GADNativeAdDelegate,GADNativeAdLoaderDelegate{
    // load GADNativeAd
    private func loadGADNativAd(adInfo:GAD_AD_Info){
        
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        
        if CommonConst.isPurchasedRemoveAds{
            tmpAdInfo.nativeAD = nil
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            return
        }
        
        
        if tmpAdInfo.nativeAD == nil &&
            isInternetConnected  &&
            !tmpAdInfo.adID.isEmpty &&
            !tmpAdInfo.adRequested && adsRunValue == "1" {
            
            tmpAdInfo.adRequested = true
            
            let multipleAdsOptions = GADMultipleAdsAdLoaderOptions()
            multipleAdsOptions.numberOfAds = 1
            
            let videoOption = GADVideoOptions()
            videoOption.customControlsRequested = true
            
            tmpAdInfo.nativeADLoader = GADAdLoader(adUnitID: tmpAdInfo.adID,
                                                   rootViewController: UIApplication.getTopViewController() ?? UIViewController(),
                                                   adTypes: [.native],
                                                   options: [multipleAdsOptions,videoOption])
            tmpAdInfo.nativeADLoader?.delegate = self
            tmpAdInfo.nativeADLoader?.load(GADRequest())
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        }
    }
    
    // Nativ adLoader Receive Ad
    internal func adLoader(_ adLoader: GADAdLoader, didReceive nativeAd: GADNativeAd) {
        var tmpAdInfo = getSetAdInfoFromID(adID: adLoader.adUnitID)
        let adLoadSucccess:((GADNativeAd?) -> Void)? = tmpAdInfo.nativeADLoadSuccess
        
        tmpAdInfo.adRequested = false
        tmpAdInfo.nativeAD = nativeAd
        tmpAdInfo.nativeAD!.delegate = self
        tmpAdInfo.nativeADLoadSuccess = nil
        let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        
        adLoadSucccess?(tmpAdInfo.nativeAD)
        
        printLog("SUCCESS :- GADNativeAd load ")
    }
    
    // Nativ adLoader didfail to Receive ad
    internal func adLoader(_ adLoader: GADAdLoader, didFailToReceiveAdWithError error: Error) {
        var tmpAdInfo = getSetAdInfoFromID(adID: adLoader.adUnitID)
        tmpAdInfo.adRequested = false
        tmpAdInfo.nativeAD = nil
        let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        
        printLog("ERROR :- GADNativeAd load error: \(error.localizedDescription)")
    }
    
    // The native ad was clicked on.
    internal func nativeAdDidRecordClick(_ nativeAd: GADNativeAd) {
        //        var tmpAdInfo = getSetAdInfoFromID(adID: adLoader.adUnitID)
        //        tmpAdInfo.nativeAD = nil
        //        tmpAdInfo.nativeADLoadSuccess?(nil)
        //        loadGADNativAd()
    }
    
    
    // get loaded native ad
    func getGADNativeAd(adInfo:GAD_AD_Info,ad:((GADNativeAd?) -> Void)? = nil){
        
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        
        if CommonConst.isPurchasedRemoveAds{
            tmpAdInfo.nativeAD = nil
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            ad?(nil)
            return
        }
        
        if let gadNativeAd = tmpAdInfo.nativeAD{
            ad?(gadNativeAd)
        }else{
            tmpAdInfo.nativeADLoadSuccess = ad
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            
            loadGADNativAd(adInfo: adInfo)
        }
    }
    
    //reset banner ad after added in screen
    func resetNativeAd(adInfo:GAD_AD_Info){
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        tmpAdInfo.nativeAD = nil
        let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        
        loadGADNativAd(adInfo:adInfo)
    }
}

//MARK: - GADBanner Ad's METHOD
extension ClassGAD_New:GADBannerViewDelegate{
    // load GADNativeAd
    private func loadGadBannerAd(size:CGSize,adInfo:GAD_AD_Info){
        
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        
        if CommonConst.isPurchasedRemoveAds{
            tmpAdInfo.bannerAD = nil
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            return
        }
        
        if CommonConst.isInternetConnected &&
            !tmpAdInfo.adID.isEmpty &&
            tmpAdInfo.bannerAD == nil &&
            !tmpAdInfo.adRequested && adsRunValue == "1" {
            
            tmpAdInfo.adRequested = true
            
            let adSize = GADAdSizeFromCGSize(size)
            tmpAdInfo.bannerAD = GADBannerView(adSize: adSize)
            tmpAdInfo.bannerAD?.adUnitID = tmpAdInfo.adID
            tmpAdInfo.bannerAD?.rootViewController = UIApplication.getTopViewController() ?? UIViewController()
            tmpAdInfo.bannerAD?.delegate = self
            tmpAdInfo.bannerAD?.load(GADRequest())
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        }
    }
    
    // get loaded native ad
    func getGADBannerAd(size:CGSize,adInfo:GAD_AD_Info,ad:((GADBannerView?) -> Void)? = nil){
        
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        
        if CommonConst.isPurchasedRemoveAds{
            tmpAdInfo.bannerAD = nil
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            ad?(nil)
            return
        }
        
        if let gadBannerView = tmpAdInfo.bannerAD{
            ad?(gadBannerView)
        }else{
            tmpAdInfo.bannerADLoadSuccess = ad
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            
            loadGadBannerAd(size: size, adInfo: adInfo)
        }
    }
    
    // banner ad recive success
    internal func bannerViewDidReceiveAd(_ bannerView: GADBannerView) {
        printLog("SUCCESS :- GADBannerView load ")
        if let adID = bannerView.adUnitID{
            
            var tmpAdInfo = getSetAdInfoFromID(adID: adID)
            let adLoadSucccess:((GADBannerView?) -> Void)? = tmpAdInfo.bannerADLoadSuccess
            tmpAdInfo.adRequested = false
            bannerView.backgroundColor = .white
            tmpAdInfo.bannerAD = bannerView
            tmpAdInfo.bannerADLoadSuccess = nil
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
            
            adLoadSucccess?(bannerView)
        }
    }
    
    // banner ad recive fail
    internal func bannerView(_ bannerView: GADBannerView, didFailToReceiveAdWithError error: Error) {
        if let adID = bannerView.adUnitID{
            var tmpAdInfo = getSetAdInfoFromID(adID: adID)
            
            tmpAdInfo.adRequested = false
            
            if tmpAdInfo.bannerADLoadSuccess != nil{
                tmpAdInfo.bannerADLoadSuccess = nil
            }else{
                tmpAdInfo.bannerAD = nil
            }
            let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        }
        
        printLog("ERROR :- GADBannerView load error: \(error.localizedDescription)")
    }
    
    //reset banner ad after added in screen
    func resetBannerAd(size:CGSize,adInfo:GAD_AD_Info){
        var tmpAdInfo = getSetAdInfoFromID(adID: adInfo.adID)
        tmpAdInfo.bannerAD = nil
        let _ = getSetAdInfoFromID(adInfo: tmpAdInfo)
        loadGadBannerAd(size: size, adInfo: adInfo)
    }
}

extension UIApplication {
    class func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return getTopViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}
