//
//  Click_CountClass.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//


import UIKit
//import Firebase

class Click_CountClass {
    static let shared = Click_CountClass()
    
    private var totalClickCount = 0
    private var remoteClickCount: Int = 1
    private var navigationController: UINavigationController?
    
    private init() {}
    
    func incrementClickCount() {
        // Fetch the click_count from Remote Config before incrementing
        fetchClickCount { [weak self] (remoteCount) in
            guard let self = self, let remoteCount = remoteCount else {
                return
            }
            
            self.remoteClickCount = remoteCount
            self.totalClickCount += 1
        }
    }
    
    func checkClickCount(presentingViewController: UIViewController) {
        // Compare the totalClickCount with the value fetched from Firebase Remote Config
        if totalClickCount >= remoteClickCount {
            // Both counts match, present the "RewardVC" view controller
            DispatchQueue.main.async {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let rewardVC = storyboard.instantiateViewController(withIdentifier: "RewardViewController") as! RewardViewController
                rewardVC.modalPresentationStyle = .overCurrentContext
                presentingViewController.present(rewardVC, animated: true, completion: nil)
            }
            
            // Reset the totalClickCount
            self.totalClickCount = 0
        }
    }
    
    func fetchClickCount(completion: @escaping (Int?) -> Void) {
//        let remoteConfig = RemoteConfig.remoteConfig()
//
//        // Define default values for your keys
//        let remoteConfigDefaults: [String: NSObject] = [
//            "click_count": "30" as NSObject // Default value as a string
//        ]
//        remoteConfig.setDefaults(remoteConfigDefaults)
//
//        remoteConfig.fetch { (status, error) in
//            if status == .success {
//                remoteConfig.activate { (_, _) in
//                    let clickCountString = remoteConfig["click_count"].stringValue
//                    if let clickCount = Int(clickCountString!) {
//                        self.remoteClickCount = clickCount
//                        print("Fetched Click Count: \(self.remoteClickCount)")
//                        completion(self.remoteClickCount)
//                    } else {
//                        print("Error converting click_count to an integer")
//                        completion(nil)
//                    }
//                }
//            } else {
//                print("Error fetching remote config: \(error?.localizedDescription ?? "Unknown error")")
//                completion(nil)
//            }
//        }
    }
}

class MainGradientView: UIView {
    override class var layerClass: AnyClass {
        return CAGradientLayer.self
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupGradient()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupGradient()
    }
    
    func setupGradient() {
        guard let gradientLayer = self.layer as? CAGradientLayer else { return }
        
        // Set colors
        gradientLayer.colors = [
            UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1).cgColor,
            UIColor(red: 255/255, green: 242/255, blue: 194/255, alpha: 1).cgColor
        ]
        
        // Set locations
        gradientLayer.locations = [0, 1]
        
        // Set direction from top to bottom
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 1) // Top center
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 0)   // Bottom center
    }
}
