//
//  ConstantFile.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import Foundation
import UIKit
import Toast_Swift
import AVKit
import Alamofire
import MBProgressHUD
import GoogleMobileAds

var mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)

var isInternetConnected:Bool
{
    return NetworkReachabilityManager()?.isReachable ?? false
}

extension String {
    
    // Lottie Animation
    static let lottie_Splash = "animated"
    static let lottie_Congrates = "congrates"
    static let lottie_Loader = "loader"
    static let lottie_chatai = "chatai"
}

let Defaults = UserDefaults.standard;
let APPNAME = "AIMoneyTracker"

struct CommonConst {
    static let isIphone = UIDevice.current.userInterfaceIdiom == .phone // check current device is iPhone or iPad
    static var isPurchasedRemoveAds = false // check is purchased or not removed ad's
    static var isOneDayRemoveAds = false
    static var priceOfRemoveAd = "" // get price of remove ads from app store and store here
    static var isSubscriptionAds = false
    
    // for check internet connection
    static var isInternetConnected:Bool
    {
        return NetworkReachabilityManager()?.isReachable ?? false
    }
}

struct AppInformation
{
    static let removeAdID = "YOUR_INAPP_PURCHASE_ID"
    
    static let privacyPolicyURL = "YOUR_PRIVAY_POLICY_LINK"
}

class CustomLoader{
    class func show(){
        self.hide()
        let tmpVW = UIApplication.shared.windows[0]
        MBProgressHUD.showAdded(to: tmpVW, animated: true)
    }
    
    class func hide(){
        let tmpVW = UIApplication.shared.windows[0]
        MBProgressHUD.hide(for: tmpVW, animated: true)
    }
}

func AlertWithMessage(_ vc:UIViewController,message:String)
{
    let dialogBox = UIAlertController(title: APPNAME, message: message, preferredStyle: .alert)
    dialogBox.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
    vc.present(dialogBox, animated: true, completion: nil)
}

// DispatchQueue
func DispatchQueueMain(_ block:@escaping(() -> Void)){
    DispatchQueue.main.async {
        block()
    }
}

extension Notification.Name{
    static let isPurchased = NSNotification.Name("Notification_PurchasedSuccess")
    static let GADAdIDGet = NSNotification.Name("GAD_AD_Id_Get_From_Remote")
    static let isAccountDeleted = NSNotification.Name("UserAccountDeleted")
}

extension UserDefaults {
    private enum UserDefaultsKeys : String {
        case hashOnboared
    }
    
    var hasOnboarded: Bool {
        get {
            bool(forKey: UserDefaultsKeys.hashOnboared.rawValue)
        }
        set {
            setValue(newValue, forKey: UserDefaultsKeys.hashOnboared.rawValue)
        }
    }
}

class CustomToast{
    
    enum TOAST_TYPE{
        case ERROR
        case SUCCESS
        case NONE
    }
    
    class func toastMessage(message:String,
                            type:TOAST_TYPE = .SUCCESS){
        
        if message.isEmpty { return }
        
        DispatchQueue.main.async {
            let baseView = UIApplication.shared.keyWindow ?? UIView()
            
            baseView.hideToast()
            
            var toastStyle = ToastStyle()
            
            switch type {
            case .ERROR:
                toastStyle.backgroundColor = .red
                toastStyle.titleColor = .white
                toastStyle.messageColor = .white
            case .SUCCESS:
                toastStyle.backgroundColor = .green
                toastStyle.titleColor = .black
                toastStyle.messageColor = .black
            case .NONE: // Add a case for .INSTRUCTION
                toastStyle.backgroundColor = .orange
                toastStyle.titleColor = .white
                toastStyle.messageColor = .white
            }
            
            toastStyle.titleAlignment = .center
            toastStyle.messageAlignment = .center
            
            baseView.makeToast(message, duration: 3.0, position: .top, style: toastStyle)
            
            // Added vibrate for all cases except .INSTRUCTION
            if type != .NONE {
                AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
            }
        }
    }
    
    // hide toast message
    class func hideToast(){
        let baseView = UIApplication.shared.keyWindow ?? UIView()
        baseView.hideToast()
    }
}

extension UIView {
    
    /// Rounds the top corners of the view.
    func roundTopCorners(cornerRadius: CGFloat) {
        self.clipsToBounds = true
        self.layer.cornerRadius = cornerRadius
        self.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
    }
    
    /// Adds a border to the bottom of the view.
    func addBottomBorder(color: UIColor, borderWidth: CGFloat) {
        let borderLayer = CALayer()
        borderLayer.backgroundColor = color.cgColor
        borderLayer.frame = CGRect(x: 0, y: self.frame.size.height - borderWidth, width: self.frame.size.width, height: borderWidth)
        self.layer.addSublayer(borderLayer)
    }
}

extension UIView {
    func addBottomBorder(color: UIColor, thickness: CGFloat) {
        let borderLayer = CALayer()
        borderLayer.backgroundColor = color.cgColor
        borderLayer.frame = CGRect(x: 0, y: self.frame.size.height - thickness, width: self.frame.size.width, height: thickness)
        self.layer.addSublayer(borderLayer)
    }
}

extension UIView {
    func addBottomBorders(color: UIColor, thickness: CGFloat) {
        let bottomBorder = CALayer()
        bottomBorder.frame = CGRect(x: 0, y: self.frame.size.height - thickness, width: self.frame.size.width, height: thickness)
        bottomBorder.backgroundColor = color.cgColor
        self.layer.addSublayer(bottomBorder)
    }
}

extension UIViewController{
    @objc func openRemoveAdScreen(){
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
        
        vc.isForOnlyRemoveAd = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension UIView{
    
    enum NativeAdView:String{
        case UnifiedNativeAd = "UnifiedNativeAdView"
        case PageControlNativeAd = "PageControlNativeView"
    }
    
    // show native ad
    func showGADNativeAd(ad:GADNativeAd?,adView:NativeAdView,btnRemoveAds:((UIButton) -> Void)?){
        isHidden = true
        
        // Create and place ad in view hierarchy.
        if let nativeAd = ad,
           let nibObjects = Bundle.main.loadNibNamed(adView.rawValue, owner: nil, options: nil),
           let nativeAdView = nibObjects.first as? GADNativeAdView{
            
            // add nativadview
            self.removeAllSubViews()
            addSubview(nativeAdView)
            nativeAdView.translatesAutoresizingMaskIntoConstraints = false
            
            let viewDictionary = ["_nativeAdView": nativeAdView]
            self.superview!.addConstraints(
              NSLayoutConstraint.constraints(
                withVisualFormat: "H:|[_nativeAdView]|",
                options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: viewDictionary)
            )
            self.superview!.addConstraints(
              NSLayoutConstraint.constraints(
                withVisualFormat: "V:|[_nativeAdView]|",
                options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: viewDictionary)
            )
            
            
            // Title
            (nativeAdView.headlineView as? UILabel)?.text = nativeAd.headline
            nativeAdView.headlineView?.isHidden = nativeAd.headline == nil
            
            // Advertiser
            (nativeAdView.advertiserView as? UILabel)?.text = nativeAd.advertiser
            nativeAdView.advertiserView?.isHidden = nativeAd.advertiser == nil
            
            // Icon
            (nativeAdView.iconView as? UIImageView)?.image = nativeAd.icon?.image
            nativeAdView.iconView?.isHidden = nativeAd.icon == nil
            
            // Star
            (nativeAdView.starRatingView as? UIImageView)?.image = nativeAd.getStarImgForNativAd()
            nativeAdView.starRatingView?.isHidden = nativeAd.starRating == nil
            
            // show star if advertiser && starRating are nil
            if nativeAd.advertiser == nil && nativeAd.starRating == nil{
                (nativeAdView.starRatingView as? UIImageView)?.image = nativeAd.getStarImgForNativAd()
                nativeAdView.starRatingView?.isHidden = false
            }
            
            // Body
            (nativeAdView.bodyView as? UILabel)?.text = nativeAd.body
            nativeAdView.bodyView?.isHidden = nativeAd.body == nil
            
            // Media
            nativeAdView.mediaView?.mediaContent = nativeAd.mediaContent
            
            // callToActionView
            nativeAdView.callToActionView?.isUserInteractionEnabled = false
            (nativeAdView.callToActionView as? UIButton)?.setTitle(nativeAd.callToAction ?? "Install", for: .normal)
            
            // RemoveAds Button
            if let btnIndex = nativeAdView.subviews.firstIndex(where: {$0.tag == 456}),let btnRemoveAd = (nativeAdView.subviews[btnIndex] as? UIButton){
                btnRemoveAds?(btnRemoveAd)
                btnRemoveAd.isUserInteractionEnabled = true
            }
            
            nativeAdView.nativeAd = nativeAd
            nativeAdView.backgroundColor = .clear
            
            isHidden = false
        }
    }
    
    // show Banner ad
    func showGADBannerAd(ad:GADBannerView){
        self.removeAllSubViews()
        self.addSubview(ad)
        self.isHidden = false
    }
    
    // Gradiant Color For NativeAdView
    func GADNativeAdViewGradientBackground(){
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x: 0, y: 0, width: self.bounds.width, height: self.bounds.height)
        gradientLayer.colors = [UIColor(hex: "523652").cgColor,  UIColor(hex: "000000").cgColor]
//        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
//        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        
        // Apply corner radius to the view's layer
        self.layer.cornerRadius = 10
        
        // Make sure to clip subviews to the rounded corners
        self.clipsToBounds = true
        
        // Apply corner radius to the gradient layer
        gradientLayer.cornerRadius = 10
        gradientLayer.masksToBounds = true
        
        
        for layer in self.layer.sublayers ?? []{
            if layer.isKind(of: CAGradientLayer.self){
                layer.removeFromSuperlayer()
            }
        }
        
        // Insert the gradient layer as a sublayer
        self.layer.insertSublayer(gradientLayer, at: 0)
        
        layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        layer.borderWidth = 0.5
    }
    
    func removeAllSubViews(){
        self.subviews.forEach({$0.removeFromSuperview()})
    }
}

//MARK: - ************* GADNativeAd *****************
extension GADNativeAd{
    func getStarImgForNativAd() -> UIImage? {
        guard let rating = starRating?.doubleValue else {
            return nil
        }
        if rating >= 5 {
            return UIImage(named: "ic_stars_5")
        } else if rating >= 4.5 {
            return UIImage(named: "ic_stars_4_5")
        } else if rating >= 4 {
            return UIImage(named: "ic_stars_4")
        } else if rating >= 3.5 {
            return UIImage(named: "ic_stars_3_5")
        } else {
            return nil
        }
    }
}
