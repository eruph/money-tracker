//
//  NotificationViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import Alamofire
import GoogleMobileAds
import OneSignalFramework

protocol NotificationVCDelegate: AnyObject {
    func notificationSwitchDidChange(isOn: Bool)
}

class NotificationViewController: UIViewController {
    
    weak var delegate: NotificationVCDelegate?
    
    @IBOutlet weak var vwNativeAd: UIView!
    @IBOutlet weak var notification2: UISwitch!
    @IBOutlet weak var notification: UISwitch!
    @IBOutlet weak var view_height: NSLayoutConstraint!
    
    let adsRunValue = ClassGAD_New.shared.adsRunValue
    var onesignalDeviceId: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadNativAd()
        
        NotificationCenter.default.addObserver(self, selector: #selector(loadNativAd), name: .GADAdIDGet, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(loadNativAd), name: .isPurchased, object: nil)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)
        
        let defaults = UserDefaults.standard
        
        // Check if the "isChecked1" key exists in UserDefaults
            if defaults.object(forKey: "isChecked1") == nil {
                // Set default value to true (On) if key doesn't exist
                defaults.set(true, forKey: "isChecked1")
            }
            
            // Set the switch value based on UserDefaults
            notification2.isOn = defaults.bool(forKey: "isChecked1")
        
        notification2.addTarget(self, action: #selector(notificationSwitch1DidChange(_:)), for: .valueChanged)
        
        self.title = "Notification Setting"
        
        // Retrieve the switch state from UserDefaults
        if let switchState = UserDefaults.standard.object(forKey: "SwitchState") as? Bool {
            // Update the switch state
            notification.isOn = switchState
        }
        
        if let switchState = UserDefaults.standard.object(forKey: "SwitchStateAllEntry") as? Bool {
            // Update the switch state
            notification2.isOn = switchState
        }
    }

    @objc func loadNativAd()
    {
        showHideNativeAdView()
        ClassGAD_New.shared.getGADNativeAd(adInfo: NativADNotification) { ad in
            self.vwNativeAd.showGADNativeAd(ad: ad,adView: .UnifiedNativeAd) { btn in
                btn.addTarget(self, action: #selector(self.openRemoveAdScreen), for: .touchUpInside)
            }
            
            
            if ad != nil{
                self.showHideNativeAdView(isHide: false)
                ClassGAD_New.shared.resetNativeAd(adInfo: NativADNotification)
            }
        }
    }

    private func clearNativeAdView() {
        // Clear the existing native ad view
        vwNativeAd.subviews.forEach { $0.removeFromSuperview() }
    }
    
    func notificationSwitchDidChange(isOn: Bool) {
            // Handle the switch state change
            delegate?.notificationSwitchDidChange(isOn: isOn)
        }
    
    private func showHideNativeAdView(isHide:Bool = true){
        vwNativeAd.isHidden = isHide
        view_height.constant = isHide ? 0 : 300
        
        //vwNativeAd.bord
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
    
    @objc func notificationSwitchDidChange(_ sender: UISwitch) {
        let defaults = UserDefaults.standard
        defaults.set(sender.isOn, forKey: "isChecked")
        defaults.synchronize()
        
        if sender.isOn {
            sender.onTintColor = UIColor.black
            print("On")
            //Toast.show(message: "On")
        } else {
            print("Off")
            //Toast.show(message: "Off")
        }
    }
    
    func getDeviceID() -> String? {
        let device = UIDevice.current
        return device.identifierForVendor?.uuidString
    }
    
    func getOneSignalPlayerID(completion: @escaping (String?) -> Void) {
        // Prompt the user for push notification permission
        //OneSignal.promptForPushNotifications(userResponse: { accepted in
           // if accepted {
                // If the user accepts, retrieve the OneSignal player ID
                guard let oneSignal = OneSignal.User.pushSubscription.id else {
                    print("Failed to retrieve OneSignal player ID")
                    completion(nil)
                    return
                }
                
                // Use the playerID as needed
                print("OneSignal player ID: \(oneSignal)")
                completion(oneSignal)
//            } else {
//                // If the user rejects push notification permission
//                print("User rejected push notification permission")
//                completion(nil)
           // }
        //})
    }
    
    @objc func notificationSwitch1DidChange(_ sender: UISwitch) {
        let defaults = UserDefaults.standard
        defaults.set(sender.isOn, forKey: "isChecked1")
        defaults.synchronize()
        
        self.getOneSignalPlayerID { playerID in
            guard let playerID = playerID else {
                print("Failed to obtain OneSignal player ID")
                return
            }
            
            if let deviceID = self.getDeviceID() {
                print("OneSignal player ID: \(playerID)")
                print("Device ID: \(deviceID)")
                
                if let playerID = self.getDeviceID() {
                    print("OneSignal player ID: \(playerID)")
                    
                    if let deviceState = OneSignal.User.pushSubscription.id {
                        print("OneSignal Device ID: \(deviceState)")
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
                        let currentTime = dateFormatter.string(from: Date())
                        
                        self.toggleNotification(playerid: playerID)
                    } else {
                        print("Failed to obtain OneSignal Device ID")
                    }
                } else {
                    print("Failed to obtain player ID")
                }
            }
        }
        
        if sender.isOn {
            sender.onTintColor = UIColor.green
            print("Notification On successfully")
        } else {
            print("Notification Off")
        }
    }
    
    private func toggleNotification(playerid: String) {
        let onesignalDeviceId = self.onesignalDeviceId ?? ""
        
        let apiUrl = "https://money-manager-copilot-budget.aibible.in/api/daily-notification-on-off/\(playerid)"
        
        AF.request(apiUrl).responseJSON { response in
            switch response.result {
            case .success(let value):
                if let statusCode = response.response?.statusCode, statusCode == 200 {
                    print("Notification On successfully")
                } else {
                    print("Notification Off")
                }
            case .failure(let error):
                print("Notification Off")
                print("API Error: \(error)")
            }
        }
    }
    
    @IBAction func click_notification(_ sender: Any) {
        let isSwitchOn = notification2.isOn
        
//        // Store the switch state in UserDefaults
//        UserDefaults.standard.set(isSwitchOn, forKey: "SwitchState")
        // Store the switch state in UserDefaults
        UserDefaults.standard.set(isSwitchOn, forKey: "SwitchStateAllEntry")
        // Call the delegate method to inform the switch state change
       // delegate?.notificationSwitchDidChange(isOn: isSwitchOn)
    }
    
    
    @IBAction func click_noification_suspense(_ sender: Any) {
        let isSwitchOn = notification.isOn
        
        // Store the switch state in UserDefaults
        UserDefaults.standard.set(isSwitchOn, forKey: "SwitchState")
    
    }
    
    @IBAction func click_next(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}

