//
//  TransactionViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 13/10/23.
//

import UIKit
import CoreData

class TransactionViewController: UIViewController {
    
    @IBOutlet weak var tbllending: UITableView!
    @IBOutlet weak var tblborrow: UITableView!
    @IBOutlet weak var tblincome: UITableView!
    @IBOutlet weak var tblexpense: UITableView!
    
    @IBOutlet weak var tblexpense_height: NSLayoutConstraint!
    @IBOutlet weak var tblincome_height: NSLayoutConstraint!
    @IBOutlet weak var tblborrow_height: NSLayoutConstraint!
    @IBOutlet weak var tbllending_height: NSLayoutConstraint!
    
    @IBOutlet weak var lbllending: UILabel!
    @IBOutlet weak var lblincome: UILabel!
    @IBOutlet weak var lblborrow: UILabel!
    @IBOutlet weak var lblexpense: UILabel!
    @IBOutlet weak var lblreport: UILabel!
    
    var filterData: [NSManagedObject] = []
    var name : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        updateTotalLabels()
        
        lblreport.text = name
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tblexpense.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        self.tblincome.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        self.tblborrow.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        self.tbllending.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tblexpense.removeObserver(self, forKeyPath: "contentSize")
        self.tblincome.removeObserver(self, forKeyPath: "contentSize")
        self.tblborrow.removeObserver(self, forKeyPath: "contentSize")
        self.tbllending.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "contentSize", let newvalue = change?[.newKey] as? CGSize {
            let newSize = newvalue
            
            if object is UITableView {
                switch object as! UITableView {
                case tblexpense:
                    self.tblexpense_height.constant = newSize.height
                case tblincome:
                    self.tblincome_height.constant = newSize.height
                case tblborrow:
                    self.tblborrow_height.constant = newSize.height
                case tbllending:
                    self.tbllending_height.constant = newSize.height
                default:
                    break
                }
            }
        }
    }
    
    @IBAction func clickNavigate(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
    
    func updateTotalLabels() {
        // Initialize total variables
        var totalExpense = 0
        var totalIncome = 0
        var totalBorrowing = 0
        var totalLending = 0
        
        // Iterate through filterData to calculate totals
        for transaction in filterData {
            if let type = transaction.value(forKey: "type") as? String,
               let amount = transaction.value(forKey: "amount") as? Int {
                switch type {
                case "Expense":
                    totalExpense += amount
                case "Income":
                    totalIncome += amount
                case "Borrowing":
                    totalBorrowing += amount
                case "Lending":
                    totalLending += amount
                default:
                    break
                }
            }
        }
        
        // Update the total labels
        lblexpense.text = "\(totalExpense)"
        lblincome.text = "\(totalIncome)"
        lblborrow.text = "\(totalBorrowing)"
        lbllending.text = "\(totalLending)"
    }


    // Call this function whenever you need to update the total labels, e.g., in viewWillAppear

}

extension TransactionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // Filter data based on the table view
        let filteredData: [NSManagedObject]
        switch tableView {
        case tblincome:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Income" }
        case tblexpense:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Expense" }
        case tblborrow:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Borrowing" }
        case tbllending:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Lending" }
        default:
            filteredData = []
        }
        
        return filteredData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TransactionTableViewCell", for: indexPath) as! TransactionTableViewCell
        
        // Filter data based on the table view
        let filteredData: [NSManagedObject]
        switch tableView {
        case tblincome:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Income" }
        case tblexpense:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Expense" }
        case tblborrow:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Borrowing" }
        case tbllending:
            filteredData = filterData.filter { ($0.value(forKey: "type") as? String) == "Lending" }
        default:
            filteredData = []
        }
        
        // Ensure that the index is within the filtered data's bounds
        guard indexPath.row < filteredData.count else {
            // Handle an out-of-bounds case, e.g., return an empty cell
            return cell
        }
        
        // Configure the cell using filteredData
        let income = filteredData[indexPath.row]
        
        // Set the date in lbldate
        if let date = income.value(forKey: "date") as? Date {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            let formattedDate = dateFormatter.string(from: date)
            cell.lbldate.text = formattedDate
        } else {
            cell.lbldate.text = "N/A" // Set a default value or handle it as needed
        }
        
        // Set the note in lblnote
        if let note = income.value(forKey: "note") as? String {
            cell.lblnote.text = note
        } else {
            cell.lblnote.text = "N/A" // Set a default value or handle it as needed
        }
        
        // Set the amount in lblamount
        if let amount = income.value(forKey: "amount") as? Int {
            cell.lblamount.text = String(amount)
        } else {
            cell.lblamount.text = "N/A" // Set a default value or handle it as needed
        }
        
        if indexPath.row % 2 == 1 {
                // Even row
                cell.uiview.backgroundColor = UIColor(hex: "FFFFFF") // Use your preferred color
            } else {
                // Odd row
                cell.uiview.backgroundColor = UIColor(hex: "FFF2C2") // Use your preferred color
            }
        
        // You may need to configure other cell elements as well
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40.0
    }
}

