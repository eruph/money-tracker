//
//  AnalysisViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 14/10/23.
//

import UIKit
import CoreData
import MBProgressHUD

protocol BottomSheetVCDelegate: AnyObject {
    func didSelectAccount()
    func didSelectCategorywise()
    func didSelectHistory()
    //    func didSelectSuggestion()
    //    func didSelectHistory()
    //    func didSaveToIncome()
    //    func reloadTables()
    //    func updateTables()
    //    func didSelectNotification()
    //    func didSelectCategorywise()
    //func didSelectInApp()
}


class AnalysisViewController: UIViewController {
    
    weak var delegate: BottomSheetVCDelegate?
    var bottomSheetVC: AnalysisViewController?
    var main: [NSManagedObject] = []
    var dataSource = [[String: Any]]()
    var arrExpenseList: [[String: Any]] = [] // Declare the array for expense transactions
    var arrIncome: [[String: Any]] = []
    var arrAnother: [[String: Any]] = []
    
    @IBOutlet weak var expense_height: NSLayoutConstraint!
    @IBOutlet weak var tblexpense: UITableView!
    @IBOutlet weak var income_height: NSLayoutConstraint!
    @IBOutlet weak var tblincome: UITableView!
    @IBOutlet weak var img_feedback: UIImageView!
    @IBOutlet weak var img_history: UIImageView!
    @IBOutlet weak var img_category: UIImageView!
    @IBOutlet weak var img_notification: UIImageView!
    @IBOutlet weak var img_report: UIImageView!
    @IBOutlet weak var tblsuspense: UITableView!
    @IBOutlet weak var tbl_suspense_height: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Analysis Report"
        
        let gif1 = UIImage.gifImageWithName("report")
        img_report.image = gif1
        
        let gif2 = UIImage.gifImageWithName("notification")
        img_notification.image = gif2
        
        let gif3 = UIImage.gifImageWithName("list")
        img_category.image = gif3
        
        let gif4 = UIImage.gifImageWithName("history")
        img_history.image = gif4
        
        let gif5 = UIImage.gifImageWithName("feedback")
        img_feedback.image = gif5
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleDataUpdateNotification(_:)), name: Notification.Name("DataUpdateNotification"), object: nil)
        
        tblexpense.delegate = self
        tblexpense.dataSource = self
        
        tblincome.delegate = self
        tblincome.dataSource = self
        
        tblsuspense.delegate = self
        tblsuspense.dataSource = self
        
        loadTransactions()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc func handleDataUpdateNotification(_ notification: Notification) {
        print("handleDataUpdateNotification called")
        
        // Retrieve the data from the notification
        guard let userInfo = notification.userInfo as? [String: Any],
              let type = userInfo["type"] as? String,
              let amount = userInfo["amount"] as? Int,
              let category = userInfo["category"] as? String,
              let note = userInfo["note"] as? String
                /*let date = userInfo["date"] as? Date*/ else {
                    self.tblexpense.reloadData()
                    return
                }
        
        print("Type: \(type)")
        print("Amount: \(amount)")
        print("Category: \(category)")
        print("Note: \(note)")
        //print("Date: \(date)")
        
        let newDataItem = ["type": type, "amount": amount, "category": category, "note": note] as [String : Any]
        dataSource.append(newDataItem)
        
        loadTransactions()
    }
    
    func loadTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Main")
        
        do {
            main = try managedContext.fetch(fetchRequest)
            
            // Clear existing arrays
            arrExpenseList.removeAll()
            arrIncome.removeAll()
            arrAnother.removeAll() // Clear the arrAnother array
            
            // Categorize transactions into expense, income, and another arrays
            for transaction in main {
                if let type = transaction.value(forKey: "type") as? String,
                   let category = transaction.value(forKey: "category") as? String,
                   let note = transaction.value(forKey: "note") as? String,
                   let amount = transaction.value(forKey: "amount") as? Int {
                    
                    let transactionData: [String: Any] = [
                        "type": type,
                        "category": category,
                        "note": note,
                        "amount": amount
                        //"date": date
                    ]
                    
                    if type == "Expense" {
                        arrExpenseList.append(transactionData)
                    } else if type == "Income" {
                        arrIncome.append(transactionData)
                    } else if type == "Suspense" {
                        // Store other transactions in the arrAnother array
                        arrAnother.append(transactionData)
                    }
                }
            }
            
            // Reload table views
            tblexpense.reloadData()
            tblincome.reloadData()
            tblsuspense.reloadData()
            
        } catch {
            print("Error fetching transactions: \(error)")
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tblexpense.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        self.tblincome.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        self.tblsuspense.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tblexpense.removeObserver(self, forKeyPath: "contentSize")
        self.tblincome.removeObserver(self, forKeyPath: "contentSize")
        self.tblsuspense.removeObserver(self, forKeyPath: "contentSize")
    }
    
    @IBAction func click_accountant(_ sender: Any) {
      
    }
    
    func navigateToReportVC() {
        let mainFamilyVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AccountReportViewController") as! AccountReportViewController
        
        // Ensure that the navigation is performed from a visible view controller
        if let navigationController = self.navigationController {
            navigationController.pushViewController(mainFamilyVC, animated: true)
        } else {
            // If the current view controller is not part of a navigation controller, present the new view controller modally
            self.present(mainFamilyVC, animated: true, completion: nil)
        }
    }
    
//    @IBAction func click_cateogry_wise(_ sender: Any) {
//        // Navigate to the Create QR screen directly if ads have been purchased
//        if CommonConst.isPurchasedRemoveAds {
//            navigateToCategoryReportVC()
//            return
//        }
//        
//        // Show a progress indicator (MBProgressHUD)
//        let hud = MBProgressHUD.showAdded(to: self.view, animated: true)
//        hud.mode = .indeterminate
//        hud.label.text = "Loading"
//        
//        // Set up the ad dismissal callback
//        ClassGAD.shared.adDismissedCallback = { [weak self] in
//            DispatchQueue.main.async {
//                hud.hide(animated: true)
//                self?.navigateToCategoryReportVC()
//            }
//        }
//        
//        // Load and present the interstitial ad with a timeout of 5 seconds
//        ClassGAD.shared.loadAndPresentInterstitialAd_CategoryReport {
//            DispatchQueue.main.async {
//                hud.hide(animated: true)
//                self.navigateToCategoryReportVC()
//            }
//        }
//        
//        // Wait for 5 seconds, and if the ad is still not loaded, navigate to the next view controller
////        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
////            if ClassGAD.shared.interstitialAdCategoryReport == nil {
////                hud.hide(animated: true)
////                self.navigateToCategoryReportVC()
////            }
////        }
//    }
    
    func navigateToCategoryReportVC() {
        let mainFamilyVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CategoryFilterViewController") as! CategoryFilterViewController
        
        // Ensure that the navigation is performed from a visible view controller
        if let navigationController = self.navigationController {
            navigationController.pushViewController(mainFamilyVC, animated: true)
        } else {
            // If the current view controller is not part of a navigation controller, present the new view controller modally
            self.present(mainFamilyVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func click_btn_history(_ sender: Any) {
        let vc = mainStoryBoard.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
        self.navigationController!.pushViewController(vc, animated: true)
    }
    
    @IBAction func click_notification(_ sender: Any) {
        let vc = mainStoryBoard.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        self.navigationController!.pushViewController(vc, animated: true)
    }
    
    func didSelectAccount() {
        self.delegate?.didSelectAccount()
        dismiss(animated: true, completion: nil)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "contentSize", let newvalue = change?[.newKey] as? CGSize {
            let newSize = newvalue
            
            if object is UITableView {
                switch object as! UITableView {
                case tblexpense:
                    self.expense_height.constant = newSize.height
                case tblincome:
                    self.income_height.constant = newSize.height
                case tblsuspense:
                    self.tbl_suspense_height.constant = newSize.height
                default:
                    break
                }
            }
        }
    }
    
    func openCustomBudget_Inc_Exp_ViewController(index: Int, lblamount: Int?, lblcategory: String?, lblnote: String?, lbltype: String?) {
        let addSuspenseVC = storyboard?.instantiateViewController(withIdentifier: "AddSuspenseVC") as! AddSuspenseVC
        //addSuspenseVC.passedValue = lblname
        addSuspenseVC.passedamount = lblamount
        addSuspenseVC.passednote = lblnote
        addSuspenseVC.passedcategory = lblcategory
        addSuspenseVC.passedrealnote = lblnote
        addSuspenseVC.passedtype = lbltype
        addSuspenseVC.isBlueButtonHidden = false
        
        // Present the AddSuspenseVC
        present(addSuspenseVC, animated: true, completion: nil)
    }
    
    func deleteData(lblnote: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "note == %@", lblnote)
        
        do {
            guard let result = try managedContext.fetch(fetchRequest) as? [NSManagedObject], let objectToDelete = result.first else {
                return
            }
            managedContext.delete(objectToDelete)
            
            do {
                try managedContext.save()
                print("Data deleted")
            } catch let error as NSError {
                print("Failed to save context after deleting data: \(error), \(error.userInfo)")
            }
        } catch let error as NSError {
            print("Failed to fetch data for deletion: \(error), \(error.userInfo)")
        }
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
}

extension AnalysisViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblincome {
            return arrIncome.count + 1
        } else if tableView == tblexpense {
            return arrExpenseList.count + 1
        } else if tableView == tblsuspense {
            return arrAnother.count
        }
        
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExpenseTableViewCell", for: indexPath) as! ExpenseTableViewCell
        
        // Reset formatting for all cells
        cell.lbl_amount.textColor = .black
        cell.lbl_amount.font = UIFont.systemFont(ofSize: 12)
        
        if tableView == tblincome {
            if indexPath.row < arrIncome.count {
                let transaction = arrIncome[indexPath.row]
                cell.lblnote.text = transaction["note"] as? String
                
                if let amount = transaction["amount"] as? Int {
                    cell.lbl_amount.text = String(amount)
                    cell.lbl_amount.textColor = .green
                } else {
                    cell.lbl_amount.text = nil
                }
            } else {
                // Calculate and display total income
                let totalIncome = arrIncome.reduce(0) { $0 + ($1["amount"] as? Int ?? 0) }
                cell.lblnote.text = "Total Income :"
                cell.lblnote.font = UIFont.boldSystemFont(ofSize: 11)
                cell.lbl_amount.text = String(totalIncome)
                // Apply formatting for total income cell
                cell.lbl_amount.textColor = .green
                cell.lbl_amount.font = UIFont.boldSystemFont(ofSize: 12) // Set to bold
            }
        } else if tableView == tblexpense {
            if indexPath.row < arrExpenseList.count {
                let transaction = arrExpenseList[indexPath.row]
                cell.lblnote.text = transaction["note"] as? String
                
                if let amount = transaction["amount"] as? Int {
                    cell.lbl_amount.text = String(amount)
                    cell.lbl_amount.textColor = .red
                } else {
                    cell.lbl_amount.text = nil
                }
            } else {
                // Calculate and display total expense
                let totalExpense = arrExpenseList.reduce(0) { $0 + ($1["amount"] as? Int ?? 0) }
                cell.lblnote.text = "Total Expense :"
                cell.lblnote.font = UIFont.boldSystemFont(ofSize: 11)
                cell.lbl_amount.text = String(totalExpense)
                // Apply formatting for total expense cell
                cell.lbl_amount.textColor = .red
                cell.lbl_amount.font = UIFont.boldSystemFont(ofSize: 12) // Set to bold
            }
        } else if tableView == tblsuspense {
            cell.lbl_amount.isHidden = true
            let transaction = arrAnother[indexPath.row]
            cell.lblnote.text = transaction["note"] as? String
            
            if let amount = transaction["amount"] as? Int {
                cell.lbl_amount.text = String(amount)
                cell.lbl_amount.textColor = .red
            } else {
                cell.lbl_amount.text = nil
            }
            //cell.lblnote.text = transaction["note"] as? String
            cell.lbl_type.text = transaction["type"] as? String
            cell.lbl_cateogry.text = transaction["category"] as? String
            
            cell.addButtonAction = { [weak self] index in
                print(index)
                self?.openCustomBudget_Inc_Exp_ViewController(index: index, lblamount: Int(cell.lbl_amount.text ?? ""), lblcategory: cell.lbl_cateogry.text, lblnote: cell.lblnote.text, lbltype: cell.lbl_type.text)
            }
            
            cell.btn_edit.tag = indexPath.row
            cell.deleteButtonAction = { [weak self] index in
                guard let self = self else { return }
                
                let type = cell.lbl_type.text!
                let amount = Int(cell.lbl_amount.text ?? "") ?? 0
                let category = cell.lbl_cateogry.text!
                let note = cell.lblnote.text!
                //let name = cell.lblname.text!
                
                let alert = UIAlertController(title: "Confirm Deletion", message: "Are you sure you want to delete this record?", preferredStyle: .alert)
                
                let confirmAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
                    self.deleteData(lblnote: cell.lblnote.text!)
                    
                    let userInfo: [String: Any] = [
                        "type": type,
                        "amount": amount,
                        "category": category,
                        "note": note,
                    ]
                    
                    NotificationCenter.default.post(name: Notification.Name("DataUpdateNotification"), object: nil, userInfo: userInfo)
                    self.loadTransactions()
                }
                
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                
                alert.addAction(confirmAction)
                alert.addAction(cancelAction)
                
                self.present(alert, animated: true, completion: nil)
            }
            
            cell.btn_close.tag = indexPath.row
        }
        return cell
    }
}


