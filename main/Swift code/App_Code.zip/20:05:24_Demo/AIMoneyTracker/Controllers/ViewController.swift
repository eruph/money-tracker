//
//  ViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 17/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var SCROLLVIEW: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardAppear), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardDisappear), name: UIResponder.keyboardWillHideNotification,object: nil)
    }
    
    var isExpand : Bool = false
    
    @IBAction func click_done(_ sender: Any) {
        view.endEditing(true)
    }
    
    @objc func keyboardAppear() {
        if !isExpand {
            self.SCROLLVIEW.contentSize = CGSize(width: self.view.frame.width, height: self.SCROLLVIEW.frame.height + 200)
            isExpand = true
        }
    }
    
    @objc func keyboardDisappear() {
        if isExpand {
            self.SCROLLVIEW.contentSize = CGSize(width: self.view.frame.width, height: self.SCROLLVIEW.frame.height - 150)
            isExpand = false
        }
    }
}
