//
//  FeaturesViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 12/10/23.
//

import UIKit
import MBProgressHUD

struct MainProduct {
    //let image: UIImage
    let label2: String
    let label1: String
}

class FeaturesViewController: UIViewController {
    
    @IBOutlet weak var tblmain: UITableView!
//    @IBOutlet weak var vwCardBannerAd: UIView!
//    @IBOutlet weak var vwBannerAd: UIView!
//    @IBOutlet weak var nslcHeightVwBannerCard: NSLayoutConstraint!
    
    var bannerAdSize:CGSize? = nil
    let array: [MainProduct] = [
        MainProduct(label2: "You can see your All Expense, Income, Borrowing and Lending Report", label1: "Transaction Report"),
        MainProduct(label2: "View your categorized reports for all expenses, incomes, borrowings, and lendings.", label1: "Category Wise Transaction"),
        MainProduct(label2: "Settings allow users to control how and when they receive alerts and notifications from apps", label1: "Notification"),
        MainProduct(label2: "Complete transaction history encompassing income, expenses, borrowings, and lendings.", label1: "All Transaction")
    ]
    
    let gifNames = [
        "report",
        "list",
        "notification",
        "history"
    ]
    
    let adsRunValue = ClassGAD_New.shared.adsRunValue
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblmain.separatorStyle = .none
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // Load the interstitial ad when the view is loaded
        loadInterstitialAdIfNeeded()
        //self.loadBannerAd()
    }
    
    private func loadInterstitialAdIfNeeded() {
        ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADTransactionReport, isNeedToPresent: false)
        
        ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADCategoryReport, isNeedToPresent: false)
    }
}

extension FeaturesViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainCell", for: indexPath) as! MainCell
        
        let product = array[indexPath.row]
        cell.lbl1.text = product.label1
        cell.lbl2.text = product.label2
        
        if indexPath.row < gifNames.count {
            if let gifImage = UIImage.gifImageWithName(gifNames[indexPath.row]) {
                cell.img.image = gifImage
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true) // Deselect the selected row
        
        switch indexPath.row {
        case 0:
            ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADTransactionReport) {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AccountReportViewController") as! AccountReportViewController
                vc.hidesBottomBarWhenPushed = true
                self.navigationController?.pushViewController(vc, animated: true)
                print("1....")
            }
            
        case 1:
            ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADCategoryReport) {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "CategoryFilterViewController") as! CategoryFilterViewController
                vc.hidesBottomBarWhenPushed = true
                self.navigationController?.pushViewController(vc, animated: true)
            }
            
        case 2:
            // Navigate to Router Setting view controller
            let routerSettingVC = storyboard?.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
            routerSettingVC.hidesBottomBarWhenPushed = true
            navigationController?.pushViewController(routerSettingVC, animated: true)
            
        case 3:
            // Navigate to Router Setting view controller
            let routerSettingVC = storyboard?.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
            routerSettingVC.hidesBottomBarWhenPushed = true
            navigationController?.pushViewController(routerSettingVC, animated: true)
            
        default:
            break
        }
    }
}

