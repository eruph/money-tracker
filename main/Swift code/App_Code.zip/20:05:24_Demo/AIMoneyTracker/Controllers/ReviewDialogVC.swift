//
//  ReviewDialogVC.swift
//  AIMoneyTracker
//
//  Created by Apple on 16/05/24.
//

import UIKit
import StoreKit

class ReviewDialogVC: UIViewController {
    
    @IBOutlet var starButtons: [UIButton]!
    @IBOutlet weak var newview: UIView!
    @IBOutlet weak var star_img: UIImageView!
    @IBOutlet weak var btnsubmit: UIButton!
    @IBOutlet weak var btncancel: UIButton!
    @IBOutlet weak var btn_notnow: UIButton!
    @IBOutlet weak var btnstar_1: UIButton!
    @IBOutlet weak var btnstar_4: UIButton!
    @IBOutlet weak var btnstar_3: UIButton!
    @IBOutlet weak var btnstar_2: UIButton!
    @IBOutlet weak var btnstar_5: UIButton!
    
    let transparentView = UIView()
    let duration: Double = 1
    var home = MainViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        newview.layer.cornerRadius = 15
        view.alpha = 0
        newview.transform = CGAffineTransform(scaleX: 0, y: 0)
        btncancel.isHidden = true
        btnsubmit.isHidden = true
        
        newview.frame.size.height = 300
        //
        let star = UIImage.gifImageWithName("source")
        star_img.image = star
        
    }
    
    func Toast(Title:String,Text:String,delay:Int) -> Void {
        let alert = UIAlertController(title: Title, message: Text, preferredStyle: .alert)
        self.present(alert,animated: true)
        let deadlineTime = DispatchTime.now() + .seconds(delay)
        DispatchQueue.main.asyncAfter(deadline: deadlineTime, execute: {
            alert.dismiss(animated: true, completion: nil)
        })
    }
    
    func showAnimation(isShow:Bool){
        UIView.animate(withDuration: isShow ? 0.40 : 0.40, delay: 0, options: .curveEaseOut) {
            self.newview.transform = isShow ? .identity : CGAffineTransform(scaleX: 0.01, y: 0.01)
            self.view.alpha = isShow ? 1 : 0
        } completion: { isCompleted in
            if !isShow{
                self.dismiss(animated: false, completion: nil)
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showAnimation(isShow: true)
    }
    
    func removedialog() {
        btnstar_5.isSelected = UserDefaults.standard.bool(forKey: "isSaved")
    }
    
    @IBAction func btn_notnow(_ sender: Any) {
        self.showAnimation(isShow: false)
        //isDialogClosedOnce = true
        UserDefaults.standard.set(true, forKey: "isNotNowSelected")
    }
    
    @IBAction func buttonTapped(_ sender: Any) {
        guard let button = sender as? UIButton else {
            return
        }
        
        let val1 = button.tag
        
        if val1 >= 1 && val1 <= 4 {
            let ratingKey = "dialogTag\(val1)"
            UserDefaults.standard.set(val1, forKey: ratingKey)
            
            let title = "AIMoneyTracker"
            let text = "Thanks for \(val1) Rating"
            Toast(Title: title, Text: text, delay: 1)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.showAnimation(isShow: false)
            }
        } else if val1 == 5 {
            UserDefaults.standard.set(val1, forKey: "dialogTag\(val1)")
            self.showAnimation(isShow: false)
            
            if #available(iOS 14.0, *) {
                ReviewManager.requestAppStoreReview()
            } else {
                // Fallback on earlier versions
            }
        }
        
        for button in starButtons {
            btncancel.isHidden = false
            btnsubmit.isHidden = false
            btn_notnow.isHidden = true
            
            if button.tag <= val1 {
                button.setImage(UIImage(named: "star_filled"), for: .normal)
            } else {
                button.setImage(UIImage(named: "star"), for: .normal)
            }
        }
    }
    
    @IBAction func click_btncancel(_ sender: Any) {
        newview.isHidden = true
    }
    
    @IBAction func click_btnsubmit(_ sender: Any) {
        
        Toast(Title: "iQ-Air App", Text: "Thank you", delay: 1)
        newview.isHidden = true
    }
}

class ReviewManager {
    
    static func openAppStoreReviewPage() {
        guard let writeReviewURL = URL(string: "https://apps.apple.com/app/id6468482628?action=write-review") else {
            fatalError("Expected a valid URL")
        }
        UIApplication.shared.open(writeReviewURL, options: [:], completionHandler: nil)
    }
    
    @available(iOS 14.0, *)
    static func requestAppStoreReview() {
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene else {
            print("Unable to get the window scene.")
            return
        }
        SKStoreReviewController.requestReview(in: scene)
    }
}






