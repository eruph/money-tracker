//
//  CategoryFilterViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import CoreData
import MBProgressHUD

enum RecordType {
    case income
    case expense
}


struct CategoryTotal {
    let categoryName: String
    let totalAmount: Int
    let image: UIImage
}

class CategoryFilterViewController: UIViewController {
    
    var categoryTotals: [CategoryTotal] = []
    var selectedStartDate: Date?
    var selectedEndDate: Date?
    var filteredCategoryTotals: [CategoryTotal] = []
    
    @IBOutlet weak var lblnodata: UILabel!
    @IBOutlet weak var imgempty: UIImageView!
    @IBOutlet weak var emptyview: UIView!
    @IBOutlet weak var category_height: NSLayoutConstraint!
    @IBOutlet weak var tblcategory: UITableView!
    @IBOutlet weak var lblenddate: UILabel!
    @IBOutlet weak var lblstartdate: UILabel!
    @IBOutlet weak var btn_end_date_range: UIButton!
    @IBOutlet weak var btn_start_date_range: UIButton!
    @IBOutlet weak var lbldimension: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let currentDate = Date()

        lblenddate.text = dateFormatter.string(from: currentDate)
        lblstartdate.text = dateFormatter.string(from: currentDate)
        
        tblcategory.delegate = self
        tblcategory.dataSource = self
        
        // Fetch category totals from both Expense and Income tables
        categoryTotals = fetchCategoryTotals()
        
        tblcategory.separatorStyle = .none
        
        self.title = "Category wise Expense"
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.tapFunction))
        let tap1 = UITapGestureRecognizer(target: self, action: #selector(self.tapFunction1))
        
        btn_start_date_range.isUserInteractionEnabled = true
        btn_start_date_range.addGestureRecognizer(tap)
        
        btn_end_date_range.isUserInteractionEnabled = true
        btn_end_date_range.addGestureRecognizer(tap1)
        
        // Display all data initially
        filteredCategoryTotals = categoryTotals
        tblcategory.reloadData()
        
        if filteredCategoryTotals.count == 0 {
            tblcategory.isHidden = true
            lblnodata.isHidden = false
            emptyview.isHidden = false
            imgempty.isHidden = false
        } else {
            tblcategory.isHidden = false
            lblnodata.isHidden = true
            emptyview.isHidden = true
            imgempty.isHidden = true
        }
    
//        if CommonConst.isPurchasedRemoveAds {
//            return
//        }
//
//        // Create a blurred background view
//        let blurEffect = UIBlurEffect(style: .light) // Adjust the style as needed
//        let blurView = UIVisualEffectView(effect: blurEffect)
//        blurView.frame = view.bounds
//        view.addSubview(blurView)
//
//        // Show a progress indicator (MBProgressHUD)
//        let hud = MBProgressHUD.showAdded(to: self.view, animated: true)
//        hud.mode = .indeterminate
//        hud.label.text = "Loading"
//
//        // Set up the ad dismissal callback
//        ClassGAD.shared.adDismissedCallback = { [weak self] in
//            DispatchQueue.main.async {
//                hud.hide(animated: true)
//                blurView.removeFromSuperview() // Remove the blur view when the ad is dismissed
//                // self?.navigateToMainVC()
//            }
//        }
//
//        // Create a timer for the ad loading timeout
//        let timeoutSeconds: Double = 8.0 // Use Double for the timeout
//        var timeoutTimer: Timer?
//
//        timeoutTimer = Timer.scheduledTimer(withTimeInterval: timeoutSeconds, repeats: false) { [weak self] _ in
//            if ClassGAD.shared.interstitialAdCategoryReport == nil {
//                DispatchQueue.main.async {
//                    hud.hide(animated: true)
//                    blurView.removeFromSuperview() // Remove the blur view on timeout
//                    // Handle the case when the ad loading times out
//                }
//            }
//        }
//
//        // Load and present the interstitial ad
//        ClassGAD.shared.loadAndPresentInterstitialAd_CategoryReport {
//            DispatchQueue.main.async {
//                // Invalidate the timer when the ad is loaded
//                timeoutTimer?.invalidate()
//                hud.hide(animated: true)
//                blurView.removeFromSuperview() // Remove the blur view when the ad is loaded
//                // self.navigateToMainVC()
//            }
//        }
    }
    
    @objc func tapFunction(sender: UITapGestureRecognizer) {
        self.createDatePicker()
    }
    
    @objc func tapFunction1(sender: UITapGestureRecognizer) {
        self.createDatePicker1()
    }
    
    // Create datepicker using storyboard and calling here
    func createDatePicker() {
        let datePickerController = storyboard?.instantiateViewController(withIdentifier: "CustomDatePickerVC") as! CustomDatePickerVC
        datePickerController.modalPresentationStyle = .overCurrentContext
        datePickerController.voidSelectedDate = { [weak self] selectedDate in
            self?.showSelectedStartDate(date: selectedDate)
        }
        navigationController?.present(datePickerController, animated: false, completion: nil)
    }
    
    // Create datepicker using storyboard and calling here
    func createDatePicker1() {
        let datePickerController = storyboard?.instantiateViewController(withIdentifier: "CustomDatePickerVC1") as! CustomDatePickerVC1
        datePickerController.modalPresentationStyle = .overCurrentContext
        datePickerController.voidSelectedDate = { [weak self] selectedDate in
            self?.showSelectedEndDate(date: selectedDate)
        }
        navigationController?.present(datePickerController, animated: false, completion: nil)
    }
    
    func showSelectedStartDate(date: Date) {
        selectedStartDate = date
        
        let formatter = DateFormatter()
        formatter.locale = .current
        formatter.dateFormat = "dd-MM-yyyy"
        
        let dateString = formatter.string(from: date)
        lblstartdate.text = dateString
        
        filterAndReloadTable()
    }
    
    func showSelectedEndDate(date: Date) {
        selectedEndDate = date
        
        let formatter = DateFormatter()
        formatter.locale = .current
        formatter.dateFormat = "dd-MM-yyyy"
        
        let dateString = formatter.string(from: date)
        lblenddate.text = dateString
        
        filterAndReloadTable()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.tblcategory.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.tblcategory.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey: Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "contentSize", let newvalue = change?[.newKey] as? CGSize {
            if object is UITableView {
                switch object as! UITableView {
                case tblcategory:
                    self.category_height.constant = newvalue.height
                default:
                    break
                }
            }
        }
    }
    
    func filterAndReloadTable() {
        guard let startDate = selectedStartDate, let endDate = selectedEndDate,
              let dimension = lbldimension.text?.lowercased(), !dimension.isEmpty else {
                  return
              }
        
        // Start date and end date are selected
        if startDate > endDate {
            //showToast(message: "Enter Proper Date")
            CustomToast.toastMessage(message: "Enter Proper Date", type: .NONE)
            return
        }
        
        let formattedStartDate = Calendar.current.startOfDay(for: startDate)
        let formattedEndDate = Calendar.current.startOfDay(for: endDate).addingTimeInterval(24 * 60 * 60) // Adding 1 day
        
        filteredCategoryTotals = categoryTotals.filter { categoryTotal in
            let categoryName = categoryTotal.categoryName
            
            var income: [NSManagedObject] = []
            var expense: [NSManagedObject] = []
            
            if dimension.contains("income") {
                income = fetchIncomeForCategory(categoryName: categoryName, startDate: formattedStartDate, endDate: formattedEndDate)
            }
            if dimension.contains("expense") {
                expense = fetchExpenseForCategory(categoryName: categoryName, startDate: formattedStartDate, endDate: formattedEndDate)
            }
            if dimension.contains("borrowing") {
                expense = fetchBorrowingForCategory(categoryName: categoryName, startDate: formattedStartDate, endDate: formattedEndDate)
            }
            if dimension.contains("lending") {
                expense = fetchLendingForCategory(categoryName: categoryName, startDate: formattedStartDate, endDate: formattedEndDate)
            }
            
            return !income.isEmpty || !expense.isEmpty
        }
        
        tblcategory.reloadData()
    }
    
    func showToast(message: String) {
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
        toastLabel.backgroundColor = UIColor.red.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.black
        toastLabel.font = UIFont.systemFont(ofSize: 12)
        toastLabel.textAlignment = .center
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true
        self.view.addSubview(toastLabel)
        
        UIView.animate(withDuration: 3.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: { _ in
            toastLabel.removeFromSuperview()
        })
    }
    
    func fetchRecordsForCategory(categoryName: String, startDate: Date, endDate: Date, recordType: RecordType) -> [NSManagedObject] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND date >= %@ AND date <= %@", categoryName, startDate as NSDate, endDate as NSDate)
        
        let isIncome = (recordType == .income)
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND date >= %@ AND date <= %@ AND isIncome == %d", categoryName, startDate as NSDate, endDate as NSDate, isIncome)
        
        do {
            let records = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return records
        } catch let error as NSError {
            print("Failed to fetch records for category \(categoryName): \(error), \(error.userInfo)")
            return []
        }
    }
    
    
    func fetchIncomeForCategory(categoryName: String, startDate: Date, endDate: Date) -> [NSManagedObject] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND date >= %@ AND date <= %@ AND type == %@", categoryName, startDate as NSDate, endDate as NSDate, "Income")
        
        do {
            let income = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return income
        } catch let error as NSError {
            print("Failed to fetch income for category \(categoryName): \(error), \(error.userInfo)")
            return []
        }
    }
    
    func fetchExpenseForCategory(categoryName: String, startDate: Date, endDate: Date) -> [NSManagedObject] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND date >= %@ AND date <= %@ AND type == %@", categoryName, startDate as NSDate, endDate as NSDate, "Expense")
        
        do {
            let income = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return income
        } catch let error as NSError {
            print("Failed to fetch income for category \(categoryName): \(error), \(error.userInfo)")
            return []
            
            print("item")
        }
    }
    
    func fetchBorrowingForCategory(categoryName: String, startDate: Date, endDate: Date) -> [NSManagedObject] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND date >= %@ AND date <= %@ AND type == %@", categoryName, startDate as NSDate, endDate as NSDate, "Borrowing")
        
        do {
            let income = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return income
        } catch let error as NSError {
            print("Failed to fetch income for category \(categoryName): \(error), \(error.userInfo)")
            return []
            
            print("item")
        }
    }
    
    func fetchLendingForCategory(categoryName: String, startDate: Date, endDate: Date) -> [NSManagedObject] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND date >= %@ AND date <= %@ AND type == %@", categoryName, startDate as NSDate, endDate as NSDate, "Lending")
        
        do {
            let income = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return income
        } catch let error as NSError {
            print("Failed to fetch income for category \(categoryName): \(error), \(error.userInfo)")
            return []
            
            print("item")
        }
    }
    
    func fetchAllDataForCategory(categoryName: String, startDate: Date, endDate: Date) -> [NSManagedObject] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND date >= %@ AND date <= %@", categoryName, startDate as NSDate, endDate as NSDate)
        
        do {
            let income = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return income
        } catch let error as NSError {
            print("Failed to fetch income for category \(categoryName): \(error), \(error.userInfo)")
            return []
        }
    }
    
    func fetchIncomeForCategory(categoryName: String) -> [NSManagedObject] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@", categoryName)
        
        do {
            let income = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return income
        } catch let error as NSError {
            print("Failed to fetch income for category \(categoryName): \(error), \(error.userInfo)")
            return []
        }
    }
    
    func fetchAllCategories() -> [String] {
        let expenseCategories = fetchAllCategories(forEntity: "Main")
        
        // Combine and remove duplicates
        var categoriesSet = Set<String>()
        categoriesSet.formUnion(expenseCategories)
        let categories = Array(categoriesSet)
        
        return categories
    }
    
    func fetchAllCategories(forEntity entityName: String) -> [String] {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return []
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.returnsDistinctResults = true
        fetchRequest.propertiesToFetch = ["category"]
        
        do {
            let result = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            
            // Extract unique categories from the result
            let categories = result.compactMap { $0.value(forKey: "category") as? String }
            
            return categories
        } catch let error as NSError {
            print("Failed to fetch categories for entity \(entityName): \(error), \(error.userInfo)")
            return []
        }
    }
    
    func fetchCategoryTotals() -> [CategoryTotal] {
        let allCategories = fetchAllCategories(forEntity: "Main")
        
        // Combine and remove duplicates
        var categoriesSet = Set<String>()
        categoriesSet.formUnion(allCategories)
        let categories = Array(categoriesSet)
        
        // Fetch the total amounts for each category
        var categoryTotals: [CategoryTotal] = []
        
        for category in categories {
            var image: UIImage?
            
            if fetchIsIncomeForCategory(categoryName: category, type: "Income") {
                image = UIImage(named: "Home_Income") // Set the green image for income category
            } else if fetchIsExpenseForCategory(categoryName: category, type: "Expense") {
                image = UIImage(named: "Home_Expense") // Set the image for expense category
            } else if fetchIsBorrowingForCategory(categoryName: category, type: "Borrowing") {
                image = UIImage(named: "Home_Borrowing")
            } else if fetchIsLendingForCategory(categoryName: category, type: "Lending") {
                image = UIImage(named: "lending")
            }
            
            if let image = image {
                let totalAmount = fetchTotalAmountForCategory(categoryName: category, entityName: "Main")
                let categoryTotal = CategoryTotal(categoryName: category, totalAmount: totalAmount, image: image)
                categoryTotals.append(categoryTotal)
            } else {
                print("Hello")
                // Handle the case when the image is not found (nil)
                // You can use a default image or handle the situation as needed.
            }
        }
        
        return categoryTotals
    }
    
    func fetchIsIncomeForCategory(categoryName: String, type: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return false
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@", categoryName, "Income")
        
        do {
            let results = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return !results.isEmpty
        } catch let error as NSError {
            print("Failed to fetch income category status for category \(categoryName): \(error), \(error.userInfo)")
            return false
        }
    }
    
    func fetchIsExpenseForCategory(categoryName: String, type: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return false
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@", categoryName, "Expense")
        
        do {
            let results = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return !results.isEmpty
        } catch let error as NSError {
            print("Failed to fetch income category status for category \(categoryName): \(error), \(error.userInfo)")
            return false
        }
    }
    
    func fetchIsBorrowingForCategory(categoryName: String, type: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return false
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@", categoryName, "Borrowing")
        
        do {
            let results = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return !results.isEmpty
        } catch let error as NSError {
            print("Failed to fetch income category status for category \(categoryName): \(error), \(error.userInfo)")
            return false
        }
    }
    
    func fetchIsLendingForCategory(categoryName: String, type: String) -> Bool {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return false
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@", categoryName, "Lending")
        
        do {
            let results = try managedContext.fetch(fetchRequest) as? [NSManagedObject] ?? []
            return !results.isEmpty
        } catch let error as NSError {
            print("Failed to fetch income category status for category \(categoryName): \(error), \(error.userInfo)")
            return false
        }
    }
    
    func fetchTotalAmountForCategory(categoryName: String, entityName: String) -> Int {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return 0
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = NSPredicate(format: "category == %@", categoryName)
        fetchRequest.resultType = .dictionaryResultType
        
        let sumExpression = NSExpression(forFunction: "sum:", arguments: [NSExpression(forKeyPath: "amount")])
        let sumDescription = NSExpressionDescription()
        sumDescription.name = "sumAmount"
        sumDescription.expression = sumExpression
        sumDescription.expressionResultType = .integer32AttributeType
        
        fetchRequest.propertiesToFetch = [sumDescription]
        fetchRequest.propertiesToGroupBy = ["category"]
        
        do {
            let results = try managedContext.fetch(fetchRequest) as? [NSDictionary] ?? []
            if let result = results.first,
               let totalAmount = result["sumAmount"] as? Int {
                return totalAmount
            }
        } catch let error as NSError {
            print("Failed to fetch total amount for category \(categoryName) in entity \(entityName): \(error), \(error.userInfo)")
        }
        return 0
    }
    
    @IBAction func clickNavigate(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func click_dimension(_ sender: Any) {
        let vc = mainStoryBoard.instantiateViewController(withIdentifier: "FilterAlertsVC") as! FilterAlertsVC
        vc.saveButtonHandler = { selectedValues in
            // Handle the selectedValues as needed
            // For example, join the selected values with a comma and update the lbldimension label
            let selectedText = selectedValues.joined(separator: ", ")
            self.lbldimension.text = selectedText
            //self.fetchAllDataForCategory(categoryName: "Clothes", startDate: Date(), endDate: Date())
            self.filterAndReloadTable()
        }
        vc.modalPresentationStyle = .overCurrentContext
        present(vc, animated: true, completion: nil)
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
}

extension CategoryFilterViewController: UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredCategoryTotals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategorywiseTableViewCell", for: indexPath) as! CategorywiseTableViewCell
        
        let categoryTotal = filteredCategoryTotals[indexPath.row]
        cell.lblcategoryname.text = categoryTotal.categoryName
        cell.lblamount.text = "\(categoryTotal.totalAmount)"
        cell.imgcategory.image = categoryTotal.image
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let categoryTotal = filteredCategoryTotals[indexPath.row]
        let categoryName = categoryTotal.categoryName
        
        let incomeViewController = storyboard?.instantiateViewController(withIdentifier: "IncExpViewController") as! IncExpViewController
        incomeViewController.selectedCategory = categoryName
        
        print(categoryName) // Print the selected category name
        
        navigationController?.pushViewController(incomeViewController, animated: true)
    }
}







