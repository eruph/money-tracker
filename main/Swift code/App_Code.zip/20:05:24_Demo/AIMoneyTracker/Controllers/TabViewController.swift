//
//  TabViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 12/10/23.
//

import UIKit

class TabViewController: UITabBarController, UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.delegate = self
        let selectedColor   = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        let unselectedColor = UIColor(red: 150.0/255.0, green: 253.0/255.0, blue: 253.0/255.0, alpha: 1.0)
        
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: unselectedColor], for: .normal)
        UITabBarItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: selectedColor], for: .selected)
    }
    
//    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
//        // Update the title and image of the tab bar item
//        
//        // Assuming you have a custom button with a title
//        if let customButton = tabBarController.selectedViewController?.navigationItem.rightBarButtonItem {
//            let buttonTitle = customButton.title ?? ""
//            
//            // Update the title of the tab bar item
//            tabBarController.tabBar.items?[tabBarController.selectedIndex].title = buttonTitle
//            
//            // Set the image of the tab bar item to a rendered image of the button's title
//            if let tabBarItem = tabBarController.tabBar.items?[tabBarController.selectedIndex] {
//                let image = UIImage(systemName: buttonTitle)
//                tabBarItem.image = image?.withRenderingMode(.alwaysOriginal)
//                tabBarItem.selectedImage = image?.withRenderingMode(.alwaysOriginal)
//            }
//        }
//    }
}


