//
//  HistoryViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import CoreData
import MobileCoreServices
import MBProgressHUD

class HistoryViewController: UIViewController, AddSuspenseVCDelegate {
    
    @IBOutlet weak var lblnodata: UILabel!
    @IBOutlet weak var emptyimg: UIImageView!
    @IBOutlet weak var histtoryview: CardViewNoBorder!
    @IBOutlet weak var history_height: NSLayoutConstraint!
    @IBOutlet weak var tblhistory: UITableView!
    @IBOutlet weak var vwNativeAd: UIView!
    @IBOutlet weak var uiview: CardView!
    @IBOutlet weak var view_height: NSLayoutConstraint!
    @IBOutlet weak var emptyview: UIView!
    
    let adsRunValue = ClassGAD_New.shared.adsRunValue
    var dataSource = [[String: Any]]()
    var history: [NSManagedObject] = []
    var parameterValue: String = ""
    var hist: HistoryViewController?
    var managedContext: NSManagedObjectContext!
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MoneyManagerBudgetCopilot") // Replace with your data model name
        container.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Unresolved error \(error)")
            }
        }
        return container
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleDataUpdateNotification(_:)), name: Notification.Name("DataUpdateHistory"), object: nil)
        
        //fetchRemoteConfig()
        //loadAndDisplayBannerAd()
        self.title = "History"
        retrieveData()
        
        loadNativAd()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)

        NotificationCenter.default.addObserver(self, selector: #selector(loadNativAd), name: .GADAdIDGet, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(loadNativAd), name: .isPurchased, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Fetch data from Core Data
        fetchHistoryData()
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
    
    @objc func loadNativAd()
    {
        showHideNativeAdView()
        ClassGAD_New.shared.getGADNativeAd(adInfo: NativADHistory) { ad in
            self.vwNativeAd.showGADNativeAd(ad: ad,adView: .UnifiedNativeAd) { btn in
                btn.addTarget(self, action: #selector(self.openRemoveAdScreen), for: .touchUpInside)
            }
            
            
            if ad != nil{
                self.showHideNativeAdView(isHide: false)
                ClassGAD_New.shared.resetNativeAd(adInfo: NativADHistory)
            }
        }
    }
    
    deinit {
        // Don't forget to remove the observer when the view controller is deinitialized
        NotificationCenter.default.removeObserver(self)
    }
    
    private func showHideNativeAdView(isHide:Bool = true){
        vwNativeAd.isHidden = isHide
        view_height.constant = isHide ? 0 : 300
        
        //vwNativeAd.bord
    }
    
    func saveFileToInternalStorage(fileData: Data, fileName: String) {
        do {
            let fileURL = try FileManager.default.url(for: .libraryDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                .appendingPathComponent(fileName)
            
            try fileData.write(to: fileURL)
            print("File saved successfully at: \(fileURL)")
        } catch {
            print("Error while saving the file: \(error.localizedDescription)")
        }
    }
    
    func getFileURL() -> URL? {
        do {
            let fileURL = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                .appendingPathComponent("backupData.txt")
            
            if FileManager.default.fileExists(atPath: fileURL.path) {
                return fileURL
            } else {
                print("File not found at path: \(fileURL.path)")
                return nil
            }
        } catch {
            print("Error while accessing the file URL: \(error.localizedDescription)")
            return nil
        }
    }
    
    // Backup and Share Data
    func backupDataAndShare() {
        do {
            if let fileURL = try CoreDataBackupManager.backupDataToFile() {
                print("Data backed up to file: \(fileURL)")
                
                // Save the file to internal storage
                let fileData = try Data(contentsOf: fileURL)
                let fileName = "backupData.txt"
                saveFileToInternalStorage(fileData: fileData, fileName: fileName)
                print("File name: \(fileName)")
                
                // Share the file
                if let internalFileURL = getBackupDataFileURL() {
                    shareFile(fileURL: internalFileURL)
                } else {
                    print("Internal file URL not found.")
                }
            } else {
                print("Failed to backup data.")
            }
        } catch {
            print("Error during backup: \(error.localizedDescription)")
        }
    }
    
    func fetchHistoryData() {
        let fetchRequest: NSFetchRequest<Main> = Main.fetchRequest()
        
        do {
            history = try persistentContainer.viewContext.fetch(fetchRequest)
            print(history, "History")
            tblhistory.reloadData()
        } catch {
            print("Error fetching data: \(error.localizedDescription)")
        }
    }
    
    // Share File
    func shareFile(fileURL: URL) {
        let activityViewController = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
        present(activityViewController, animated: true, completion: nil)
    }
    
    @IBAction func click_backup(_ sender: Any) {
        if CommonConst.isPurchasedRemoveAds {
        backupDataAndShare()
        } else {
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func click_restor(_ sender: Any) {
        if CommonConst.isPurchasedRemoveAds {
        let documentTypes = UIDocumentPickerViewController(documentTypes: ["public.plain-text"], in: .import)
        documentTypes.delegate = self
        documentTypes.allowsMultipleSelection = true
        present(documentTypes, animated: true, completion: nil)
        } else {
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func getBackupDataFileURL() -> URL? {
        // Provide the URL of the backup data file
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            return nil
        }
        
        let fileName = "backupData.txt"
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        return fileURL
    }
    
    func didAddDataToHistory() {
        // Reload your history table view here
        tblhistory.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tblhistory.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tblhistory.removeObserver(self, forKeyPath: "contentSize")
    }
    
    @objc func handleDataUpdateNotification(_ notification: Notification) {
        print("handleDataUpdateNotification called")
        
        // Retrieve the data from the notification
        guard let userInfo = notification.userInfo as? [String: Any],
              let type = userInfo["type"] as? String,
              let amount = userInfo["amount"] as? Int,
              let category = userInfo["category"] as? String,
              let note = userInfo["note"] as? String else {
                  self.tblhistory.reloadData()
                  return
              }
        
        print("Type: \(type)")
        print("Amount: \(amount)")
        print("Category: \(category)")
        print("Note: \(note)")
        
        let newDataItem = ["type": type, "amount": amount, "category": category, "note": note] as [String : Any]
        dataSource.append(newDataItem)
        //self.tblhistory.reloadData()
        retrieveData()
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        //if let obj = object as? UITableView {
        if keyPath == "contentSize",let newvalue = change?[.newKey]
        {
            let newSize = newvalue as! CGSize
            
            if object is UITableView{
                
                switch object as! UITableView{
                case tblhistory:
                    self.history_height.constant = newSize.height
                default:
                    break
                }
            }
        }
    }
    
    func retrieveData() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let historyFetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Main")
        
        do {
            history = try managedContext.fetch(historyFetchRequest)
            
            DispatchQueue.main.async {
                self.tblhistory.reloadData()
            }
            
            if history.count == 0 {
                emptyview.isHidden = false
                lblnodata.isHidden = false
                emptyimg.isHidden = false
                tblhistory.isHidden = true
                histtoryview.isHidden = true
            } else {
                emptyview.isHidden = true
                lblnodata.isHidden = true
                emptyimg.isHidden = true
                tblhistory.isHidden = false
                histtoryview.isHidden = false
            }
        } catch {
            print("Error fetching data: \(error)")
        }
    }
    
    func deleteAllData(primarykey: Int) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        // Find the index of the record to delete in the history array
        if let indexToDelete = history.firstIndex(where: { ($0.value(forKey: "primarykey") as? Int) == primarykey }) {
            // Delete the data from the History table
            let historyObjectToDelete = history[indexToDelete]
            managedContext.delete(historyObjectToDelete)
            
            // Delete the corresponding data from the Income, Expense, and Pending tables
            deleteRecordWithPrimaryKey(primarykey, entityName: "Main")
            
            
            do {
                try managedContext.save()
                print("Data deleted from AllData")
                
                // Remove the deleted record from the history array
                history.remove(at: indexToDelete)
                
                // Reload the tblhistory table view after deleting the history record
                DispatchQueue.main.async {
                    self.tblhistory.reloadData()
                }
            } catch let error as NSError {
                print("Failed to save context after deleting data: \(error), \(error.userInfo)")
            }
        }
    }
    
    func deleteRecordWithPrimaryKey(_ primaryKey: Int, entityName: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = NSPredicate(format: "primarykey == %d", primaryKey) // Use %d for integer
        
        do {
            let records = try managedContext.fetch(fetchRequest) as! [NSManagedObject]
            
            for recordToDelete in records {
                managedContext.delete(recordToDelete)
            }
            
            try managedContext.save() // Save the changes after deletion
        } catch {
            print("Error fetching records to delete for entity \(entityName) with primary key \(primaryKey): \(error)")
        }
    }
    
    func openCustomBudget_Inc_Exp_ViewController(index: Int, lblamount: Int?, lblcategory: String?, lblnote: String?, lbltype: String?, lblprompt: String?, lblprimary: Int?, notification_id: Int?) {
        let addSuspenseVC = storyboard?.instantiateViewController(withIdentifier: "AddSuspenseVC") as! AddSuspenseVC
        //addSuspenseVC.passedValue = lblname
        addSuspenseVC.passedamount = lblamount
        addSuspenseVC.passednote = lblnote
        addSuspenseVC.passedcategory = lblcategory
        addSuspenseVC.passedrealnote = lblnote
        addSuspenseVC.passedtype = lbltype
        addSuspenseVC.passedprimary = lblprimary
        addSuspenseVC.passedprompt = lblprompt
        addSuspenseVC.notification_id = notification_id
        addSuspenseVC.isBlueButtonHidden = false
        
        // Present the AddSuspenseVC
        addSuspenseVC.modalPresentationStyle = .overCurrentContext
        navigationController?.present(addSuspenseVC, animated: true, completion: nil)
    }
    
    @IBAction func clickNavigate(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
}

extension HistoryViewController: UITableViewDelegate, UITableViewDataSource {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return history.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let hcell = tblhistory.dequeueReusableCell(withIdentifier: "HistoryTableViewCell", for: indexPath) as! HistoryTableViewCell
//        
//        let income = history[indexPath.row]
//        if let date = income.value(forKey: "date") as? Date {
//            let dateFormatter = DateFormatter()
//            dateFormatter.dateFormat = "dd/MM/yyyy"
//            let formattedDate = dateFormatter.string(from: date)
//            hcell.lbldate.text = formattedDate
//        }
//        if let amount = income.value(forKey: "amount") as? Int {
//            hcell.lblamount.text = String(amount)
//        }
//        hcell.lblcategory.text = income.value(forKey: "category") as? String
//        if let type = income.value(forKey: "type") as? String {
//            hcell.lbltype.text = type.capitalized
//        }
//        hcell.lblnote.text = income.value(forKey: "note") as? String
//        
//        if let prompt = income.value(forKey: "prompt") as? String {
//            hcell.lblprompt.text = prompt
//        } else {
//            hcell.lblprompt.text = "N/A" // Set a default value or handle it as needed
//        }
//        
//        if let primarykey = income.value(forKey: "primarykey") as? Int {
//            hcell.lblprimary.text = String(primarykey)
//        } else {
//            hcell.lblprimary.text = "N/A" // Set a default value or handle it as needed
//        }
//        
//        let notification_id = income.value(forKey: "notification_id") as? Int
//        
//        // Set odd/even background colors
//        if indexPath.row % 2 == 1 {
//            // Even row
//            hcell.contentView.backgroundColor = UIColor(hex: "FFFFFF")
//        } else {
//            // Odd row
//            hcell.contentView.backgroundColor = UIColor(hex: "E5FFFF")
       // }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return history.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let hcell = tblhistory.dequeueReusableCell(withIdentifier: "HistoryTableViewCell", for: indexPath) as! HistoryTableViewCell
            
            // Check if the index is within bounds of the history array
            guard indexPath.row < history.count else {
                return hcell
            }
            
            let income = history[indexPath.row]
            
            if let date = income.value(forKey: "date") as? Date {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd/MM/yyyy"
                let formattedDate = dateFormatter.string(from: date)
                hcell.lbldate.text = formattedDate
            }
            if let amount = income.value(forKey: "amount") as? Int {
                hcell.lblamount.text = String(amount)
            }
            hcell.lblcategory.text = income.value(forKey: "category") as? String
            if let type = income.value(forKey: "type") as? String {
                hcell.lbltype.text = type.capitalized
            }
            hcell.lblnote.text = income.value(forKey: "note") as? String
            
            if let prompt = income.value(forKey: "prompt") as? String {
                hcell.lblprompt.text = prompt
            } else {
                hcell.lblprompt.text = "N/A" // Set a default value or handle it as needed
            }
            
            if let primarykey = income.value(forKey: "primarykey") as? Int {
                hcell.lblprimary.text = String(primarykey)
            } else {
                hcell.lblprimary.text = "N/A" // Set a default value or handle it as needed
            }
            
            // Set odd/even background colors
            if indexPath.row % 2 == 1 {
                // Even row
                hcell.contentView.backgroundColor = UIColor(hex: "FFFFFF")
            } else {
                // Odd row
                hcell.contentView.backgroundColor = UIColor(hex: "FFF2C2")
            }
        
            let notification_id = income.value(forKey: "notification_id") as? Int
            
//        hcell.deleteButtonAction = { [weak self] index in
//            guard let self = self else { return }
//            let alert = UIAlertController(title: "Confirm Deletion", message: "Are you sure you want to delete this record?", preferredStyle: .alert)
//            
//            let confirmAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
//                if let primarykeyText = hcell.lblprimary.text, let primarykey = Int(primarykeyText) {
//                    // Delete the record from Core Data
//                    self.deleteRecordWithPrimaryKey(primarykey, entityName: "Main")
//                    print("Record with primary key \(primarykey) deleted")
//                    // Remove the item from the history array and update the table view
//                    if index >= 0 && index < self.history.count {
//                        self.history.remove(at: index)
//                        
//                        // Reload the entire table view to reflect the updated data source
//                        self.tblhistory.reloadData()
//                    }
//                } else {
//                    // Handle the case where lblprimary.text is not a valid integer
//                    print("Invalid primary key format")
//                }
//            }
//            
//            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
//            
//            alert.addAction(confirmAction)
//            alert.addAction(cancelAction)
//            
//            self.present(alert, animated: true, completion: nil)
//        }
            hcell.deleteButtonAction = { [weak self] index in
                guard let self = self else { return }
                let alert = UIAlertController(title: "Confirm Deletion", message: "Are you sure you want to delete this record?", preferredStyle: .alert)
                
                let confirmAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
                    if let primarykeyText = hcell.lblprimary.text, let primarykey = Int(primarykeyText) {
                        // Delete the record from Core Data
                        self.deleteRecordWithPrimaryKey(primarykey, entityName: "Main")
                        print("Record with primary key \(primarykey) deleted")
                        
                        // Remove the item from the history array and update the table view
                        if index >= 0 && index < self.history.count {
                            self.history.remove(at: index)
                            self.tblhistory.reloadData()
                        }
                    } else {
                        // Handle the case where lblprimary.text is not a valid integer
                        print("Invalid primary key format")
                    }
                }
                
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
                
                alert.addAction(confirmAction)
                alert.addAction(cancelAction)
                
                self.present(alert, animated: true, completion: nil)
            }

        
        hcell.addButtonAction = { [weak self] index in
            print(index)
            guard let lblamountText = hcell.lblamount.text,
                  let lblcategoryText = hcell.lblcategory.text,
                  let lblnoteText = hcell.lblnote.text,
                  let lbltypeText = hcell.lbltype.text,
                  let lblpromptText = hcell.lblprompt.text,
                  let lblprimarykeyText = hcell.lblprimary.text,
                  let lblprimarykey = Int(lblprimarykeyText) else {
                      // Handle the case where one of the labels' text is not convertible to an integer
                      print("Invalid data format")
                      return
                  }
            
            self?.openCustomBudget_Inc_Exp_ViewController(
                index: index,
                lblamount: Int(lblamountText) ?? 0,
                lblcategory: lblcategoryText,
                lblnote: lblnoteText,
                lbltype: lbltypeText,
                lblprompt: lblpromptText,
                lblprimary: lblprimarykey,
                notification_id: notification_id
            )
        }
        
        let userInfo: [String: Any] = [
            "type": hcell.lbltype?.text ?? "",
            "amount": Int(hcell.lblamount?.text ?? "") ?? 0,
            "category": hcell.lblcategory?.text ?? "",
            "note": hcell.lblnote?.text ?? "",
            "prompt": hcell.lblprompt?.text ?? ""
        ]
        
        NotificationCenter.default.post(name: Notification.Name("DataUpdateNotification"), object: nil, userInfo: userInfo)
        self.hist?.retrieveData()
        
        return hcell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
}


extension HistoryViewController: UIDocumentPickerDelegate {
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
//        if let selectedFileURL = urls.first {
//                    // Handle the selected file here
//                    print("Selected file URL: \(selectedFileURL)")
//                }
        if let fileURL = urls.first {
            // Check if it's a valid file URL and proceed with data restoration
            do {
                guard let fileURL = getBackupDataFileURL() else {
                    print("Backup data file URL is not available.")
                    return
                }

                do {
                    try CoreDataBackupManager.restoreDataFromBackup(fileURL: fileURL)
                    print("Data restored successfully.")

                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "dd/MM/yyyy"

                    // Read and parse the contents of the restored file
                    if let restoredData = try? Data(contentsOf: fileURL),
                       let restoredString = String(data: restoredData, encoding: .utf8) {

                        // Parse the restoredString (assuming it's CSV-like data)
                        let rows = restoredString.components(separatedBy: "\n")

                        for row in rows {
                            if row.isEmpty {
                                continue
                            }

                            if row == "BackUp Of AIMoneyTracker" {
                                // Skip the header line
                                continue
                            }

                            let dataComponents = row.components(separatedBy: ",")

                            if dataComponents.count == 8 {
                                let newMain = Main(context: persistentContainer.viewContext)
                                newMain.amount = Int32(dataComponents[0]) ?? 0
                                newMain.category = dataComponents[1]
                                newMain.date = dateFormatter.date(from: dataComponents[2])
                                newMain.note = dataComponents[3]
                                newMain.type = dataComponents[4]
                                newMain.primarykey = Int16(dataComponents[5]) ?? 0
                                newMain.prompt = dataComponents[6]
                                newMain.time = dataComponents[7]
                            }
                        }

                        // Save the changes to Core Data
                        do {
                            try persistentContainer.viewContext.save()
                            print("Data saved in Core Data successfully.")
                            //view.makeToast("Data Restore Successfully.", position: .top)
                            self.navigationController?.popViewController(animated: true)
                            
                        } catch {
                            print("Error while saving data in Core Data: \(error.localizedDescription)")
                        }

                        DispatchQueue.main.async {
                            self.tblhistory.reloadData()
                        }
                        
                    } else {
                        print("Failed to read the restored file.")
                    }
                } catch {
                    print("Error during data restoration: \(error.localizedDescription)")
                }
            } catch {
                print("Error during data restoration: \(error.localizedDescription)")
            }
        }
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        // Handle the case when the user cancels the document picker
        print("Document picker was canceled")
    }
}






