//
//  AccountReportViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import CoreData
import MBProgressHUD
import Toast_Swift
import Foundation

class AccountReportViewController: UIViewController {
    
    @IBOutlet weak var year: UIButton!
    @IBOutlet weak var month: UIButton!
    @IBOutlet weak var week: UIButton!
    @IBOutlet weak var today: UIButton!
    @IBOutlet weak var nativeadview: UIView!
    @IBOutlet weak var native_height: NSLayoutConstraint!
    
    var filterData: [NSManagedObject] = []
    let adsRunValue = ClassGAD_New.shared.adsRunValue
    override func viewDidLoad() {
        super.viewDidLoad()
        
        hidesBottomBarWhenPushed = true
        self.title = "AI Accountant Report"
        // Fetch and display today's data by default
        fetchReports(for: .today)
        
        loadNativAd()
        
        NotificationCenter.default.addObserver(self, selector: #selector(loadNativAd), name: .GADAdIDGet, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(loadNativAd), name: .isPurchased, object: nil)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)
        
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
    
    @objc func loadNativAd()
    {
        showHideNativeAdView()
        ClassGAD_New.shared.getGADNativeAd(adInfo: NativADAccountReport) { ad in
            self.nativeadview.showGADNativeAd(ad: ad,adView: .UnifiedNativeAd) { btn in
                btn.addTarget(self, action: #selector(self.openRemoveAdScreen), for: .touchUpInside)
            }
            
            
            if ad != nil{
                self.showHideNativeAdView(isHide: false)
                ClassGAD_New.shared.resetNativeAd(adInfo: NativADAccountReport)
            }
        }
    }

    private func clearNativeAdView() {
        // Clear the existing native ad view
        nativeadview.subviews.forEach { $0.removeFromSuperview() }
    }
       
       private func showHideNativeAdView(isHide:Bool = true){
           nativeadview.isHidden = isHide
           native_height.constant = isHide ? 0 : 280
   
           //vwNativeAd.bord
       }

    // Function to fetch reports for the specified time interval
    func fetchReports(for timeInterval: TimeInterval) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Main")
        
        // Calculate the date for the time interval
        let calendar = Calendar.current
        var startDate: Date?
        
        switch timeInterval {
        case .today:
            startDate = calendar.startOfDay(for: Date())
        case .lastWeek:
            startDate = calendar.date(byAdding: .weekOfYear, value: -1, to: Date())
        case .lastMonth:
            startDate = calendar.date(byAdding: .month, value: -1, to: Date())
        case .lastYear:
            startDate = calendar.date(byAdding: .year, value: -1, to: Date())
        }
        
        if let startDate = startDate {
            fetchRequest.predicate = NSPredicate(format: "date >= %@", startDate as NSDate)
        }
        
        do {
            filterData = try managedContext.fetch(fetchRequest)
            //tblmain.reloadData()
        } catch let error as NSError {
            print("Error fetching data: \(error.localizedDescription)")
        }
    }
    
    // Enum for time intervals
    enum TimeInterval {
        case today
        case lastWeek
        case lastMonth
        case lastYear
    }
    
    @IBAction func clickNavigate(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    // Connect your action functions for different time intervals here
    @IBAction func clickTodayReport(_ sender: Any) {
        fetchReports(for: .today)
        print(filterData, "Today Data")
    }
    
    @IBAction func lastWeekReport(_ sender: Any) {
        fetchReports(for: .lastWeek)
        print(filterData, "Last Week Data")
    }
    
    @IBAction func lastMonthReport(_ sender: Any) {
        fetchReports(for: .lastMonth)
        print(filterData, "Last Month Data")
    }
    
    @IBAction func lastYearReport(_ sender: Any) {
        fetchReports(for: .lastYear)
        print(filterData, "Last Year Data")
    }
    
    @IBAction func showAnalysisController(_ sender: Any) {
        // Fetch reports and print the data
        if let button = sender as? UIButton {
            if button == today {
                fetchReports(for: .today)
                print(filterData, "Today Data")
                // Navigate to AnalysisController
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                if let analysisController = storyboard.instantiateViewController(withIdentifier: "TransactionViewController") as? TransactionViewController {
                    analysisController.name = "Today's Report"
                    analysisController.filterData = filterData
                    navigationController?.pushViewController(analysisController, animated: true)
                }
            } else if button == week {
                fetchReports(for: .lastWeek)
                print(filterData, "Last Week Data")
                // Navigate to AnalysisController
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                if let analysisController = storyboard.instantiateViewController(withIdentifier: "TransactionViewController") as? TransactionViewController {
                    analysisController.name = "Last Week's Report"
                    analysisController.filterData = filterData
                    navigationController?.pushViewController(analysisController, animated: true)
                }
            } else if button == month {
                fetchReports(for: .lastMonth)
                print(filterData, "Last Month Data")
                // Navigate to AnalysisController
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                if let analysisController = storyboard.instantiateViewController(withIdentifier: "TransactionViewController") as? TransactionViewController {
                    analysisController.name = "Last Month's Report"
                    analysisController.filterData = filterData
                    navigationController?.pushViewController(analysisController, animated: true)
                }
            } else if button == year {
                fetchReports(for: .lastYear)
                print(filterData, "Last Year Data")
                // Navigate to AnalysisController
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                if let analysisController = storyboard.instantiateViewController(withIdentifier: "TransactionViewController") as? TransactionViewController {
                    analysisController.name = "Last Year's Report"
                    analysisController.filterData = filterData
                    navigationController?.pushViewController(analysisController, animated: true)
                }
            }
        }
        
//        // Navigate to AnalysisController
//        let storyboard = UIStoryboard(name: "Main", bundle: nil)
//        if let analysisController = storyboard.instantiateViewController(withIdentifier: "TransactionViewController") as? TransactionViewController {
//            analysisController.filterData = filterData
//            navigationController?.pushViewController(analysisController, animated: true)
//        }
    }
}
