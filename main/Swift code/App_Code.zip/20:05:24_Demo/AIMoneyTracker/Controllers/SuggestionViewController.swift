//
//  SuggestionViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

struct Suggestion: Codable {
    let uniqueNumber: Int
    let date: String
    let time: String
    let note: String
    
    enum CodingKeys: String, CodingKey {
        case uniqueNumber
        case date
        case time
        case note
    }
    
    init(uniqueNumber: Int, date: String, time: String, note: String) {
        self.uniqueNumber = uniqueNumber
        self.date = date
        self.time = time
        self.note = note
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        uniqueNumber = try container.decode(Int.self, forKey: .uniqueNumber)
        date = try container.decode(String.self, forKey: .date)
        time = try container.decode(String.self, forKey: .time)
        note = try container.decode(String.self, forKey: .note)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(uniqueNumber, forKey: .uniqueNumber)
        try container.encode(date, forKey: .date)
        try container.encode(time, forKey: .time)
        try container.encode(note, forKey: .note)
    }
    
    // This static variable keeps track of the last generated unique number
    private static var lastUniqueNumber: Int = 0
    
    // This static method generates a new unique number
    static func generateUniqueNumber() -> Int {
        lastUniqueNumber += 1
        return lastUniqueNumber
    }
}

import CoreData
import Lottie

class SuggestionViewController: UIViewController {
    
    @IBOutlet weak var tblsuggestion: UITableView!
    
    var receivedData: [NSManagedObject]?
    var suggestions: [Suggestion] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        hidesBottomBarWhenPushed = true
        
        self.title = "Suggestion"
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)
        
        if let savedSuggestionsData = UserDefaults.standard.data(forKey: "suggestions"),
           let savedSuggestions = try? JSONDecoder().decode([Suggestion].self, from: savedSuggestionsData) {
            suggestions = savedSuggestions
        }
        
        print(receivedData, "ReceiveData")
        
        // Set the delegate and data source for the table view
        tblsuggestion.delegate = self
        tblsuggestion.dataSource = self
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
    
    @IBAction func click_suggestion(_ sender: Any) {
        if let receivedData = receivedData {
            let prompt = formatReceivedDataForAPI(receivedData) // Convert receivedData to a string format
            
            if receivedData.count >= 10 {
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let rewardVC = storyboard.instantiateViewController(withIdentifier: "SetSuggestionLoadingViewController") as! SetSuggestionLoadingViewController
                rewardVC.modalPresentationStyle = .overCurrentContext
                rewardVC.hidesBottomBarWhenPushed = true
                self.present(rewardVC, animated: true, completion: nil)
                
                APIManagers.shared.callAPISuggestion(with: prompt) { (type, amount, category, note, content) in
                    // Hide the Lottie animation when the API response is received
                    DispatchQueue.main.async {
                        //self.vwLottieAnimation.isHidden = true
                        self.dismiss(animated: true, completion: nil)
                        
                    }
                    // Handle the API response here
                    print(prompt, "Prompt")
                    print("Type: \(type)")
                    print("Amount: \(amount)")
                    print("Category: \(category)")
                    print("Note: \(note)")
                    print("Content: \(content)")
                    
                    let currentDate = Date() // This will give you the current date and time
                    
                    // If you want to format the date as a string, you can use a DateFormatter
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "dd-MM-yy" // Customize the date format as needed
                    let formattedDate = dateFormatter.string(from: currentDate)
                    
                    let currentTime = Date()
                    
                    // Create a DateFormatter to format the time
                    let timeFormatter = DateFormatter()
                    timeFormatter.dateFormat = "HH:mm:ss" // Customize the time format as needed
                    let formattedTime = timeFormatter.string(from: currentTime)
                    
                    // Create the Suggestion object here
                    let uniqueNumber = Suggestion.generateUniqueNumber()
                    let suggestion = Suggestion(uniqueNumber: uniqueNumber, date: formattedDate, time: formattedTime, note: note)
                    
                    // Append the suggestion to the suggestions array
                    self.suggestions.append(suggestion)
                    
                    // Save suggestions data to UserDefaults
                    if let encodedData = try? JSONEncoder().encode(self.suggestions) {
                        UserDefaults.standard.set(encodedData, forKey: "suggestions")
                    }
                    
                    // Reload the table view to reflect the new data
                    DispatchQueue.main.async {
                        self.tblsuggestion.reloadData()
                    }
                    
                    // Print the suggestion data
                    self.printSuggestionData()
                }
            } else {
                CustomToast.toastMessage(message: "Please Enter Minimum 10 records", type: .ERROR)
            }
        }
    }
    
    func formatReceivedDataForAPI(_ receivedData: [NSManagedObject]) -> String {
        var formattedData = ""
        
        for dataObject in receivedData {
            if let note = dataObject.value(forKey: "note") as? String,
               let amount = dataObject.value(forKey: "amount") as? Int,
               let type = dataObject.value(forKey: "type") as? String {
                
                // Create a prompt for each record and append it to formattedData
                let prompt = "\(type) \(amount)rs for \(note)"
                formattedData += prompt + "\n"
            }
        }
        return formattedData
    }
    
    func deleteSuggestion(at index: Int) {
        let alertController = UIAlertController(
            title: "Confirm Deletion",
            message: "Are you sure you want to delete this suggestion?",
            preferredStyle: .alert
        )
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        let deleteAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
            // Remove the suggestion from the array
            self.suggestions.remove(at: index)
            
            // Save the updated suggestions array to UserDefaults
            if let encodedData = try? JSONEncoder().encode(self.suggestions) {
                UserDefaults.standard.set(encodedData, forKey: "suggestions")
            }
            
            // Reload the table view to reflect the changes
            self.tblsuggestion.reloadData()
        }
        
        alertController.addAction(cancelAction)
        alertController.addAction(deleteAction)
        
        // Present the confirmation dialog
        present(alertController, animated: true, completion: nil)
    }
    
    func printSuggestionData() {
        for suggestion in suggestions {
            print("Date: \(suggestion.date)")
            print("Time: \(suggestion.time)")
            print("Note: \(suggestion.note)")
            print("---------------")
        }
    }
    
    @IBAction func click_next(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}

extension SuggestionViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return suggestions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SuggestionTableViewCell", for: indexPath) as! SuggestionTableViewCell
        
        let suggestion = suggestions[indexPath.row]
        
        // Configure the cell with data from the suggestion object
        cell.lblsuggestion.text = suggestion.note // Display the note
        cell.lbldate.text = suggestion.date
        cell.lbltime.text = suggestion.time
        cell.lblsuggestionnumber.text = "Suggestion \(indexPath.row + 1)"
        
        // Assign the delete action closure
        cell.onDeleteTapped = { [weak self] in
            self?.deleteSuggestion(at: indexPath.row)
        }
        return cell
    }
}

