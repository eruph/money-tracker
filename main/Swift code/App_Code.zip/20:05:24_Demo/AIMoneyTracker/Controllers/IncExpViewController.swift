//
//  IncExpViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import CoreData

struct IncomeRecord {
    let amount: Int
    let note: String
    let date: Date
    let type: String
}

class IncExpViewController: UIViewController {
    
    @IBOutlet weak var lbltitle: UILabel!
    @IBOutlet weak var tblinc_exp_filter: UITableView!
    @IBOutlet weak var lblcategory: UILabel!
    @IBOutlet weak var tblhieght: NSLayoutConstraint!
    
    var incomeRecords: [IncomeRecord] = []
    var category = ""
    var selectedCategory: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.lbltitle.text = selectedCategory
        lblcategory.text = selectedCategory
        fetchIncomeRecords(for: selectedCategory!)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tblinc_exp_filter.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tblinc_exp_filter.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "contentSize", let newvalue = change?[.newKey] as? CGSize {
            let newSize = newvalue
            
            if object is UITableView {
                switch object as! UITableView {
                case tblinc_exp_filter:
                    self.tblhieght.constant = newSize.height
                default:
                    break
                }
            }
        }
    }
    
    func fetchIncomeRecords(for category: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let incomeFetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        incomeFetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@ ", category, "Income")
        
        let expenseFetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        expenseFetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@", category, "Expense")
        
        let borrowFetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        borrowFetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@", category, "Borrowing")
        
        let lendingFetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        lendingFetchRequest.predicate = NSPredicate(format: "category == %@ AND type == %@", category, "Lending")
        
        do {
            let incomeResults = try managedContext.fetch(incomeFetchRequest) as? [NSManagedObject] ?? []
            let expenseResults = try managedContext.fetch(expenseFetchRequest) as? [NSManagedObject] ?? []
            let borrowResults = try managedContext.fetch(borrowFetchRequest) as? [NSManagedObject] ?? []
            let lendingResults = try managedContext.fetch(lendingFetchRequest) as? [NSManagedObject] ?? []
            
            // Map the fetched results from both entities to the IncomeRecord struct
            let incomeRecords = incomeResults.compactMap { result -> IncomeRecord? in
                guard let amount = result.value(forKey: "amount") as? Int,
                      let note = result.value(forKey: "note") as? String,
                      let date = result.value(forKey: "date") as? Date,
                      let type = result.value(forKey: "type") as? String else {
                          return nil
                      }
                
                return IncomeRecord(amount: amount, note: note, date: date, type: type)
            }
            
            let expenseRecords = expenseResults.compactMap { result -> IncomeRecord? in
                guard let amount = result.value(forKey: "amount") as? Int,
                      let note = result.value(forKey: "note") as? String,
                      let date = result.value(forKey: "date") as? Date,
                      let type = result.value(forKey: "type") as? String else {
                          return nil
                      }
                
                return IncomeRecord(amount: amount, note: note, date: date, type: type)
            }
            
            let borrowRecords = borrowResults.compactMap { result -> IncomeRecord? in
                guard let amount = result.value(forKey: "amount") as? Int,
                      let note = result.value(forKey: "note") as? String,
                      let date = result.value(forKey: "date") as? Date,
                      let type = result.value(forKey: "type") as? String else {
                          return nil
                      }
                
                return IncomeRecord(amount: amount, note: note, date: date, type: type)
            }
            
            let lendingRecords = lendingResults.compactMap { result -> IncomeRecord? in
                guard let amount = result.value(forKey: "amount") as? Int,
                      let note = result.value(forKey: "note") as? String,
                      let date = result.value(forKey: "date") as? Date,
                      let type = result.value(forKey: "type") as? String else {
                          return nil
                      }
                
                return IncomeRecord(amount: amount, note: note, date: date, type: type)
            }
            
            // Combine the fetched records from both entities
            self.incomeRecords = incomeRecords + expenseRecords + borrowRecords + lendingRecords
            
//            if incomeRecords.count == 0 {
//                tblinc_exp_filter.isHidden = true
//                imgempty.isHidden = false
//                lblnodata.isHidden = false
//                emptyview.isHidden = false
//            } else {
//                tblinc_exp_filter.isHidden = false
//                imgempty.isHidden = true
//                lblnodata.isHidden = true
//                emptyview.isHidden = true
//            }
//            
            tblinc_exp_filter.reloadData()
        } catch let error as NSError {
            print("Failed to fetch income/expense records for category \(category): \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

extension IncExpViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return incomeRecords.count + 1
    }
    
    //    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    //        let cell = tableView.dequeueReusableCell(withIdentifier: "Inc_Exp_FilterCell", for: indexPath) as! Inc_Exp_FilterCell
    //
    //        let record = incomeRecords[indexPath.row]
    //        //cell.lbltype.text = record.type
    //        if let type = record.type as? String {
    //            cell.lbltype.text = type.capitalized
    //        }
    //        cell.lblamount.text = "\(record.amount)"
    //        cell.lblnote.text = record.note
    //
    //        let dateFormatter = DateFormatter()
    //           dateFormatter.dateFormat = "dd/MM/yyyy" // Set the desired date format
    //
    //           cell.lbldate.text = dateFormatter.string(from: record.date)
    //
    //        return cell
    //    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "IncExpTableViewCell", for: indexPath) as! IncExpTableViewCell
        
        if indexPath.row < incomeRecords.count {
            let record = incomeRecords[indexPath.row]
            if let type = record.type as? String {
                cell.lbltype.text = type.capitalized
            }
            cell.lblamount.text = "\(record.amount)"
            cell.lblnote.text = record.note
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy" // Set the desired date format
            cell.lbldate.text = dateFormatter.string(from: record.date)
        } else {
            let totalAmount = incomeRecords.reduce(0) { $0 + $1.amount }
            cell.lbltype.isHidden = true
            cell.lbldate.isHidden = true
            cell.lblnote.text = "Total :"
            cell.lblnote.font = UIFont.boldSystemFont(ofSize: 12)
            cell.lblamount.text = "\(totalAmount)"
            cell.lblamount.textColor = .black
            cell.lblamount.font = UIFont.boldSystemFont(ofSize: 12) // Set to bold
        }
        
        return cell
    }
}



