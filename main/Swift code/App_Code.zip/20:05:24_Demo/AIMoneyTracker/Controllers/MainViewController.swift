//
//  MainViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import CoreData
import MBProgressHUD
//import OneSignal
import CoreLocation
import Lottie
import GoogleMobileAds
import Firebase
import StoreKit

class BudgetDataManager {
    static let shared = BudgetDataManager()
    
    private init() {} // Private initializer to ensure a single instance
    
    let isFakeReview : Bool = false
    var budgets: [Budget] = []
    
    // Load budgets from UserDefaults
    func loadBudgets() {
        if let savedBudgetData = UserDefaults.standard.data(forKey: "savedBudgets") {
            do {
                budgets = try JSONDecoder().decode([Budget].self, from: savedBudgetData)
            } catch {
                print("Error decoding budgets: \(error)")
            }
        }
    }
    
    // Save budgets to UserDefaults
    func saveBudgets() {
        if let encodedData = try? JSONEncoder().encode(budgets) {
            UserDefaults.standard.set(encodedData, forKey: "savedBudgets")
        }
    }
}

class MainViewController: UIViewController, AddSuspenseVCDelegate, MainMonthVCDelegate {
    func didUpdateBudgets(_ budgets: [Budget]) {
        self.budgets = budgets
        updateUIWithBudgetData()
    }
    
    
    @IBOutlet weak var tblmain: UITableView!
    var filterData: [NSManagedObject] = []
    var managedContext: NSManagedObjectContext!
    var history: [NSManagedObject] = []
    var dataSource = [[String: Any]]()
    
    var budgets: [Budget] = []
    
    @IBOutlet weak var lblmonthbudget: UILabel!
    @IBOutlet weak var lblnodata: UILabel!
    @IBOutlet weak var imgempty: UIImageView!
    @IBOutlet weak var emptyview: UIView!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var REWARDVIEW: CardView!
    @IBOutlet weak var view_height: NSLayoutConstraint!
    @IBOutlet weak var uiview: UIView!
    @IBOutlet weak var balance: UILabel!
    @IBOutlet weak var total_income: UILabel!
    @IBOutlet weak var total_expense: UILabel!
    @IBOutlet weak var lblamount: UILabel!
    @IBOutlet weak var lblmonth: UILabel!
    @IBOutlet weak var gifimage: UIImageView!
    @IBOutlet weak var btnpremium: UIButton!
    @IBOutlet weak var main_height: NSLayoutConstraint!
    
    var currentAmount: String?
    var currentMonthBudget: Budget?
    
    //var currentMonthBudget: Budget? = Budget(month: "", amount: 0.0)
    
    var main: MainMonthVC?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // main?.delegate = self
        
        //delegate?.didUpdateBudgets(budgets)
        if let tabBar = self.tabBarController?.tabBar {
                    tabBar.barTintColor = UIColor(named: "40CFCF")
                }
        
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        
        let currentMonthAndYear = formatter.string(from: Date())
        
        lblmonth.text = currentMonthAndYear
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap_RemoveAds(_:)))
        view.addGestureRecognizer(tapGesture)
        
        setupLottieAnimation()
        //fetchAndDisplayCurrentMonthData()
        
        //self.title = "Transaction"
        NotificationCenter.default.addObserver(self, selector: #selector(handleDataUpdateNotification(_:)), name: Notification.Name("DataUpdateHistory"), object: nil)
        
        // Add a tap gesture recognizer to the view
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tapGestureRecognizer)
        
        NotificationCenter.default.addObserver(self, selector: #selector(recordDeletedNotification(_:)), name: NSNotification.Name("RecordDeleted"), object: nil)
        
        //updateCurrentMonthBudget()
        //loadNativAd()
        tblmain.separatorStyle = .none
        //retrieveData()
        print(filterData, "FilterData")
        //retrieveDataTotal()
        navigationItem.setHidesBackButton(true, animated: false)
        //requestAppReview()
    }
    
    @objc func handleTap_RemoveAds(_ gesture: UITapGestureRecognizer) {
        // Increment the click count
        ClassGAD_New.shared.fetchRemoteConfig_RemoveAds()
        ClassGAD_New.clickedX += 1
        
        // Check if the clicked value matches the 'calculate' variable
        if ClassGAD_New.clickedX == ClassGAD_New.RemoveAdsClickCount {
            presentRemoveAdsVC()
            ClassGAD_New.clickedX = 0
        } else {
            continueWithAds()
        }
    }
    
    func presentRemoveAdsVC() {
        // Your code to present the RemoveAdsVC goes here
        if !CommonConst.isPurchasedRemoveAds {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            //self.present(vc, animated: true, completion: nil)
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func continueWithAds() {
        // Your code to continue with ads goes here
        print("Ads will continue")
    }
    
    func displayReviewDialog() {
        // Retrieve the value of isFackReview from UserDefaults
        let isFakeReview = UserDefaults.standard.bool(forKey: "isFackReview")
        let notnow = UserDefaults.standard.bool(forKey: "isNotNowSelected")
        
        // Assuming isFakeReview is a Boolean variable that determines whether to show the fake review dialog.
        if !isFakeReview {
            print(isFakeReview)
            if !notnow {
                // Delay time in seconds before showing the review dialog.
                let delayTime: DispatchTime = .now() + 3.0
                
                // Schedule the presentation using GCD after the specified delay.
                DispatchQueue.main.asyncAfter(deadline: delayTime) {
                    // Present the review dialog on the main thread.
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    //                if let reviewDialogVC = storyboard.instantiateViewController(withIdentifier: "ReviewDialogVC") as? ReviewDialogVC {
                    //                    reviewDialogVC.modalPresentationStyle = .overFullScreen
                    //                    reviewDialogVC.modalTransitionStyle = .crossDissolve
                    //                    print("Success")
                    //                    self.present(reviewDialogVC, animated: true, completion: nil)
                    //
                    //                    // Update UserDefaults after presenting the dialog
                    //                    //UserDefaults.standard.set(false, forKey: "isFackReview")
                    //                }
                    guard let audioSettingVC = storyboard.instantiateViewController(withIdentifier: "ReviewDialogVC") as? ReviewDialogVC else {
                        print("AudioSettingVC not found.")
                        return
                    }
                    audioSettingVC.modalPresentationStyle = .overCurrentContext
                    self.navigationController?.present(audioSettingVC, animated: true, completion: nil)
                }
            }
        }
    }
    
    func requestAppReview() {
            if #available(iOS 10.3, *) {
                SKStoreReviewController.requestReview()
            } else {
                // Fallback for earlier iOS versions, you can implement your own custom review prompt
                // For example, open a specific URL that directs users to the App Store page for your app
                if let appStoreURL = URL(string: "https://itunes.apple.com/app/id<your-app-id>") {
                    UIApplication.shared.open(appStoreURL, options: [:], completionHandler: nil)
                }
            }
        }
    
    @objc func recordDeletedNotification(_ notification: Notification) {
        // Handle the notification, for example, by reloading your data
        //retrieveData()
        loadTransactions()
    }
    
    func updateUIWithBudgetData() {
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM yyyy"
        let currentMonthNameAndYear = dateFormatter.string(from: currentDate)
        
        if let currentMonthBudget = BudgetDataManager.shared.budgets.first(where: { $0.month == currentMonthNameAndYear }) {
            lblmonthbudget.text = "Budget : \(currentMonthBudget.amount)"
        } else {
            lblmonthbudget.text = "No budget set"
        }
    }
  
    private func setupLottieAnimation(){
        let animationView = AnimationView(name: .lottie_chatai)
        animationView.frame = gifimage.bounds
        animationView.backgroundColor = .clear
        animationView.contentMode = .scaleAspectFit
        animationView.loopMode = .loop
        animationView.play()
        
        self.gifimage.addSubview(animationView)
    }
    
    private func loadInterstitialAdIfNeeded() {
        ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADSetMonthBudget, isNeedToPresent: false)
        
        ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADSeeAll, isNeedToPresent: false)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tblmain.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
        
        if let dialogTag1 = UserDefaults.standard.object(forKey: "dialogTag1") as? Int, dialogTag1 == 1 {
            // Handle dialogTag1 scenario
        } else if let dialogTag2 = UserDefaults.standard.object(forKey: "dialogTag2") as? Int, dialogTag2 == 2 {
            // Handle dialogTag2 scenario
        } else if let dialogTag3 = UserDefaults.standard.object(forKey: "dialogTag3") as? Int, dialogTag3 == 3 {
            // Handle dialogTag3 scenario
        } else if let dialogTag4 = UserDefaults.standard.object(forKey: "dialogTag4") as? Int, dialogTag4 == 4 {
            // Handle dialogTag4 scenario
        } else if let dialogTag5 = UserDefaults.standard.object(forKey: "dialogTag5") as? Int, dialogTag5 == 5 {
            // Handle dialogTag5 scenario
        } else {
            // Neither dialogTag4 nor dialogTag5 is equal to 4 or 5, display dialog box
            displayReviewDialog()
            print("else")
        }
        
        retrieveData()
        retrieveDataTotal()
        BudgetDataManager.shared.loadBudgets()
        
        // Load the interstitial ad when the view is loaded
        loadInterstitialAdIfNeeded()
        updateUIWithBudgetData()
        
        if filterData.count == 0 {
            tblmain.isHidden = true
            imgempty.isHidden = false
            lblnodata.isHidden = false
            emptyview.isHidden = false
        } else {
            tblmain.isHidden = false
            imgempty.isHidden = true
            lblnodata.isHidden = true
            emptyview.isHidden = true
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.tblmain.removeObserver(self, forKeyPath: "contentSize")
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "contentSize", let newvalue = change?[.newKey] as? CGSize {
            let newSize = newvalue
            
            if object is UITableView {
                switch object as! UITableView {
                case tblmain:
                    self.main_height.constant = newSize.height
                default:
                    break
                }
            }
        }
    }
    
    deinit {
        // Don't forget to remove the observer when the view controller is deinitialized
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func handleTap() {
        // Check if the user has already received the reward
        let hasReceivedReward = UserDefaults.standard.bool(forKey: "HasReceivedReward")
        
        if !hasReceivedReward {
            // Increment the click count when the user taps anywhere on the screen
            Click_CountClass.shared.incrementClickCount()
            Click_CountClass.shared.checkClickCount(presentingViewController: self)
        }
    }
    
    @objc func handleDataUpdateNotification(_ notification: Notification) {
        print("handleDataUpdateNotification called")
        
        // Retrieve the data from the notification
        guard let userInfo = notification.userInfo as? [String: Any],
              let type = userInfo["type"] as? String,
              let amount = userInfo["amount"] as? Int,
              let category = userInfo["category"] as? String,
              let note = userInfo["note"] as? String
                /*let date = userInfo["date"] as? Date*/ else {
                    self.tblmain.reloadData()
                    return
                }
        
        print("Type: \(type)")
        print("Amount: \(amount)")
        print("Category: \(category)")
        print("Note: \(note)")
        //print("Date: \(date)")
        
        let newDataItem = ["type": type, "amount": amount, "category": category, "note": note] as [String : Any]
        dataSource.append(newDataItem)
        
        retrieveData()
        retrieveDataTotal()
    }
    
    @IBAction func click_notification(_ sender: Any) {
        let vc = mainStoryBoard.instantiateViewController(withIdentifier: "NotificationViewController") as! NotificationViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    @IBAction func click_premium(_ sender: Any) {
        let vc = mainStoryBoard.instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click_reward_codevc(_ sender: Any) {
        print("click")
        let mainFamilyVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
        
        // Ensure that the navigation is performed from a visible view controller
        if let navigationController = self.navigationController {
            navigationController.pushViewController(mainFamilyVC, animated: true)
        } else {
            // If the current view controller is not part of a navigation controller, present the new view controller modally
            self.present(mainFamilyVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func click_month_budget(_ sender: Any) {
        ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADSetMonthBudget) {
            self.navigateToMainVC()
        }
    }
    
    func navigateToMainVC() {
        let mainFamilyVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainMonthVC") as! MainMonthVC
        
        // Ensure that the navigation is performed from a visible view controller
        if let navigationController = self.navigationController {
            mainFamilyVC.valueToDisplay = total_expense.text ?? ""
            mainFamilyVC.hidesBottomBarWhenPushed = true
            mainFamilyVC.delegate = self
            mainFamilyVC.loadBudgets()
            navigationController.pushViewController(mainFamilyVC, animated: true)
        } else {
            // If the current view controller is not part of a navigation controller, present the new view controller modally
            self.present(mainFamilyVC, animated: true, completion: nil)
        }
    }
    
    @IBAction func click_suggestion(_ sender: Any) {
        if CommonConst.isPurchasedRemoveAds {
        let suggestion = storyboard?.instantiateViewController(withIdentifier: "SuggestionViewController") as! SuggestionViewController
        suggestion.receivedData = self.filterData
        suggestion.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(suggestion, animated: true)
        } else {
            let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RemoveAds_CodeViewController") as! RemoveAds_CodeViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func clcik_open_message_alert(_ sender: Any) {
        
            let vc = mainStoryBoard.instantiateViewController(withIdentifier: "ChatMessageVC") as! ChatMessageVC
            vc.modalPresentationStyle = .overCurrentContext
            self.present(vc, animated: true, completion: nil)
    }
    
    @IBAction func clcik_history(_ sender: Any) {
        ClassGAD_New.shared.checkGADInterstitialAd(adInfo: InterstitialADSeeAll) {
            let vc = mainStoryBoard.instantiateViewController(withIdentifier: "HistoryViewController") as! HistoryViewController
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func click_analysis(_ sender: Any) {
        // Navigate to the Create QR screen directly if ads have been purchased
    }
    
    func retrieveDataTotal() {
        // Get the current month and year
        let calendar = Calendar.current
        let currentDate = Date()
        let currentMonthComponents = calendar.dateComponents([.year, .month], from: currentDate)
        
        // Filter data for the current month
        let filteredData = filterData.filter { transaction in
            if let date = transaction.value(forKey: "date") as? Date {
                let transactionComponents = calendar.dateComponents([.year, .month], from: date)
                return transactionComponents == currentMonthComponents
            }
            return false
        }
        
        // Calculate totalExpense, totalIncome, totalBorrowing, totalLending, and totalBalance
        var totalExpense = 0
        var totalIncome = 0
        var totalBorrowing = 0
        var totalLending = 0
        
        for transaction in filteredData {
            if let amount = transaction.value(forKey: "amount") as? Int, let type = transaction.value(forKey: "type") as? String {
                switch type.lowercased() {
                case "expense":
                    totalExpense += amount
                case "income":
                    totalIncome += amount
                case "borrowing":
                    totalBorrowing += amount
                case "lending":
                    totalLending += amount
                default:
                    // Handle other transaction types as needed
                    break
                }
            }
        }
        
        let totalBalance = totalIncome - totalExpense + totalLending - totalBorrowing
        
        // Print or use totalExpense, totalIncome, totalBorrowing, totalLending, and totalBalance as needed
        print("Total Expense: \(totalExpense)")
        print("Total Income: \(totalIncome)")
        print("Total Borrowing: \(totalBorrowing)")
        print("Total Lending: \(totalLending)")
        print("Total Balance for the Current Month: \(totalBalance)")
        
        DispatchQueue.main.async { [self] in
            tblmain.reloadData()
            print("Array", filterData )
        }
        // Update the UI element with the calculated balance
        balance.text = String(totalBalance)
        total_income.text = String(totalIncome)
        total_expense.text = String(totalExpense)
        updateUIViewWithBlinkEffect(totalBalance)
    }
    
    func updateUIViewWithBlinkEffect(_ totalBalance: Int) {
        if totalBalance < 0 {
            // Balance is negative
            balance.textColor = UIColor.black
            uiview.backgroundColor = UIColor.red
            
            // Add blinking animation to the UIView
            let blinkAnimation = CABasicAnimation(keyPath: "opacity")
            blinkAnimation.fromValue = 1.0
            blinkAnimation.toValue = 0.0
            blinkAnimation.duration = 0.5
            blinkAnimation.autoreverses = true
            blinkAnimation.repeatCount = Float.greatestFiniteMagnitude
            uiview.layer.add(blinkAnimation, forKey: "blink")
        } else if totalBalance > 0 {
            // Balance is positive
            balance.textColor = UIColor.black
            uiview.backgroundColor = UIColor(hex: "FFC83C")
            
            // Remove any existing blinking animation
            uiview.layer.removeAnimation(forKey: "blink")
        } else {
            // Balance is zero
            // Handle this case as needed
            uiview.layer.removeAnimation(forKey: "blink") // Remove animation if balance is zero
        }
    }
    
    func navigateToAnalyticsVC() {
        let mainFamilyVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AnalysisViewController") as! AnalysisViewController
        
        // Ensure that the navigation is performed from a visible view controller
        if let navigationController = self.navigationController {
            navigationController.pushViewController(mainFamilyVC, animated: true)
        } else {
            // If the current view controller is not part of a navigation controller, present the new view controller modally
            self.present(mainFamilyVC, animated: true, completion: nil)
        }
    }
    
    func retrieveData() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Main")
        
        do {
            let allData = try managedContext.fetch(fetchRequest)
            
            // Store all the data in the filterData array
            filterData = allData
            
            // Sort the data by date in descending order to get the most recent records first
            let sortedData = allData.sorted { (obj1, obj2) -> Bool in
                if let date1 = obj1.value(forKey: "date") as? Date,
                   let date2 = obj2.value(forKey: "date") as? Date {
                    return date1 > date2
                }
                return false
            }
            
            // Reload the main table view
            DispatchQueue.main.async {
                self.tblmain.reloadData()
            }
            
            // After fetching the data, calculate and display the total
            retrieveDataTotal()
        } catch let error as NSError {
            print("Error fetching data: \(error.localizedDescription)")
        }
    }
    
    func deleteData(lblnote: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Main")
        fetchRequest.predicate = NSPredicate(format: "note == %@", lblnote)
        
        do {
            guard let result = try managedContext.fetch(fetchRequest) as? [NSManagedObject], let objectToDelete = result.first else {
                return
            }
            managedContext.delete(objectToDelete)
            
            do {
                try managedContext.save()
                print("Data deleted")
            } catch let error as NSError {
                print("Failed to save context after deleting data: \(error), \(error.userInfo)")
            }
        } catch let error as NSError {
            print("Failed to fetch data for deletion: \(error), \(error.userInfo)")
        }
    }
    
    func didAddDataToHistory() {
        // Reload your history table view here
        tblmain.reloadData()
    }
    
    func openCustomBudget_Inc_Exp_ViewController(index: Int, lblamount: Int?, lblcategory: String?, lblnote: String?, lbltype: String?, lblprompt: String?, lblprimary: Int?, notification_id: Int?) {
        let addSuspenseVC = storyboard?.instantiateViewController(withIdentifier: "AddSuspenseVC") as! AddSuspenseVC
        //addSuspenseVC.passedValue = lblname
        addSuspenseVC.passedamount = lblamount
        addSuspenseVC.passednote = lblnote
        addSuspenseVC.passedcategory = lblcategory
        addSuspenseVC.passedrealnote = lblnote
        addSuspenseVC.passedtype = lbltype
        addSuspenseVC.passedprimary = lblprimary
        addSuspenseVC.passedprompt = lblprompt
        addSuspenseVC.notification_id = notification_id
        addSuspenseVC.isBlueButtonHidden = false
        
        // Present the AddSuspenseVC
        addSuspenseVC.modalPresentationStyle = .overCurrentContext
        navigationController?.present(addSuspenseVC, animated: true, completion: nil)
    }
    
    func loadTransactions() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Main")
        
        do {
            //history = try managedContext.fetch(fetchRequest)
            filterData = try managedContext.fetch(fetchRequest)
            
            
            // Categorize transactions into expense, income, and another arrays
            for transaction in filterData {
                if let type = transaction.value(forKey: "type") as? String,
                   let category = transaction.value(forKey: "category") as? String,
                   let note = transaction.value(forKey: "note") as? String,
                   let amount = transaction.value(forKey: "amount") as? Int {
                    
                    let transactionData: [String: Any] = [
                        "type": type,
                        "category": category,
                        "note": note,
                        "amount": amount
                        //"date": date
                    ]
                }
            }
            
            // Reload table views
            tblmain.reloadData()
            
            
        } catch {
            print("Error fetching transactions: \(error)")
        }
    }
    
    func deleteRecordWithPrimaryKey(_ primaryKey: Int, entityName: String) {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        fetchRequest.predicate = NSPredicate(format: "primarykey == %d", primaryKey)
        
        do {
            let records = try managedContext.fetch(fetchRequest) as! [NSManagedObject]
            
            for recordToDelete in records {
                managedContext.delete(recordToDelete)
            }
            
            try managedContext.save()
            
            // Post a notification here
            NotificationCenter.default.post(name: NSNotification.Name("RecordDeleted"), object: nil)
            
        } catch {
            print("Error fetching records to delete for entity \(entityName) with primary key \(primaryKey): \(error)")
        }
    }
    
//    func deleteRecordWithPrimaryKey(_ primaryKey: Int, entityName: String, completion: @escaping (Bool) -> Void) {
//        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
//            completion(false)
//            return
//        }
//
//        let managedContext = appDelegate.persistentContainer.viewContext
//
//        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
//        fetchRequest.predicate = NSPredicate(format: "primarykey == %d", primaryKey)
//
//        do {
//            let records = try managedContext.fetch(fetchRequest) as! [NSManagedObject]
//
//            for recordToDelete in records {
//                managedContext.delete(recordToDelete)
//            }
//
//            try managedContext.save()
//
//            // Post a notification here
//            NotificationCenter.default.post(name: NSNotification.Name("RecordDeleted"), object: nil)
//            
//            completion(true)
//
//        } catch {
//            print("Error fetching records to delete for entity \(entityName) with primary key \(primaryKey): \(error)")
//            completion(false)
//        }
//    }
}

extension MainViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return filterData.count
        let numberOfRecordsToDisplay = min(filterData.count, 3)
        return numberOfRecordsToDisplay
        //        let currentDate = Date() // Assuming you want transactions for the current date
        //            let todayTransactions = filterData.filter { (income) -> Bool in
        //                if let date = income.value(forKey: "date") as? Date {
        //                    return Calendar.current.isDate(date, inSameDayAs: currentDate)
        //                }
        //                return true
        //            }
        //            return todayTransactions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let incomeCell = tblmain.dequeueReusableCell(withIdentifier: "MainTableViewCell", for: indexPath) as! MainTableViewCell
        
        //let income = filterData[indexPath.row]
        let income = filterData[filterData.count - 1 - indexPath.row]
        
        if let date = income.value(forKey: "date") as? Date {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd/MM/yyyy"
            let formattedDate = dateFormatter.string(from: date)
            incomeCell.lbldate.text = formattedDate
        }
        
        if let amount = income.value(forKey: "amount") as? Int {
            incomeCell.lblamount.text = String(amount)
        } else {
            incomeCell.lblamount.text = "N/A" // Set a default value or handle it as needed
        }
        
        if let category = income.value(forKey: "category") as? String {
            incomeCell.lblcategory.text = category.capitalizingFirstLetter() // Capitalize the first letter
        } else {
            incomeCell.lblcategory.text = "N/A" // Set a default value or handle it as needed
        }
        
        if let category = income.value(forKey: "time") as? String {
            incomeCell.lbltime.text = category.capitalizingFirstLetter() // Capitalize the first letter
        } else {
            incomeCell.lbltime.text = "N/A" // Set a default value or handle it as needed
        }
        
        //        let dateFormatter = DateFormatter()
        //        dateFormatter.dateFormat = "HH:mm"
        //
        //        let currentTime = Date()
        //        let formattedTime = dateFormatter.string(from: currentTime)
        
        if let type = income.value(forKey: "type") as? String {
            incomeCell.lbltype.text = type.capitalized
            
            // Set the image based on the type
            if type.lowercased() == "income" {
                incomeCell.img.image = UIImage(named: "Home_Income")
                incomeCell.btnedit.isHidden = true
                incomeCell.btndelete.isHidden = true
                //                incomeCell.lbltime.text = formattedTime
                //                incomeCell.lbltime.isHidden = false
            } else if type.lowercased() == "expense" {
                incomeCell.img.image = UIImage(named: "Home_Expense")
                incomeCell.btnedit.isHidden = true
                incomeCell.btndelete.isHidden = true
                //                incomeCell.lbltime.text = formattedTime
                //                incomeCell.lbltime.isHidden = false
            } else if type.lowercased() == "lending" {
                incomeCell.img.image = UIImage(named: "lending")
                incomeCell.btnedit.isHidden = true
                incomeCell.btndelete.isHidden = true
                //                incomeCell.lbltime.text = formattedTime
                //                incomeCell.lbltime.isHidden = false
            } else if type.lowercased() == "borrowing" {
                incomeCell.img.image = UIImage(named: "Home_Borrowing")
                incomeCell.btnedit.isHidden = true
                incomeCell.btndelete.isHidden = true
                //                incomeCell.lbltime.text = formattedTime
                //                incomeCell.lbltime.isHidden = false
            } else {
                // Default image when type is neither "income" nor "expense"
                incomeCell.img.image = UIImage(named: "Home_Suspense")
                incomeCell.btnedit.isHidden = false
                incomeCell.btndelete.isHidden = false
                incomeCell.lbltime.isHidden = true
                
            }
        } else {
            incomeCell.lbltype.text = "N/A" // Set a default value or handle it as needed
            incomeCell.img.image = UIImage(named: "Home_Suspense") // Default image
            incomeCell.btnedit.isHidden = false
            incomeCell.btndelete.isHidden = false
            //            incomeCell.lbltime.text = formattedTime
            //            incomeCell.lbltime.isHidden = true
        }
        
        if let note = income.value(forKey: "note") as? String {
            incomeCell.lblnote.text = note
        } else {
            incomeCell.lblnote.text = "N/A" // Set a default value or handle it as needed
        }
        
        if let prompt = income.value(forKey: "prompt") as? String {
            incomeCell.lblprompt.text = prompt
        } else {
            incomeCell.lblprompt.text = "N/A" // Set a default value or handle it as needed
        }
        
        if let primarykey = income.value(forKey: "primarykey") as? Int {
            incomeCell.lblprimarykey.text = String(primarykey)
        } else {
            incomeCell.lblprimarykey.text = "N/A" // Set a default value or handle it as needed
        }
           
        let notification_id = income.value(forKey: "notification_id") as? Int
        
        incomeCell.addButtonAction = { [weak self] index in
            print(index)
            if let lblamountText = incomeCell.lblamount.text, let lblcategoryText = incomeCell.lblcategory.text, let lblnoteText = incomeCell.lblnote.text, let lbltypeText = incomeCell.lbltype.text, let lblpromptText = incomeCell.lblprompt.text, let lblprimarykeyText = incomeCell.lblprimarykey.text, let lblprimarykey = Int(lblprimarykeyText) {
                self?.openCustomBudget_Inc_Exp_ViewController(index: index, lblamount: Int(lblamountText) ?? 0, lblcategory: lblcategoryText, lblnote: lblnoteText, lbltype: lbltypeText, lblprompt: lblpromptText, lblprimary: lblprimarykey, notification_id: notification_id)
                
            } else {
                // Handle the case where one of the labels' text is not convertible to an integer
                print("Invalid data format")
            }
        }
        
        incomeCell.btnedit.tag = indexPath.row
        
        incomeCell.deleteButtonAction = { [weak self, weak incomeCell] index in
            guard let self = self, let incomeCell = incomeCell else { return }

            let alert = UIAlertController(title: "Confirm Deletion", message: "Are you sure you want to delete this record?", preferredStyle: .alert)

            let confirmAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
                if let primarykeyText = incomeCell.lblprimarykey.text, let primarykey = Int(primarykeyText) {
                    print("Primary key: \(primarykey)")
                    self.deleteRecordWithPrimaryKey(primarykey, entityName: "Main")
                       // if success {
                            // Remove the item from the data source array
                            if let indexPathToDelete = self.tblmain.indexPath(for: incomeCell) {
                                DispatchQueue.main.async {
                                    // Delete row from table view
                                    self.tblmain.beginUpdates()
                                    self.filterData.remove(at: indexPathToDelete.row)
                                    self.tblmain.deleteRows(at: [indexPathToDelete], with: .automatic)
                                    self.tblmain.endUpdates()
                                }
                            }
//                        } else {
//                            print("Failed to delete record with primary key \(primarykey)")
//                        }
                   // }
                } else {
                    // Handle the case where lblprimary.text is not a valid integer
                    print("Invalid primary key format")
                }
            }

            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)

            alert.addAction(confirmAction)
            alert.addAction(cancelAction)

            self.present(alert, animated: true, completion: nil)
        }
        
        return incomeCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}

extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).capitalized + dropFirst()
    }
}

