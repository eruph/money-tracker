//
//  MainMonthVC.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import Toast_Swift
import MBProgressHUD

protocol MainMonthVCDelegate: AnyObject {
    func didUpdateBudgets(_ budgets: [Budget])
}

class MainMonthVC: UIViewController {
    
    @IBOutlet weak var lblnodata: UILabel!
    @IBOutlet weak var imgempty: UIImageView!
    @IBOutlet weak var emptyview: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var lbl_remaing_expense: UILabel!
    //@IBOutlet weak var tbl_height: NSLayoutConstraint!
    
    var budgets: [Budget] = []
    var valueToDisplay: String = ""
    
    weak var delegate: MainMonthVCDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
               view.addGestureRecognizer(tapGestureRecognizer)
        tableView.separatorStyle = .none
        lbl_remaing_expense.isHidden = true
        lbl_remaing_expense.text = valueToDisplay
        // Set up the table view
        tableView.delegate = self
        tableView.dataSource = self
        
        self.title = "Monthly Budget"
        
        // Load saved budget data from UserDefaults
        loadBudgets()
        
        print("Budgets array:", budgets)
        // Reload the table view to display the saved budgets
        tableView.reloadData()
        
//        if CommonConst.isPurchasedRemoveAds {
//            return
//        }
//
//        // Create a blurred background view
//        let blurEffect = UIBlurEffect(style: .light) // Adjust the style as needed
//        let blurView = UIVisualEffectView(effect: blurEffect)
//        blurView.frame = view.bounds
//        view.addSubview(blurView)
//
//        // Show a progress indicator (MBProgressHUD)
//        let hud = MBProgressHUD.showAdded(to: self.view, animated: true)
//        hud.mode = .indeterminate
//        hud.label.text = "Loading"
//
//        // Set up the ad dismissal callback
//        ClassGAD.shared.adDismissedCallback = { [weak self] in
//            DispatchQueue.main.async {
//                hud.hide(animated: true)
//                blurView.removeFromSuperview() // Remove the blur view when ad is dismissed
//                //self?.navigateToMainVC()
//            }
//        }
//
//        // Load and present the interstitial ad with a timeout of 5 seconds
//        ClassGAD.shared.loadAndPresentInterstitialAd_MonthlyBudget {
//            DispatchQueue.main.async {
//                hud.hide(animated: true)
//                blurView.removeFromSuperview() // Remove the blur view when ad is loaded
//                //self.navigateToMainVC()
//            }
//        }
//
//        // Set a timeout for ad loading (5 seconds)
//        let timeoutSeconds: TimeInterval = 8
//        DispatchQueue.global(qos: .background).asyncAfter(deadline: .now() + timeoutSeconds) { [weak self] in
//            // Check if the ad has not been loaded within the timeout
//            if ClassGAD.shared.interstitialAdMonthlyBudget == nil {
//                DispatchQueue.main.async {
//                    hud.hide(animated: true)
//                    blurView.removeFromSuperview() // Remove the blur view on timeout
//                    // Handle the case when the ad loading times out
//                }
//            }
//        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if budgets.count == 0 {
            emptyview.isHidden = false
            lblnodata.isHidden = false
            imgempty.isHidden = false
            tableView.isHidden = true
        } else {
            emptyview.isHidden = true
            lblnodata.isHidden = true
            imgempty.isHidden = true
            tableView.isHidden = false
        }
    }
    
    @objc func handleTap() {
        // Check if the user has already received the reward
        let hasReceivedReward = UserDefaults.standard.bool(forKey: "HasReceivedReward")
        
        if !hasReceivedReward {
            // Increment the click count when the user taps anywhere on the screen
            Click_CountClass.shared.incrementClickCount()
            Click_CountClass.shared.checkClickCount(presentingViewController: self)
        }
    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        self.tableView.addObserver(self, forKeyPath: "contentSize", options: .new, context: nil)
//    }
//    
//    override func viewWillDisappear(_ animated: Bool) {
//        self.tableView.removeObserver(self, forKeyPath: "contentSize")
//    }
    
//    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
//        if keyPath == "contentSize", let newvalue = change?[.newKey] as? CGSize {
//            let newSize = newvalue
//            
//            if object is UITableView {
//                switch object as! UITableView {
//                case tableView:
//                    self.tbl_height.constant = newSize.height
//                default:
//                    break
//                }
//            }
//        }
//    }
    
    func loadBudgets() {
        if let savedBudgetData = UserDefaults.standard.data(forKey: "savedBudgets") {
            do {
                budgets = try JSONDecoder().decode([Budget].self, from: savedBudgetData)
            } catch {
                print("Error decoding budgets: \(error)")
            }
        }
        delegate?.didUpdateBudgets(budgets)
    }
    
    @IBAction func click_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    // IBAction for adding a new budget
    @IBAction func addBudgetButtonTapped(_ sender: UIButton) {
        // Create and present Add_Month_VC modally
        let addMonthVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddMonthVC") as! AddMonthVC
        addMonthVC.delegate = self
        navigationController?.pushViewController(addMonthVC, animated: true)
    }
    
    func didUpdateBudget(atIndex index: Int, withNewBudget budget: Budget) {
            BudgetDataManager.shared.budgets[index] = budget
            BudgetDataManager.shared.saveBudgets()
        }
}

extension MainMonthVC: AddMonthDelegate {
    func indexOfExistingBudget(withMonth month: String) -> Int? {
        // Iterate through your budgets array to find the index of the existing budget
        for (index, budget) in budgets.enumerated() {
            if budget.month == month {
                return index
            }
        }
        // If no budget with the same month is found, return nil
        return nil
    }
    
    func didAddBudget(_ budget: Budget) {
        // Check if a budget with the same month and year already exists
        if let existingIndex = budgets.firstIndex(where: { $0.month == budget.month }) {
            // Update the existing budget with the new amount
            budgets[existingIndex].amount = budget.amount
        } else {
            // If not, add the new budget
            budgets.append(budget)
        }
        tableView.reloadData()
        
        // Save the updated budgets to UserDefaults
        saveBudgets()
    }
    
    func didSelectMonth(_ month: String, amount: Double) {
        // Handle the selected month and amount here
        // Create a new budget object
        let newBudget = Budget(month: month, amount: amount)
        
        // Append to budgets and reload the table view
        budgets.append(newBudget)
        tableView.reloadData()
    }
}

extension MainMonthVC: UITableViewDelegate, UITableViewDataSource {
    
    // Add a function to save the budgets to UserDefaults
    func saveBudgets() {
        if let encodedData = try? JSONEncoder().encode(budgets) {
            UserDefaults.standard.set(encodedData, forKey: "savedBudgets")
        }
    }
    
    func handleEditButtonTapped(month: String, amount: Double) {
        let addMonthVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddMonthVC") as! AddMonthVC
        
        // Pass the selected month and amount to AddMonthVC
        addMonthVC.selectedMonth = month
        addMonthVC.selectedAmount = String(amount)
        
        // Set the delegate if needed
        addMonthVC.delegate = self
        
        navigationController?.pushViewController(addMonthVC, animated: true)
    }
    
    @objc func deleteButtonTapped(_ sender: UIButton) {
        let rowIndex = sender.tag
        
        // Ensure that the index is within the bounds of the budgets array
        guard rowIndex >= 0 && rowIndex < budgets.count else {
            return
        }
        
        // Create a confirmation alert
        let alertController = UIAlertController(title: "Confirm Deletion",
                                                message: "Are you sure you want to delete this budget?",
                                                preferredStyle: .alert)
        
        // Add actions for confirm and cancel
        let confirmAction = UIAlertAction(title: "Confirm", style: .destructive) { [weak self] (_) in
            // User confirmed, delete the budget
            self?.deleteBudget(atIndex: rowIndex)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(confirmAction)
        alertController.addAction(cancelAction)
        
        // Present the alert
        present(alertController, animated: true, completion: nil)
    }
    
    func deleteBudget(atIndex index: Int) {
        // Remove the budget at the selected index
        budgets.remove(at: index)
        
        // Reload the table view to reflect the updated data
        tableView.reloadData()
        
        // Save the updated budgets to UserDefaults
        saveBudgets()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return budgets.count
        
    }
    
    //    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    //        let cell = tableView.dequeueReusableCell(withIdentifier: "BudgetCell", for: indexPath) as! MonthlyBudgetCell
    //
    //        let budget = budgets[indexPath.row]
    //
    //        cell.monthname.text = "\(budget.month)"
    //        cell.lbl_total_amount.text = "\(budget.amount)"
    //
    // Calculate the left amount and update lbl_left_amount
    //        if let remaining = Double(lbl_remaing_expense.text ?? "0") {
    //            let leftAmount = budget.amount - remaining
    //            cell.lbl_left_amount.text = "\(leftAmount)"
    //
    //            // Update the progress view based on remaining
    //            let progress = remaining / budget.amount
    //            cell.progressView.progress = Float(progress)
    //
    //            // Update progress bar color based on leftAmount
    //            if leftAmount < 0 {
    //                cell.progressView.progressTintColor = UIColor.red
    //            } else {
    //                cell.progressView.progressTintColor = UIColor.green
    //            }
    //
    //            // Set the closure for the edit button
    //            cell.editButtonAction = { [weak self] in
    //                self?.handleEditButtonTapped(month: budget.month, amount: budget.amount)
    //            }
    //
    //            // Set the title and action for the delete button
    //            cell.btn_delete.addTarget(self, action: #selector(deleteButtonTapped(_:)), for: .touchUpInside)
    //
    //            // Store the index of the cell in the button's tag property
    //            cell.btn_delete.tag = indexPath.row
    //        }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MonthlyBudgetTableViewCell", for: indexPath) as! MonthlyBudgetTableViewCell
        
        let budget = budgets[indexPath.row]
        
        cell.monthname.text = "\(budget.month)"
        cell.lbl_total_amount.text = "\(budget.amount)"
        
        // Get the current month and year
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM yyyy"
        let currentMonthNameAndYear = dateFormatter.string(from: currentDate)
        
        // Check if the cell's month matches the current month
        if cell.monthname.text == currentMonthNameAndYear {
            if let remaining = Double(lbl_remaing_expense.text ?? "0") {
                let leftAmount = budget.amount - remaining
                cell.lbl_left_amount.text = "\(leftAmount)"
                
                // Update the progress view based on remaining
                let progress = remaining / budget.amount
                cell.progressView.progress = Float(progress)
                
                // Update progress bar color based on leftAmount
                if leftAmount < 0 {
                    cell.progressView.progressTintColor = UIColor.red
                } else {
                    cell.progressView.progressTintColor = UIColor.green
                }
                
                // Set the closure for the edit button
                cell.editButtonAction = { [weak self] in
                    self?.handleEditButtonTapped(month: budget.month, amount: budget.amount)
                }
                
                // Set the title and action for the delete button
                cell.btn_delete.addTarget(self, action: #selector(deleteButtonTapped(_:)), for: .touchUpInside)
                
                // Store the index of the cell in the button's tag property
                cell.btn_delete.tag = indexPath.row
                cell.lblremaning.text = String(describing: budget.amount - leftAmount)
            }
        } else {
            // If the cell's month doesn't match the current month, clear any previous data
            cell.lbl_left_amount.text = String(0)
            cell.progressView.progress = 0
            cell.progressView.progressTintColor = .clear
            cell.editButtonAction = nil
            cell.btn_delete.removeTarget(nil, action: nil, for: .allEvents)
            cell.lblremaning.text = String(0)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 190
    }
}

struct Budget: Codable {
    let month: String
    var amount: Double // Make amount mutable to update it
}

