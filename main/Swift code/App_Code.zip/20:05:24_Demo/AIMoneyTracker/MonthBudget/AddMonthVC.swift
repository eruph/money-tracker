//
//  AddMonthVC.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

protocol AddMonthDelegate: AnyObject {
    func didAddBudget(_ budget: Budget)
    func indexOfExistingBudget(withMonth month: String) -> Int?
    func didUpdateBudget(atIndex index: Int, withNewBudget budget: Budget)
}

class AddMonthVC: UIViewController {
    
    @IBOutlet weak var lbl_month: UILabel!
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var btn_select: UIButton!
    @IBOutlet weak var lbltitle: UILabel!
    @IBOutlet weak var vwCardBannerAd: UIView!
    @IBOutlet weak var vwBannerAd: UIView!
    @IBOutlet weak var nslcHeightVwBannerCard: NSLayoutConstraint!
    
    let adsRunValue = ClassGAD_New.shared.adsRunValue
    var selectedDate: String = ""
    weak var delegate: AddMonthDelegate?
    var selectedMonth: String = ""
    var selectedAmount: String = ""
    var bannerAdSize:CGSize? = nil
    var addMonthVCInstance: AddMonthVC?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
               view.addGestureRecognizer(tapGestureRecognizer)
        
        if selectedMonth.isEmpty {
            let calendar = Calendar.current
            let currentDate = Date()

            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMMM yyyy"

            selectedMonth = dateFormatter.string(from: currentDate)
        }
        
        lbl_month.text = selectedMonth
        amountTextField.text = selectedAmount

        let tap = UITapGestureRecognizer(target: self, action: #selector(self.tapFunction))

        btn_select.isUserInteractionEnabled = true
        btn_select.addGestureRecognizer(tap)
    }
    
    @objc func handleTap() {
        // Check if the user has already received the reward
        let hasReceivedReward = UserDefaults.standard.bool(forKey: "HasReceivedReward")
        
        if !hasReceivedReward {
            // Increment the click count when the user taps anywhere on the screen
            Click_CountClass.shared.incrementClickCount()
            Click_CountClass.shared.checkClickCount(presentingViewController: self)
        }
    }

    @objc private func loadBannerAd() {
        DispatchQueueMain { [self] in
            if bannerAdSize != nil{
                
                vwCardBannerAd.isHidden = true
                nslcHeightVwBannerCard.constant = 0
                
                if adsRunValue == "1" {
                    ClassGAD_New.shared.getGADBannerAd(size: bannerAdSize!, adInfo: BannerADHome) { [self] adView in
                        if let adView = adView{
                            nslcHeightVwBannerCard.constant = 60
                            vwBannerAd.showGADBannerAd(ad: adView)
                            vwCardBannerAd.isHidden = false
                            ClassGAD_New.shared.resetBannerAd(size: bannerAdSize!, adInfo: BannerADHome)
                        }
                    }
                }
            }
        }
    }
    
    @IBAction func click_back(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        guard let month = lbl_month.text,
              let amountText = amountTextField.text,
              let amount = Double(amountText) else {
                  // Handle invalid input
                  return
              }
        
        // Create a new budget object
        let newBudget = Budget(month: month, amount: amount)
        
        // Check if a budget with the same month already exists
        if let existingIndex = delegate?.indexOfExistingBudget(withMonth: month) {
            // An existing budget was found, show an alert to confirm the action
            let alertController = UIAlertController(title: "Confirm Update",
                                                    message: "A budget for this month already exists. Do you want to update it?",
                                                    preferredStyle: .alert)
            
            // Add a confirm action with a blue background and light green text color
            let confirmAction = UIAlertAction(title: "Confirm", style: .default) { [weak self] (_) in
                // User confirmed, update the existing budget
                self?.delegate?.didAddBudget(newBudget)
                
                // Dismiss the Add_MonthVC
                self?.navigationController?.popViewController(animated: true)
            }
            confirmAction.setValue(UIColor.black, forKey: "titleTextColor") // Text color
            
            // Add a cancel action with a red background and light green text color
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            cancelAction.setValue(UIColor.red, forKey: "titleTextColor") // Text color
            
            alertController.addAction(confirmAction)
            alertController.addAction(cancelAction)
            
            // Present the alert
            self.present(alertController, animated: true, completion: nil)
        } else {
            // No existing budget found, add the new budget
            delegate?.didAddBudget(newBudget)
            
            // Dismiss the Add_MonthVC
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @objc func tapFunction(sender:UITapGestureRecognizer) {
        self.createDatePicker()
    }
    
    func createDatePicker() {
        let datePickerController = storyboard?.instantiateViewController(withIdentifier: "CustomDatePickerVC") as! CustomDatePickerVC
        datePickerController.modalPresentationStyle = .overCurrentContext
        datePickerController.voidSelectedDate = { (selectedDate) in
            self.showSelectedDate(date: selectedDate)
        }
        navigationController?.present(datePickerController, animated: false, completion: nil)
    }
    
    func showSelectedDate(date: Date) {
        let formatter = DateFormatter()
        formatter.locale = .current
        formatter.dateFormat = "MMMM yyyy"
        
        selectedDate = formatter.string(from: date)
        
        let dateString = formatter.string(from: date)
        lbl_month.text = dateString
        
        //filterAndReloadTable()
    }
}

