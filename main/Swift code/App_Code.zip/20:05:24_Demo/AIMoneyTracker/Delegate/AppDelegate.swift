//
//  AppDelegate.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 12/10/23.
//

import UIKit
import CoreData
import SwiftyStoreKit
import Firebase
import AdSupport
import GoogleMobileAds
import OneSignalFramework
import AppTrackingTransparency

@main
class AppDelegate: UIResponder, UIApplicationDelegate, GADFullScreenContentDelegate {
    
    var window: UIWindow?
    var GAD_AppOpen: String = ""
    private var gadAppOpenAd: GADAppOpenAd?
    private var gadAppOpenAdRequested = false
    var isAppLoaded = false // Declare isAppLoaded as a property
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        FirebaseApp.configure()
        ClassGAD_New.shared.initGAD() //google mobile ad's
        
        if #available(iOS 13.0, *) {
            window?.overrideUserInterfaceStyle = .light
        }
        
        CommonConst.isPurchasedRemoveAds = UserDefaults.standard.value(forKey: "isPurchasedRemoveAds") as? Bool ?? false
        loadAndPresentAppOpenAd()
        requestIDFA()
        // swifty store kit setup
        SwiftyStoreKit.completeTransactions(atomically: true) { purchases in
            
            for purchase in purchases
            {
                switch purchase.transaction.transactionState
                {
                case .purchased, .restored:
                    if purchase.needsFinishTransaction {
                        SwiftyStoreKit.finishTransaction(purchase.transaction)
                    }
                    // Unlock content
                case .failed, .purchasing, .deferred:
                    break // do nothing
                @unknown default:
                    print("error")
                }
            }
        }
            
        // Remove this method to stop OneSignal Debugging
          OneSignal.Debug.setLogLevel(.LL_VERBOSE)
          
          // OneSignal initialization
          OneSignal.initialize("YOUR_ONESIGNAL_APP_ID", withLaunchOptions: launchOptions)
          
          // requestPermission will show the native iOS notification permission prompt.
          // We recommend removing the following code and instead using an In-App Message to prompt for notification permission
          OneSignal.Notifications.requestPermission({ accepted in
            print("User accepted notifications: \(accepted)")
          }, fallbackToSettings: true)
        return true
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        //loadAndPresentAppOpenAd()
    }
    
    func loadAndPresentAppOpenAd() {
        print(CommonConst.isPurchasedRemoveAds, "....AppOpen")
        let adsRunValue = ClassGAD_New.shared.adsRunValue
        if CommonConst.isPurchasedRemoveAds{
            gadAppOpenAd = nil
            //checkCondition()
            return
        }
        
        if CommonConst.isSubscriptionAds{
            gadAppOpenAd = nil
            //checkCondition()
            return
        }
        
        if adsRunValue == "0" {
            gadAppOpenAd = nil
            return
        }
        
        if !CommonConst.isOneDayRemoveAds {
            let remoteConfig = RemoteConfig.remoteConfig()
            
            // Set default values in case the remote config fetch fails or takes too long
            let defaultConfigValues: [String: NSObject] = [
                "app_open1": NSNumber(value: false) // Default value for GAD_AppOpen key
            ]
            remoteConfig.setDefaults(defaultConfigValues)
            
            // Define the expiration duration for the cache, you can adjust the duration based on your needs
            let expirationDuration: TimeInterval = 3600 // Cache duration in seconds (1 hour)
            
            remoteConfig.fetch(withExpirationDuration: expirationDuration) { [weak self] (status, error) in
                if status == .success {
                    remoteConfig.activate { [weak self] _, _ in
                        let defaultValue = ""
                        // Fetch the value of GAD_AppOpen from remote config
                        self?.GAD_AppOpen = remoteConfig["app_open1"].stringValue ?? defaultValue
                        print("GAD_AppOpen value fetched: \(self?.GAD_AppOpen ?? "Default Value")")
                        
                        // Check if the App Open ad is already displayed or if the ad has already been requested
                        // if self?.GAD_AppOpen.lowercased() == "true" && self?.gadAppOpenAd == nil && !self!.gadAppOpenAdRequested {
                        //     self?.gadAppOpenAdRequested = true
                        
                        GADAppOpenAd.load(withAdUnitID: self!.GAD_AppOpen, request: GADRequest(), orientation: .portraitUpsideDown) { [weak self] (openAd, error) in
                            // Reset the flag after the ad load attempt is completed
                            self?.gadAppOpenAdRequested = false
                            
                            if let error = error {
                                print("ERROR: GADAppOpenAd load error: \(error.localizedDescription)")
                                // Call checkCondition if ad load fails
                                //self?.checkCondition()
                                return
                            }
                            
                            print("SUCCESS: GADAppOpenAd load")
                            self?.gadAppOpenAd = openAd
                            self?.gadAppOpenAd?.fullScreenContentDelegate = self as! GADFullScreenContentDelegate
                            
                            // Set the flag to indicate that the app is loaded
                            self?.isAppLoaded = true
                            
                            // Schedule a Timer to check if the ad is presented after 5 seconds
                            Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { timer in
                                if self?.gadAppOpenAd == nil {
                                    // The ad was not presented within 5 seconds, call checkCondition
                                    //self?.checkCondition()
                                } else {
                                    // The ad is loaded, present it
                                    self?.presentGADAppOpenAd()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    func presentGADAppOpenAd() {
        if let topVC = UIApplication.getTopViewController(), gadAppOpenAd != nil {
            DispatchQueue.main.async {
                self.gadAppOpenAd!.present(fromRootViewController: topVC)
            }
        }
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                        willPresent notification: UNNotification,
                                        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
         print("Push notification received in foreground.")
         completionHandler([.alert, .sound, .badge])
      }
    
    func requestIDFA() {
        print("Requesting IDFA")
        
        if #available(iOS 14, *) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                ATTrackingManager.requestTrackingAuthorization { status in
                    
                    switch status {
                    case .authorized:
                        print("Authorization Status: Authorized")
                        // Tracking authorization completed. Start loading ads here.
                        // loadAd()
                    case .denied:
                        print("Authorization Status: Denied")
                    case .restricted:
                        print("Authorization Status: Restricted")
                    case .notDetermined:
                        print("Authorization Status: Not Determined")
                    @unknown default:
                        fatalError("Unhandled authorization status")
                    }
                }
            }
        } else {
            // Fallback on earlier versions
            print("IDFA request not supported on this iOS version.")
        }
    }
    
    // MARK: UISceneSession Lifecycle
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Remove user defaults here
        UserDefaults.standard.removeObject(forKey: "isNotNowSelected")
        // Make sure to synchronize changes
        UserDefaults.standard.synchronize()
    }

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    
    // MARK: - Core Data stack
    
    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: "MoneyManagerBudgetCopilot")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    // MARK: - Core Data Saving support
    
    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}

