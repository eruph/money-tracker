//
//  GetStartedVC.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit

class GetStartedVC: UIViewController {
    @IBOutlet var collStarted:UICollectionView!
    @IBOutlet var pageControl:UIPageControl!
    @IBOutlet var btnStarted:UIButton!
    @IBOutlet var ViewBtnStarted:UIView!
    @IBOutlet var constBtnHieght:NSLayoutConstraint!
    @IBOutlet weak var lblprivacy: UILabel!
    @IBOutlet weak var lblterms: UILabel!
    @IBOutlet weak var checkedcheckbox: UIButton!
    
    var reachedLastPage = false
    
    var currentPage = 0 {
        didSet {
            pageControl.currentPage = currentPage
            if currentPage == arrValu.count - 1 {
                btnStarted.setTitle("Start", for: .normal)
            }else {
                btnStarted.setTitle("Next", for: .normal)
            }
        }
    }
    
    //var isFromSplash:Bool = false
    
    var arrValu:[[String:Any]] = [["header1":"Transaction as a Prompting",
                                   "subStr1": "Just Write Note as a Prompt : 'I eat $5’s Burger'\nAI app will save your transaction like :\nTransaction type : 'Expense',\nNote : 'Eat Burger',\nAmount : '$5'",
                                   "imgKey":UIImage(named: "Walkthrow_1")!],
                                  
                                  ["header1":"Reminder",
                                   "subStr1":"AI-based Transaction Reminder Increase Saving using AI Suggestion ",
                                   "imgKey":UIImage(named: "Walkthrow_2")!],
                                  
                                  ["header1":"One-click Tracking",
                                   "subStr1":"Track your financial activity in just a few seconds",
                                   "imgKey":UIImage(named: "Walkthrow_3")!]]
    
    /*["header":"Worldwide Ranking of Air Pollution","subStr":"Air pollution of worldwide ranking is update you.","imgKey":UIImage(named: "onboarding_3")!]] as [[String:Any]]*/
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(openTermsAndConditions))
        lblterms.isUserInteractionEnabled = true
        lblterms.addGestureRecognizer(tapGesture)
        
        let tapGesture1 = UITapGestureRecognizer(target: self, action: #selector(openPrivacyPolicy))
        lblprivacy.isUserInteractionEnabled = true
        lblprivacy.addGestureRecognizer(tapGesture1)
        
        self.navigationItem.setHidesBackButton(true, animated: true)
        pageControl.numberOfPages = arrValu.count
        //self.navigationItem.setHidesBackButton(true, animated: true)
    }
    
    @objc func openTermsAndConditions() {
        if let url = URL(string: "https://sites.google.com/view/money-manager-copilot-budget") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    @objc func openPrivacyPolicy() {
        if let url = URL(string: "https://sites.google.com/view/money-manager-copilot-budget") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func btnCheckPolicy(_ sender:UIButton)
    {
        if (sender as AnyObject).isSelected == false
        {
            sender.isSelected = true
            Defaults.set(true, forKey: "CheckPolicy")
        }
        else
        {
            sender.isSelected = false
            Defaults.set(false, forKey: "CheckPolicy")
        }
    }
    
    @IBAction func btnGetStarted(_ sender: UIButton) {
        if !checkedcheckbox.isSelected {
            // Checkbox is checked
            let vc = mainStoryBoard.instantiateViewController(withIdentifier: "RemoveAdsViewController") as! RemoveAdsViewController
            self.navigationController?.pushViewController(vc, animated: true)
        } else {
            // Checkbox is not checked
            // Display an alert to inform the user
            guard let audioSettingVC = storyboard?.instantiateViewController(withIdentifier: "TermsConditionAlertVC") as? TermsConditionAlertVC else {
                print("AudioSettingVC not found.")
                return
            }
            audioSettingVC.modalPresentationStyle = .overCurrentContext
            navigationController?.present(audioSettingVC, animated: true, completion: nil)
        }
    }
}

extension GetStartedVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.arrValu.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GetStartedCell", for: indexPath) as? GetStartedCell else { return UICollectionViewCell() }
        
        let dic:NSDictionary = self.arrValu[indexPath.item] as? NSDictionary ?? [:]
        cell.img.image = dic.value(forKey: "imgKey") as? UIImage ?? UIImage()
        cell.header1.text = dic.value(forKey: "header1") as? String ?? ""
        cell.substr1.text = dic.value(forKey: "subStr1") as? String ?? ""
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        //self.pageControl.currentPage = indexPath.section
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //let thisWidth = CGFloat(collStarted.frame.width)
        return CGSize(width: collStarted.frame.width, height: collStarted.frame.height)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let width = scrollView.frame.width
        currentPage = Int(scrollView.contentOffset.x / width)
        pageControl.currentPage = currentPage

        // Check if user has scrolled to the last page
        if currentPage == arrValu.count - 1 {
            reachedLastPage = true
            btnStarted.isSelected = true // Set the button as selected on the last page
            btnStarted.isEnabled = true // Enable the button on the last page
            btnStarted.isHidden = false
        } else {
            reachedLastPage = false
            btnStarted.isSelected = false // Set the button as not selected on other pages
            btnStarted.isEnabled = currentPage < 2 // Enable the button on the first two pages
            btnStarted.isHidden = true
        }
    }
}





