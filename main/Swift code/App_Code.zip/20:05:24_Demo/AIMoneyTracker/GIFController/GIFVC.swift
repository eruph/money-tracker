//
//  GIFVC.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import Firebase
import UIKit
import GoogleMobileAds
import MBProgressHUD

class GIFVC: UIViewController {
    
    private let delay: TimeInterval = 9.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add a tap gesture recognizer to the view
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        view.addGestureRecognizer(tapGestureRecognizer)
        navigationItem.hidesBackButton = true
        
        setupViews()
        startDelay()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Hide the navigation bar
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    @objc func handleTap() {
        // Check if the user has already received the reward
        let hasReceivedReward = UserDefaults.standard.bool(forKey: "HasReceivedReward")
        
        if !hasReceivedReward {
            // Increment the click count when the user taps anywhere on the screen
            Click_CountClass.shared.incrementClickCount()
            Click_CountClass.shared.checkClickCount(presentingViewController: self)
        }
    }
    
    private func setupViews() {
        let imageView = UIImageView(frame: view.bounds)
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: "video")
        view.addSubview(imageView)
    }
    
    private func startDelay() {
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
            self.navigateToLaunchActivity()
        }
    }
    
    private func navigateToLaunchActivity() {
        // Check if the GifVC has been displayed previously
        let hasDisplayedScreen = UserDefaults.standard.bool(forKey: "DisplayedAuckthrow")
        
        if !hasDisplayedScreen {
            // Show the GifVC
            let gifVC = mainStoryBoard.instantiateViewController(withIdentifier: "GetStartedVC") as! GetStartedVC
            self.navigationController?.pushViewController(gifVC, animated: true)
            
            // Mark that the GifVC has been displayed
            UserDefaults.standard.set(true, forKey: "DisplayedAuckthrow")
        } else {
            //            let mainFamilyVC = mainStoryBoard.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
            //            self.navigationController?.pushViewController(mainFamilyVC, animated: true)
            if CommonConst.isPurchasedRemoveAds {
                // If ads are purchased, navigate to the MainVC
                let mainFamilyVC = mainStoryBoard.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
                self.navigationController?.pushViewController(mainFamilyVC, animated: true)
            } else {
                // If ads are not purchased, navigate to the RemoveAdsVC
                let removeAdsVC = mainStoryBoard.instantiateViewController(withIdentifier: "RemoveAdsViewController") as! RemoveAdsViewController
                self.navigationController?.pushViewController(removeAdsVC, animated: true)
            }
        }
    }
}

fileprivate extension UIApplication {
    
    func getTopViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        
        if let nav = base as? UINavigationController {
            return getTopViewController(base: nav.visibleViewController)
            
        } else if let tab = base as? UITabBarController, let selected = tab.selectedViewController {
            return getTopViewController(base: selected)
            
        } else if let presented = base?.presentedViewController {
            return getTopViewController(base: presented)
        }
        return base
    }
}


