//
//  RemoveAdsViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import MBProgressHUD

extension UIColor {
    convenience init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        
        var rgb: UInt64 = 0
        
        Scanner(string: hexSanitized).scanHexInt64(&rgb)
        
        let red = CGFloat((rgb & 0xFF0000) >> 16) / 255.0
        let green = CGFloat((rgb & 0x00FF00) >> 8) / 255.0
        let blue = CGFloat(rgb & 0x0000FF) / 255.0
        
        self.init(red: red, green: green, blue: blue, alpha: 1.0)
    }
}

class RemoveAdsViewController: UIViewController {
    
    @IBOutlet weak var lblprice: UILabel!
    @IBOutlet weak var btnrestore: MyButton!
    
    var isForOnlyRemoveAd = false
    var isSuccess : ((String) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showInAppPurchasePrice()
        showPriceText()
        btnrestore.layer.borderColor = UIColor.black.cgColor
        btnrestore.layer.borderWidth = 0.8
        btnrestore.layer.cornerRadius = 5.0

        self.navigationItem.hidesBackButton = true
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        //load reward ad if needed
        if !isForOnlyRemoveAd{
            ClassGAD_New.shared.checkGADRewardedInterstitialAd(adInfo: RewardedInterstitialAD,isNeedToPresent: false)
        }
    }
    
    private func moveToNext(){
        if isForOnlyRemoveAd{
            self.navigationController?.popViewController(animated: true)
        }else{
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
//    private func hideViewForOnlyRemoveAd(){
//        btnClose.isHidden = !isForOnlyRemoveAd
////        stcContinueWithAd.isHidden = isForOnlyRemoveAd
//        stcContinueWithAd.subviews.forEach({
//            $0.isHidden = isForOnlyRemoveAd
//        })
//    }
    
    func showInAppPurchasePrice(){
                InAppPurchaseClass.shared.getPrice {[self] isSuccess in
                    if isSuccess{
                        showPriceText()
                    }else{
                        showInAppPurchasePrice()
                    }
                }
    }
    
    func showPriceText(){
        lblprice.text = "\(CommonConst.priceOfRemoveAd.isEmpty ? "-" : CommonConst.priceOfRemoveAd)"
    }
    
    func handleUserReward() {
        print("User earned a reward!")
        // Implement any actions you want to perform when the user earns a reward.
    }
    
    func setGradientBackground(view: UIView, colorTop: UIColor, colorBottom: UIColor, cornerRadius: CGFloat, leadingMargin: CGFloat, trailingMargin: CGFloat) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x: leadingMargin, y: 0, width: view.bounds.width - leadingMargin - trailingMargin, height: view.bounds.height)
        gradientLayer.colors = [colorTop.cgColor, colorBottom.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        
        // Apply corner radius to the view's layer
        view.layer.cornerRadius = cornerRadius
        
        // Make sure to clip subviews to the rounded corners
        view.clipsToBounds = true
        
        // Apply corner radius to the gradient layer
        gradientLayer.cornerRadius = cornerRadius
        gradientLayer.masksToBounds = true
        
        // Insert the gradient layer as a sublayer
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setGradientBackground1(view: UIView, colorTop: UIColor, colorBottom: UIColor, cornerRadius: CGFloat, leadingMargin: CGFloat, trailingMargin: CGFloat) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x: leadingMargin, y: 0, width: view.bounds.width - leadingMargin - trailingMargin, height: view.bounds.height)
        gradientLayer.colors = [colorTop.cgColor, colorBottom.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        
        // Apply corner radius to the view's layer
        view.layer.cornerRadius = cornerRadius
        
        // Make sure to clip subviews to the rounded corners
        view.clipsToBounds = true
        
        // Apply corner radius to the gradient layer
        gradientLayer.cornerRadius = cornerRadius
        gradientLayer.masksToBounds = true
        
        // Insert the gradient layer as a sublayer
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    @IBAction func click_remove_ads(_ sender: Any) {
                if CommonConst.isInternetConnected{
                    InAppPurchaseClass.shared.purchase { isSuccess, errMsg in
                        if isSuccess{
                            self.isSuccess?(errMsg)
                            //self.navigationController?.popViewController(animated: true)
                            let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
                            self.navigationController?.pushViewController(vc, animated: true)
                        }else{
                            CustomToast.toastMessage(message: errMsg, type: .ERROR)
                        }
                    }
                }else{
                    CustomToast.toastMessage(message: "Please check internet connection", type: .ERROR)
                }
    }
    
    @IBAction func click_restore(_ sender: Any) {
        if CommonConst.isInternetConnected{
            InAppPurchaseClass.shared.restore{ isSuccess, errMsg in
                if isSuccess{
                    self.isSuccess?(errMsg)
                    self.navigationController?.popViewController(animated: true)
                }else{
                    CustomToast.toastMessage(message: errMsg, type: .ERROR)
                }
            }
        }else{
            CustomToast.toastMessage(message: "Please check internet connection")
        }
    }
    
    @IBAction func continue_main(_ sender: Any) {
//        if ClassGAD.shared.isRewardedAdLoaded() {
//            ClassGAD.shared.presentGADRewardedAd(userReward: { [weak self] in
//                // User earned the reward (optional)
//                self?.handleUserReward()
//                
//                // Navigate to the desired view controller after the ad is completed
//                let vc = self?.storyboard?.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
//                self?.navigationController?.pushViewController(vc, animated: true)
//            })
//        } else {
//            // Show a loading indicator using MBProgressHUD
//            let loadingHUD = MBProgressHUD.showAdded(to: self.view, animated: true)
//            loadingHUD.label.text = "Loading"
//            
//            // Wait for 5 seconds and check if the ad is loaded
//                MBProgressHUD.hide(for: self.view, animated: true)
//                
//                if ClassGAD.shared.isRewardedAdLoaded() {
//                    // If the ad is loaded after waiting, present it
//                    ClassGAD.shared.presentGADRewardedAd(userReward: { [weak self] in
//                        // User earned the reward (optional)
//                        self?.handleUserReward()
//                        
//                        // Navigate to the desired view controller after the ad is completed
//                        let vc = self?.storyboard?.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
//                        self?.navigationController?.pushViewController(vc, animated: true)
//                    })
//                } else {
//                    // If the ad is still not loaded after waiting, navigate to the desired view controller
//                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabViewController") as! TabViewController
//                    self.navigationController?.pushViewController(vc, animated: true)
//                }
//        }
        
        ClassGAD_New.shared.checkGADRewardedInterstitialAd(adInfo: RewardedInterstitialAD) {
        } adisDismissed: { isAdDismissed in
            if isAdDismissed{
                // If ad is still not loaded after waiting, navigate to FamilyCreateGrpVC
                self.moveToNext()
            }
        }
    }
}


