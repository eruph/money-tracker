//
//  RemoveAds_CodeViewController.swift
//  AIMoneyTracker
//
//  Created by Comet Lake on 11/10/23.
//

import UIKit
import MBProgressHUD

class RemoveAds_CodeViewController: UIViewController {
    
    @IBOutlet weak var lblprice: UILabel!
    @IBOutlet weak var btnrestore: MyButton!
    
    var isForOnlyRemoveAd = false
    var isSuccess : ((String) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Premium"
        showInAppPurchasePrice()
        showPriceText()
        btnrestore.layer.borderColor = UIColor.black.cgColor
        btnrestore.layer.borderWidth = 0.8
        btnrestore.layer.cornerRadius = 5.0
        
//        // Set the gradient background for the removeadview
//        let colorTop = UIColor(hex: "9C57FF")
//        let colorBottom = UIColor(hex: "DD8FFF") // Replace with your color code
//        let cornerRadius: CGFloat = 10.0
//        let leadingMargin: CGFloat = 10.0
//        let trailingMargin: CGFloat = 10.0
//        setGradientBackground(view: removeadview, colorTop: colorTop, colorBottom: colorBottom, cornerRadius: cornerRadius, leadingMargin: leadingMargin, trailingMargin: trailingMargin)
        
        // Do any additional setup after loading the view.
    }
    
    func showInAppPurchasePrice(){
        InAppPurchaseClass.shared.getPrice {[self] isSuccess in
            if isSuccess{
                showPriceText()
            }else{
                showInAppPurchasePrice()
            }
        }
    }
    
    func showPriceText(){
        lblprice.text = "\(CommonConst.priceOfRemoveAd.isEmpty ? "-" : CommonConst.priceOfRemoveAd)"
    }
    
    func handleUserReward() {
        print("User earned a reward!")
        // Implement any actions you want to perform when the user earns a reward.
    }
    
    func setGradientBackground(view: UIView, colorTop: UIColor, colorBottom: UIColor, cornerRadius: CGFloat, leadingMargin: CGFloat, trailingMargin: CGFloat) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x: leadingMargin, y: 0, width: view.bounds.width - leadingMargin - trailingMargin, height: view.bounds.height)
        gradientLayer.colors = [colorTop.cgColor, colorBottom.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        
        // Apply corner radius to the view's layer
        view.layer.cornerRadius = cornerRadius
        
        // Make sure to clip subviews to the rounded corners
        view.clipsToBounds = true
        
        // Apply corner radius to the gradient layer
        gradientLayer.cornerRadius = cornerRadius
        gradientLayer.masksToBounds = true
        
        // Insert the gradient layer as a sublayer
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    func setGradientBackground1(view: UIView, colorTop: UIColor, colorBottom: UIColor, cornerRadius: CGFloat, leadingMargin: CGFloat, trailingMargin: CGFloat) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x: leadingMargin, y: 0, width: view.bounds.width - leadingMargin - trailingMargin, height: view.bounds.height)
        gradientLayer.colors = [colorTop.cgColor, colorBottom.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        
        // Apply corner radius to the view's layer
        view.layer.cornerRadius = cornerRadius
        
        // Make sure to clip subviews to the rounded corners
        view.clipsToBounds = true
        
        // Apply corner radius to the gradient layer
        gradientLayer.cornerRadius = cornerRadius
        gradientLayer.masksToBounds = true
        
        // Insert the gradient layer as a sublayer
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
    
    @IBAction func clickNavigate(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func click_remove_ads(_ sender: Any) {
        if CommonConst.isInternetConnected{
            InAppPurchaseClass.shared.purchase { isSuccess, errMsg in
                if isSuccess{
                    self.isSuccess?(errMsg)
                    self.navigationController?.popViewController(animated: true)
                }else{
                    CustomToast.toastMessage(message: errMsg, type: .ERROR)
                }
            }
        }else{
            CustomToast.toastMessage(message: "Please check internet connection", type: .ERROR)
        }
    }
    
    @IBAction func click_restore(_ sender: Any) {
        if CommonConst.isInternetConnected{
            InAppPurchaseClass.shared.restore{ isSuccess, errMsg in
                if isSuccess{
                    self.isSuccess?(errMsg)
                    self.navigationController?.popViewController(animated: true)
                }else{
                    CustomToast.toastMessage(message: errMsg, type: .ERROR)
                }
            }
        }else{
            CustomToast.toastMessage(message: "Please check internet connection")
        }
    }
    
}



