<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Helpers\OneSignalHelper;
use App\Models\Post;
use Carbon\Carbon;
use DB;

class WeeklyDeleteUser extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'write command like below';
    // protected $signature = 'test:send';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Weekly Deleted Data set time According';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $today = Carbon::today();
        $twoDaysAgo = Carbon::today()->subDays(2);

        $uniquePlayerIds = DB::table('posts')
            ->select('player_id')
            ->where('created_at', '<', $twoDaysAgo)
            ->groupBy('player_id')
            ->havingRaw('COUNT(*) = 1')
            ->pluck('player_id');

        // Step 2: Delete records with these unique player_ids
        $deletedCount = Post::whereIn('player_id', $uniquePlayerIds)
                            ->where('created_at', '<', $twoDaysAgo)
                            ->delete();
        // dd($uniquePlayerIds, $deletedCount);
        $this->info('Weekly Data Deleted Successfully.');
    }
}
