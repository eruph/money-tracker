<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Helpers\OneSignalHelper;
use App\Models\Post;
use Carbon\Carbon;

class UserNotification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'write command like below';
    // protected $signature = 'demo:send';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Daily Send Notification user set time According';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $todayAtStart = Carbon::today()->setTime(11, 0, 0);
        $todayAtEnd = Carbon::today()->setTime(18, 0, 0);
        $entriesBetweenToday = Post::whereNotBetween('created_at', [$todayAtStart, $todayAtEnd])->where('notificationdaily',0)->get()->toArray();
        $distinctPlayerIds = array_unique(array_column($entriesBetweenToday, 'player_id'));
        // dd($distinctPlayerIds);
        $device_id =[];
        foreach ($distinctPlayerIds as $key => $value) {
            $device_id[] = $value;
        }
        // dd($device_id);
        $response = OneSignalHelper::daily_notification($device_id);
        $this->info('Successfully sent daily Notification');
    }
}
