<?php

namespace App\Helpers;

use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;
use App\Models\Post;

class OneSignalHelper
{
    public static function daily_notification($device_id)
    {
        $client = new Client();

        $response = $client->request('POST', 'https://onesignal.com/api/v1/notifications', [
            'headers' => [
                'Authorization' => 'Basic ' . env('ONESIGNAL_REST_API_KEY'),
                'Content-Type' => 'application/json',
            ],
            'json' => [
                'app_id' => env('ONESIGNAL_APP_ID'),
                'contents' => [
                    'en' => "please Add a Any Details",
                ],
                'include_player_ids' => $device_id,
            ],
        ]);
       
        return $response->getBody()->getContents();
    }
    public static function send_notification($playerId, $description, $scheduledTime)
    {
        $title ="Please Check Suspense Transaction.";
        $notificationContent = "$title\n$description";
        
        $client = new Client();

        $response = $client->request('POST', 'https://onesignal.com/api/v1/notifications', [
            'headers' => [
                'Authorization' => 'Basic '. env('ONESIGNAL_REST_API_KEY'),
                'accept'        => 'application/json',
                'content-type'  => 'application/json'
            ],
            'json' => [
                'app_id' => env('ONESIGNAL_APP_ID'),
                'contents' => [
                    'en' => $notificationContent,
                ],
                // 'include_player_ids' => [$playerId],
                'include_subscription_ids' => [$playerId],
                'send_after' => $scheduledTime,
            ]
        ]);

        return $response->getBody()->getContents();
    }

    public static function update_notification($playerid,$notificationId, $description, $scheduledTime)
    {
        $title ="Please Check Suspense Transaction.";
        $notificationContent = "$title\n$description";
        $client = new Client();

        try {
            // Cancel the existing scheduled notification
            $response = $client->delete("https://onesignal.com/api/v1/notifications/{$notificationId}", [
                'headers' => [
                    'Authorization' => 'Basic ' . base64_encode(env('ONESIGNAL_REST_API_KEY') . ':'),
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'app_id' => env('ONESIGNAL_APP_ID'),
                ],
            ]);

            // Create a new scheduled notification
            $response = $client->post("https://onesignal.com/api/v1/notifications", [
                'headers' => [
                    'Authorization' => 'Basic ' . base64_encode(env('ONESIGNAL_REST_API_KEY') . ':'),
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'app_id' => env('ONESIGNAL_APP_ID'),
                    'contents' => [
                        'en' => $notificationContent,
                    ],
                    'include_player_ids' => [$playerid],
                    //'included_segments' => ['All'],
                    'send_after' => $scheduledTime,
                ],
            ]);

            // Process the response
            $statusCode = $response->getStatusCode();
            $responseData = json_decode($response->getBody(), true);

        if ($statusCode === 200 && isset($responseData['id'])) {
            return  $responseData['id'];
        }
        } catch (ClientException $e) {
            // Handle the client exception
            $statusCode = $e->getResponse()->getStatusCode();
            $responseBody = $e->getResponse()->getBody()->getContents();

            return $statusCode;
        } catch (Exception $e) {
            // Handle other exceptions
            return -1; // Or any other suitable error code
        }
    }

    public static function delete_notification($id)
    {
        $client = new Client();
        $scheduledNotificationId = $id;

        try {
            // Make the DELETE request to delete the scheduled notification
            $response = $client->delete("https://api.onesignal.com/notifications/{$scheduledNotificationId}", [
                'headers' => [
                    'Authorization' => 'Basic ' . env('ONESIGNAL_REST_API_KEY'),
                    'Content-Type' => 'application/json',
                ],
                'json' => [
                    'app_id' => env('ONESIGNAL_APP_ID'),
                ],
            ]);
            // Process the successful response here
            $statusCode = $response->getStatusCode();
            return $statusCode;
        } catch (ClientException $e) {
            // Handle the client exception here
            $statusCode = $e->getResponse()->getStatusCode();
            $responseBody = $e->getResponse()->getBody()->getContents();
        }
    }
}