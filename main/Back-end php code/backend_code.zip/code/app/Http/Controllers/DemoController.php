<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PlayeridInfo;
use App\Models\Suspense;
use App\Models\Post;
use carbon\carbon;
use Illuminate\Http\Response;
use Validator;
use GuzzleHttp\Client;
use App\Helpers\OneSignalHelper;

class DemoController extends Controller
{
    public function player_id_store(Request $req)
    {
        $validator = Validator::make($req->all(), [
            'player_id' => 'required'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors()->first();
            return response()->json([
                "status" => "error",
                "message" => $errors,
            ]);
        }

        $checkPlayerId = PlayeridInfo::where('player_id', $req->player_id)->first();

        if (empty($checkPlayerId)) {
            $storePlayreId = new PlayeridInfo();

            $storePlayreId->player_id = $req->player_id;
            $storePlayreId->save();

            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Player ID Inserted Successfully.",
                "data" => $storePlayreId,
            ]);
        } else {
            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Player ID Already Exists.",
            ]);
        }
    }
    public function player_list(Request $req)
    {
        $showPlayerInfo = PlayeridInfo::all();
       
        if (!empty($showPlayerInfo[0])) {

            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Successfully Get Player ID Info.",
                "data" => $showPlayerInfo,
            ]);
        } else {
            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "No Player ID Exists.",
            ]);
        }
    }

    public function suspense_user_store(Request $req)
    {
        $validator = Validator::make($req->all(), [
            'player_id' => 'required',
            'notificationtime' => 'required',
            'description' => 'required',
        ]);
        
        if ($validator->fails()) {
            $errors = $validator->errors()->first();
            return response()->json([
                "status" => "error",
                "message" => $errors,
            ]);
        }

        $storeSuspense = new Suspense();

        $storeSuspense->player_id = $req->player_id;
        $storeSuspense->notificationtime = $req->notificationtime;
        $storeSuspense->description = $req->description;
        $storeSuspense->save();

        $playerId = $req->player_id;
        $description = $req->description;
        $notificationTime = carbon::parse($req->notificationtime);
        $notificationTime->subHours(4)->subMinutes(30);
        $scheduledTime = $notificationTime->format('Y-m-d H:i:s');
        
        $response = OneSignalHelper::send_notification($playerId,$description, $scheduledTime);
        $response = json_decode($response);
        $id = $response->id;
        $storeSuspense->notificationid = $id;
        $storeSuspense->save();
        
        $getSuspenseData = Suspense::where('notificationid',$id)->latest()->first();
    
        if (empty($getSuspenseData->notificationid)) {
           $deleteSuspenseData = Suspense::find($getSuspenseData->id);   
           $deleteSuspenseData->delete();
           return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Suspense Data Deleted Successfully.",
                "details" => "",
                "data" => $response,
            ]);
        } else {                                                                                                                                                                                    
            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Suspense Data Inserted Successfully.",
                "details" => $getSuspenseData,
                "data" => $response,
            ]);                                                                                                                         
        } 
    }

    public function edit_suspense(Request $req, $id)
    {
        $updateSuspenseData = Suspense::find($id);
        
        if (empty($updateSuspenseData)) {
            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Suspense Data Not Exists.",
                "data" => $updateSuspenseData,
            ]);
        } else {
            $updateSuspenseData->player_id = $req->player_id ? $req->player_id : $updateSuspenseData->player_id;
            $updateSuspenseData->notificationtime = $req->notificationtime ? $req->notificationtime : $updateSuspenseData->notificationtime;
            $updateSuspenseData->description = $req->description ? $req->description : $updateSuspenseData->description;
            $updateSuspenseData->notificationid = $updateSuspenseData->notificationid;
            $updateSuspenseData->save();
    
            $description = $updateSuspenseData->description;
            $notificationtime = carbon::parse($updateSuspenseData->notificationtime);
            $notificationtime->subHours(4)->subMinutes(30);
            $scheduledTime = $notificationtime->format('Y-m-d H:i:s');
            $notificationid = $updateSuspenseData->notificationid;
            $response = OneSignalHelper::update_notification($updateSuspenseData->player_id,$notificationid, $description, $scheduledTime);
    
            if (!empty($response)) {
                $updateSuspenseData->notificationid = $response;
                $updateSuspenseData->save();
                return response()->json([
                    "status" => Response::HTTP_OK,
                    "message" => "Updated Record and Scheduled Notification",
                    "data" => $updateSuspenseData,
                ]);
            } else {
                return response()->json([
                    "status" => Response::HTTP_INTERNAL_SERVER_ERROR,
                    "message" => "Failed to update the Scheduled Notification",
                    "data" => $updateSuspenseData,
                ]);
            }
        }
    }

    public function delete_suspense(Request $request, $id)
    {
        $deleteSuspenseData = Suspense::find($id);

        if (empty($deleteSuspenseData)) {
            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Data Not Exists.",
                "data" => $deleteSuspenseData,
            ]);
        } else {
            $signalnotificationid = $deleteSuspenseData->notificationid;
            $response = OneSignalHelper::delete_notification($signalnotificationid);
            $deleteSuspenseData->delete();

            return response()->json([
                "status" => response::HTTP_OK,
                "message" => "Suspense Record Deleted.",
                "data" => $deleteSuspenseData,
            ]);
        }
    }

    public function insert_data(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'player_id' => 'required',
            'prompt' => 'required'
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors()->first();
            return response()->json([
                "status" => "error",
                "message" => $errors,
            ]);
        }
        $postData = new Post();

        $postData->player_id = $request->player_id;
        $postData->prompt = $request->prompt;
        $postData->save();

        return response()->json([
            "status" => response::HTTP_OK,
            "message" => "Inserted Record",
            "data" => $postData,
        ]);
    }

    public function notification_on_off_daily($id){
        $postData = Post::where('player_id', $id)->get();
        
        foreach ($postData as $value) {
            if ($value['notificationdaily'] == 0) {
                $value->notificationdaily = 1;
                $value->save();
                $postData = "Not Get Daily Notification";
            } elseif ($value['notificationdaily'] == 1) {
                $value->notificationdaily = 0;
                $value->save();
                $postData = "Get Daily Notification";
            }
        }
        return response()->json([
            "status" => response::HTTP_OK,
            "message" => $postData,
        ]);
    }
}
