<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DemoController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('player-id-list', [DemoController::class, 'player_list'])->name('show.playerinfo');
Route::post('store-player-id', [DemoController::class, 'player_id_store'])->name('store.playerid');
Route::post('suspense-notificat', [DemoController::class, 'suspense_user_store'])->name('store.suspense');
Route::post('edit-suspense/{id}', [DemoController::class, 'edit_suspense'])->name('edit.suspense');
Route::delete('suspense-delete/{id}', [DemoController::class, 'delete_suspense'])->name('delete.suspense');
Route::post('insert-data', [DemoController::class, 'insert_data'])->name('insert');
Route::post('notification-on-off-daily/{player_id}', [DemoController::class, 'notification_on_off_daily']);